"use client";

import React from "react";
import { SwiperSlide } from "swiper/react";
import SwiperSlider from "./SwiperSlider";
import Image from "next/image";
import Link from "next/link";
import { User, FolderOpen, LearnMoreIcon } from "@/app/SVG";
import { capitalizeFirst } from "@/app/utils/constent";
import ProgressiveImage from "./ProgressiveImage";

interface RelatedArticle {
  title: string;
  slug: string;
  description: string;
  cover?: {
    url: string;
    alternativeText: string;
  };
  body: string;
  author?: {
    name: string;
    updatedAt: string;
  };
  category: { name: string };
}

interface RelatedBlogsSliderProps {
  relatedBlogs: RelatedArticle[];
  loading?: boolean;
}

export default function RelatedBlogsSlider({
  relatedBlogs,
  loading = false,
}: RelatedBlogsSliderProps) {
  if (loading) {
    return (
      <div className="flex gap-6 animate-pulse">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="w-full md:w-1/3">
            <div className="rounded-[15px] shadow-custom overflow-hidden">
              {/* Image Skeleton with Shimmer */}
              <div className="h-[211px] bg-gray-200 relative overflow-hidden">
                <div className="absolute inset-0 -translate-x-full bg-gradient-to-r from-gray-200 via-white/50 to-gray-200 animate-shimmer" />
              </div>

              {/* Content Skeleton */}
              <div className="py-8 px-6 space-y-4">
                {/* Author/Category */}
                <div className="flex gap-5 items-center">
                  <div className="flex gap-3 items-center">
                    <div className="w-6 h-6 bg-gray-200 rounded-full" />
                    <div className="h-4 bg-gray-200 rounded w-24" />
                  </div>
                  <div className="flex gap-3 items-center">
                    <div className="w-6 h-6 bg-gray-200 rounded-full" />
                    <div className="h-4 bg-gray-200 rounded w-24" />
                  </div>
                </div>

                {/* Title & Description */}
                <div className="space-y-2">
                  <div className="h-6 bg-gray-200 rounded w-3/4" />
                  <div className="h-4 bg-gray-200 rounded w-full" />
                  <div className="h-4 bg-gray-200 rounded w-5/6" />
                </div>

                {/* Learn More */}
                <div className="flex items-center gap-5 mt-5">
                  <div className="w-6 h-6 bg-gray-200 rounded-full" />
                  <div className="h-4 bg-gray-200 rounded w-16" />
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <SwiperSlider>
      {relatedBlogs.map((data, i) => (
        <SwiperSlide key={i}>
          <Link
            href={`/blog/${data.slug}`}
            className="block overflow-hidden rounded-[15px] shadow-custom"
            prefetch
          >
            <div className="h-[211px]">
              {data.cover?.url ? (
                <div className="w-full h-full rounded-[10px] overflow-hidden mb-6">
                  <ProgressiveImage
                    src={
                      data.cover.url.startsWith("http")
                        ? data.cover.url
                        : `https://admin.iillestfindsagency.com${data.cover.url}`
                    }
                    height={175}
                    width={276}
                    className="max-w-full max-h-full"
                    alt={`Image for ${data.cover.alternativeText}`}
                  />
                </div>
              ) : (
                <div className="w-full h-full bg-gradient-to-r from-[#241431] to-[#3E1A5F] animate-shimmer">
                  <Image
                    src="/images/related-blog-1.jpg"
                    height={175}
                    width={276}
                    className="w-full h-full object-cover"
                    alt={`Image for ${capitalizeFirst(data.title)}`}
                  />
                </div>
              )}
            </div>
            <div className="py-8 px-6">
              {(data.author?.name || data.category?.name) && (
                <div className="flex gap-5 items-center text-[#737588] mb-4">
                  {data.author?.name && (
                    <div className="flex gap-3 items-center text-[12px] font-[400] leading-[25px]">
                      <User />
                      <span>{data.author.name}</span>
                    </div>
                  )}
                  {data.category?.name && (
                    <div className="flex gap-3 items-center text-[12px] font-[400] leading-[25px]">
                      <FolderOpen />
                      <span>{data.category.name}</span>
                    </div>
                  )}
                </div>
              )}
              <h2 className="text-[#040503] text-[18px] lg:text-[20px] 2xl:text-[28px] leading-normal 2xl:leading-[36px] font-bold mb-5 text-truncate-2">
                {capitalizeFirst(data.title)}
              </h2>
              <p className="text-[14px] lg:text-base leading-normal font-medium text-truncate-4">
                {capitalizeFirst(data.description)}
              </p>
              <div className="group flex items-center gap-5 mt-5">
                <LearnMoreIcon className="transition-all delay-100 group-hover:rotate-[30deg] text-current" />
                <span className="group-hover:font-bold transition-all delay-100">
                  Learn More
                </span>
              </div>
            </div>
          </Link>
        </SwiperSlide>
      ))}
    </SwiperSlider>
  );
}
