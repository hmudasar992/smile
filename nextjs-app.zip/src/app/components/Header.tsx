"use client";

import Image from "next/image";
import Link from "next/link";
import React, { useEffect, useState } from "react";
import Button from "./Button";
import { usePathname } from "next/navigation";
import { EmailWhite, LocationWhite, PhoneWhite } from "../SVG";

const headerMenu = [
  { name: "Home", path: "/" },
  { name: "Services", path: "/services" },
  { name: "Case Study", path: "/case-study" },
  { name: "Blog", path: "/blog" },
];

const Header = () => {
  const pathname = usePathname();
  const [isScrolled, setIsScrolled] = useState(false);
  const [showMenu, setShowMenu] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 5);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);
  const handleShowMenu = () => {
    setShowMenu(true);
  };
  const handleCloseMenu = () => {
    setShowMenu(false);
  };

  useEffect(() => {
    if (showMenu) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "auto";
    }
    return () => {
      document.body.classList.remove("overflow-hidden");
    };
  }, [showMenu]);

  return (
    <React.Fragment>
      <header
        className={`fixed w-full top-0 left-0 z-50 transition-all duration-300 ${
          isScrolled ? "lg:-translate-y-[44px] lg:-translate-y-[48px] 2xl:-translate-y-[65px]" : ""
        }`}
      >
        <div className={`bg-gradient hidden lg:block`}>
          <div className="container mx-auto px-4 md:px-6">
            <ul className="flex gap-2 items-center justify-evenly">
              <li className="flex gap-3 items-center text-[14px] lg:text-base 2xl:text-[18px] font-[400] leading-[20px] 2xl:leading-[25px] text-white md:py-2 lg:py-3 2xl:py-5">
                <EmailWhite />
                <a href="mailto:faeezahlun@iillestfinds.com">
                  faeezahlun@iillestfinds.com
                </a>
              </li>
              <li className="flex gap-3 items-center text-[14px] lg:text-base 2xl:text-[18px] font-[400] leading-[20px] 2xl:leading-[25px] text-white md:py-2 lg:py-3 2xl:py-5">
                <PhoneWhite />
                <a href="tel:+19258184494">(+1) 925-818-4494</a>
              </li>
              <li className="flex gap-3 items-center text-[14px] lg:text-base 2xl:text-[18px] font-[400] leading-[20px] 2xl:leading-[25px] text-white md:py-2 lg:py-3 2xl:py-5">
                <LocationWhite />
                <a
                  href="https://www.google.com/maps/place/Iillest+Finds/@33.5611935,-111.9523555,10z/data=!3m1!4b1!4m6!3m5!1s0xadbfdd69eb94967d:0x945954682ee637b3!8m2!3d33.5611935!4d-111.9523556!16s%2Fg%2F11wwp9nh48?entry=ttu&g_ep=EgoyMDI1MDMxMi4wIKXMDSoASAFQAw%3D%3D"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Scottsdale, Greater Phoenix Area, Arizona
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div
          className={`transition-all duration-300 ${
            isScrolled
              ? "bg-white shadow-custom py-2 lg:py-3"
              : "py-3 md:py-5 lg:py-7 2xl:py-9"
          }`}
        >
          <div className="container mx-auto px-4 md:px-6">
            <div className="flex justify-between items-center">
              <div className="logo">
                <Link href="/" prefetch>
                  <Image
                    src="/images/logo-text.png"
                    height={38}
                    width={312}
                    alt="logo"
                    className={`ransition-all duration-300 w-[170px] h-auto lg:w-[312px]`}
                  />
                </Link>
              </div>
              <div className="header-right-side inline-flex items-center gap-4 lg:gap-8">
                <div className="header-menu hidden lg:flex items-center">
                  <nav>
                    <ul className="flex gap-8 items-center">
                      {headerMenu.map((item, index) => {
                        const isActive =
                          pathname === item.path ||
                          pathname.startsWith(item.path + "/");

                        return (
                          <li key={index}>
                            <Link
                              href={item.path}
                              className={`${
                                isActive
                                  ? "text-[20px] font-semibold"
                                  : "text-base font-[400]"
                              }  transition-all duration-300 hover:gradient-text"
                      `}
                              prefetch
                            >
                              {item.name}
                            </Link>
                          </li>
                        );
                      })}
                    </ul>
                  </nav>
                </div>
                <Button varient="primary" text="Contact" path="/contact-us" />
                <button
                  className="h-[30px] w-[35px] flex-none relative z-[999] lg:hidden"
                  onClick={handleShowMenu}
                >
                  <span className="h-[3px] bg-gradient rounded-[3px] block mb-2 w-[70%] ms-auto"></span>
                  <span className="h-[3px] bg-gradient rounded-[3px] block mb-2"></span>
                  <span className="h-[3px] bg-gradient rounded-[3px] block w-[80%] ms-auto"></span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div
        className={`mobile-menu fixed top-0 ${
          showMenu ? "open" : ""
        } left-0 w-full h-full z-50 transition-all duration-400 z-[999]`}
      >
        <div
          className="absolute bg-black bg-opacity-50 left-0 right-0 bottom-0 top-0"
          onClick={handleCloseMenu}
        ></div>
        <nav
          className={`bg-white w-[300px] p-5 h-full relative off-canvas-inner-content`}
        >
          <ul className="">
            {headerMenu.map((item, index) => {
              const isActive =
                pathname === item.path || pathname.startsWith(`${item.path}/`);

              return (
                <li key={index} className="mb-4">
                  <Link
                    href={item.path}
                    className={`${
                      isActive
                        ? "text-[20px] font-semibold"
                        : "text-[18px] font-[400]"
                    }  transition-all duration-300 hover:gradient-text block"
                      `}
                    prefetch
                  >
                    {item.name}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>
      </div>
    </React.Fragment>
  );
};

export default Header;
