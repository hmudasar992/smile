"use client"; // ✅ Mark this as a Client Component

import Breadcrumb from "./Breadcrumb";

interface BreadcrumbWrapperProps {
  heading: string;
  slugin: string;
  pageName: string;
  bgImage?: string;
}

const BreadcrumbWrapper: React.FC<BreadcrumbWrapperProps> = ({ heading, slugin, pageName, bgImage }) => {
  return <Breadcrumb heading={heading} slugin={slugin} pageName={pageName} bgImage={bgImage} />;
};

export default BreadcrumbWrapper;
