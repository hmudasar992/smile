import React from "react";
import BlogHeading from "./BlogHeading";
import Card from "./Card";

interface Blog {
  category?: { name: string };
}

const BlogsCategory = ({ props }: { props: Blog[] }) => {
  // Group categories and count their occurrences
  const categoryCounts: Record<string, number> = props.reduce(
    (acc: Record<string, number>, blog: Blog) => {
      const categoryName = blog.category?.name || "Uncategorized"; // Default to "Uncategorized"
      acc[categoryName] = (acc[categoryName] || 0) + 1;
      return acc;
    },
    {}
  );
  const categories = Object.entries(categoryCounts); // Convert grouped object to array

  return (
    <React.Fragment>
      <Card>
        <BlogHeading title="Category" />
        {categories.map(([category, count], index) => (
          <div
            className="flex items-center justify-between pl-5 bg-[#F8F9FC] mb-5 group hover:shadow-post"
            key={index}
          >
            <span className="inline-block text-[#757474] text-[14px] py-4 min-h-[50px] font-medium">
              {category}
            </span>
            <span className="inline-flex items-center flex-none justify-center border border-[#E3E3E3] rounded-[5px] min-h-[50px] w-[50px]">
              {count}
            </span>
          </div>
        ))}
      </Card>
    </React.Fragment>
  );
};

export default BlogsCategory;
