"use client";
import { useState, useEffect, useRef } from "react";
import React from "react";
import Heading from "./Heading"; // Ensure Heading outputs the correct tag (e.g., <h2>)
import { TickIcon } from "../SVG";
import Button from "./Button";
import LinkTag from "./LinkTag";

const pricingData = [
  {
    packageName: "SEO",
    packageList: [
      {
        title: "starter",
        name: "Starter SEO Package",
        desc: "Ideal for small businesses looking to boost local search rankings and attract nearby!",
        price: "799",
        listing: [
          "Website Audit & Technical SEO Fixes",
          "Keyword Research (10 Target Keywords)",
          "On-Page SEO (Meta, Titles, Headers, Content Optimization)",
          "Google My Business (GMB) Optimization",
          "Local SEO (GBP Optimization, Local Listings, Maps Ranking)",
          "Basic Link Building (5 Quality Backlinks per Month)",
          "Monthly SEO Report & Progress Tracking",
        ],
        caption:
          "Best for: Small businesses, startups, and service providers looking to improve local visibility.",
      },
      {
        title: "popular",
        name: "Popular SEO Package",
        desc: "Designed for businesses ready to scale traffic and leads with advanced SEO tactics.",
        price: "1499",
        listing: [
          "Everything in Starter Package PLUS:",
          "Expanded Keyword Research (20 Target Keywords)",
          "Technical SEO Fixes + Page Speed Optimization",
          "Content Optimization (Existing Pages + Blog Strategy)",
          "On-Page & Off-Page SEO Improvements",
          "Advanced Link Building (10 Quality Backlinks per Month)",
          "Local & National SEO Strategy",
          "10 High-Quality Backlinks Per Month",
          "Competitor Analysis & Strategy",
          "Monthly SEO Report + Strategy Call",
        ],
        caption:
          "Best for: Businesses ready to scale their organic traffic and leads.",
      },
      {
        title: "custom",
        name: "Custom SEO Package",
        desc: "Need a fully tailored SEO strategy? Let’s build one just for you!",
        customPrice: "Tailored for Your Business!",
        listing: [
          "Need more keywords? Done!",
          "Want high-authority backlinks? We got you!",
          "Need an aggressive content & blogging strategy? Let’s build it!",
          "Looking for eCommerce or enterprise SEO? We can help!",
        ],
        caption:
          "Best for: Businesses with specific SEO goals and highly competitive niches.",
      },
    ],
  },

  {
    packageName: "Web Development",
    packageList: [
      {
        title: "starter",
        name: "Starter Website Package",
        desc: "A simple, high-converting website for startups!",
        price: "799",
        listing: [
          "1-Page Website (WordPress or Wix)",
          "Custom Design & Branding",
          "Mobile-Optimized & Fast Loading",
          "Contact Form & CTA Sections",
          "Basic SEO Setup (Meta, Titles, Keywords)",
          "Social Media & WhatsApp Integration",
          "Live Chat Integration (If Needed)",
        ],
        caption:
          "Best for: Startups, freelancers, and small businesses looking for a quick, professional online presence.",
      },
      {
        title: "popular",
        name: "Business Website Package",
        desc: "A complete website solution for growing brands!",
        price: "1499",
        listing: [
          "4 to 7 Pages (Home, About, Services, Contact, etc.)",
          "Built on WordPress or Wix",
          "Custom, SEO-Friendly Design",
          "Mobile & Tablet Responsive",
          "Blog Setup (If Required)",
          "Basic On-Page SEO & Google Indexing",
          "Google Analytics & Speed Optimization",
          "Contact Forms, WhatsApp & Social Media Integration",
          "1 Month Free Support & Updates",
        ],
        caption:
          "Best for: Small to mid-sized businesses looking for a professional, conversion-focused website.",
      },
      {
        title: "custom",
        name: "Custom Website Package",
        desc: "Need a high-performance, custom-built website? Let’s create one just for you!",
        customPrice: "Tailored for Your Business!",
        listing: [
          "Fully Custom Website (React, Next.js, HTML, CSS)",
          "Pixel-Perfect Conversion from XD/Figma Designs",
          "eCommerce, SaaS, or Web Applications",
          // "Advanced Animations & Interactive Elements",
          "API Integrations & Backend Development",
          "SEO-Optimized, Lightning-Fast Performance",
        ],
        caption:
          "Best for: Businesses needing a high-performance custom website—whether for eCommerce, SaaS, or a web app.",
      },
    ],
  },
  {
    packageName: "Social Media Marketing",
    packageList: [
      {
        title: "starter",
        name: "Starter Package",
        desc: "Kickstart your social media journey with a strong online presence!",
        price: "699",
        listing: [
          "2 Social Media Platforms (FB, Insta, X, LinkedIn, TikTok)",
          "12 Posts Per Month (Graphics + Captions + Hashtags)",
          "Basic Engagement (Replying to Comments & Messages)",
          "Hashtag & Competitor Research",
          "Monthly Performance Report",
        ],
        caption:
          "Best for: Startups and small businesses looking to build brand awareness and engage with customers.",
      },
      {
        title: "popular",
        name: "Most Popular – Growth Package",
        desc: "Designed for brands looking to scale their social media impact!",
        price: "1449",
        listing: [
          "4 Social Media Platforms (FB, Insta, X, LinkedIn, TikTok)",
          "20 Posts Per Month (Graphics + Captions + Hashtags)",
          "4 Short-Form Videos/Reels Per Month",
          "Community Engagement & Interaction",
          "Ad Strategy & Campaign Setup (Ad budget not included)",
          "Influencer Collaboration Suggestions",
          "Monthly Performance Report + Strategy Call",
        ],
        caption:
          "Best for: Businesses ready to boost engagement, leads, and brand authority.",
      },
      {
        title: "custom",
        name: "Custom Package",
        desc: "Need a fully tailored strategy? Let’s build one just for you!",
        customPrice: "Tailored for Your Needs!",
        listing: [
          "Want to add more platforms? No problem!",
          "Need extra content, videos, or ad management? We got you!",
          "Looking for a dedicated social media manager? Let’s make it happen!",
        ],
        caption:
          "Best for: Businesses with specific social media goals and growth ambitions.",
      },
    ],
  },
];

const Pricing = () => {
  const [activeTab, setActiveTab] = useState(0);
  const indicatorRef = useRef<HTMLDivElement>(null);
  const tabsRef = useRef<(HTMLButtonElement | null)[]>([]);

  useEffect(() => {
    if (tabsRef.current[activeTab] && indicatorRef.current) {
      const tab = tabsRef.current[activeTab];
      indicatorRef.current.style.transform = `translateX(${tab.offsetLeft}px)`;
      indicatorRef.current.style.width = `${tab.offsetWidth}px`;
    }
  }, [activeTab]);

  const handleTabClick = (index: number) => {
    setActiveTab(index);
  };

  return (
    <section id="pricing" className="pt-10 pb-5 lg:pt-16 lg:pb-8">
      <div className="container mx-auto px-4 md:px-6">
        <header className="w-[590px] max-w-full mb-6 md:lg-mb-8 lg:mb-10 mx-auto text-center">
          {/* Using an H2 for the main section heading */}
          <Heading
            tag="h2"
            text="Transparent Pricing for Every Business Stage"
            className="text-center"
          />
          <p className="mb-5 text-[18px] mt-3">
            We offer <b>tailored pricing</b> to match your <b>business goals</b>
            — whether you&apos;re a <b>startup</b> or an{" "}
            <b>established local brand</b>. Choose a package that fits your{" "}
            <b>needs and budget</b>.
          </p>
        </header>
        <div className="tabs w-full mx-auto">
          <div className="flex justify-center">
            <div
              className="tabs-nav overflow-x-auto relative inline-flex gap-3 bg-white p-3 rounded-[45px] shadow-button shadow-box mb-8 border border-[#EBEAED]"
              role="tablist"
              aria-label="Pricing Packages"
            >
              <div
                ref={indicatorRef}
                className="tabs-indicator absolute top-3 bottom-3 left-0 rounded-[40px] bg-gradient transition-transform duration-400 ease-in-out"
              ></div>
              {pricingData.map((data, index) => (
                <button
                  key={index}
                  ref={(el) => {
                    tabsRef.current[index] = el;
                  }}
                  className={`tab-button flex-none px-5 py-2 md:px-8 md:py-3 text-base md:text-[18px] lg:text-[22px] font-medium rounded-[40px] cursor-pointer transition-colors duration-400 relative ${
                    activeTab === index ? "text-white" : "hover:gradient-text"
                  }`}
                  role="tab"
                  aria-selected={activeTab === index}
                  onClick={() => handleTabClick(index)}
                >
                  {data.packageName}
                </button>
              ))}
            </div>
          </div>
          {pricingData.map((content, index) => (
            <div
              key={index}
              className={`tab-panel py-6 lg:p-6 rounded-lg bg-opacity-10 bg-white transition-[all] duration-[400ms] ease-[cubic-bezier(0.4,0,0.2,1)] ${
                activeTab === index ? "block animate-fadeIn" : "hidden"
              }`}
              role="tabpanel"
              aria-hidden={activeTab !== index}
            >
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 lg:gap-8 xl:gap-10 2xl:gap-16 md:justify-center">
                {content.packageList.map((data, i) => (
                  <article key={i} className="w-full ld:w-1/3 flex">
                    <div
                      className={`border flex flex-col justify-between border-[#F1F1F1] rounded-[14px] p-[20px] lg:p-[25px] xl:p-[30px] overflow-hidden ${
                        data.title === "popular"
                          ? "bg-gradient-light"
                          : "lg:h-[90%] mt-auto"
                      }`}
                    >
                      <header>
                        {data.title === "popular" && (
                          <div className="bg-[#A665CB] py-3 text-center -mt-[30px] -mx-[30px] mb-5">
                            <span className="text-white text-base leading-[20px] uppercase font-bold tracking-[1px]">
                              Most Popular
                            </span>
                          </div>
                        )}
                        <div className="inline-block bg-[#D7A2F4] rounded-[8px] px-[10px] py-[2px] mb-4">
                          {/* Use H3 for the package name */}
                          <h3 className="gradient-text text-[12px] leading-[20px] tracking-[0.2px]">
                            {data.name}
                          </h3>
                        </div>
                      </header>
                      <p className="text-[12px] text-black leading-[20px] mb-5">
                        {data.desc}
                      </p>
                      <div className="text-black text-[20px] md:text-[22px] lg:text-[28px] xl:text-[32px] 2xl:text-[38px] font-bold leading-[30px] xl:leading-[44px]">
                        {data.price ? (
                          <div className="flex gap-2 items-center">
                            <span className="text-[44px] font-bold inline-block">
                              ${data.price}
                            </span>
                            <span className="text-[20px] font-[400] inline-block">
                              /month
                            </span>
                          </div>
                        ) : (
                          data.customPrice
                        )}
                      </div>
                      <div className="dashed-line"></div>
                      <ul className="mb-6">
                        {data.listing.map((list, i) => (
                          <li
                            key={i}
                            className="flex gap-3 items-center text-[14px] font-[400] mb-3"
                          >
                            <TickIcon />
                            {list}
                          </li>
                        ))}
                      </ul>
                      <footer>
                        <div className="text-center xl:px-6">
                          <div className="text-[14px] xl:text-base leading-[20px] xl:leading-[24px] font-bold tracking-[2%] text-black">
                            {data.caption}
                          </div>
                        </div>
                        <div className="2xl:px-6 pt-6 xl:mt-10">
                          {data.title === "custom" ? (
                            <LinkTag
                              text="Request a Custom Quote"
                              varient="primary"
                              className="w-full"
                              path="https://app.acuityscheduling.com/schedule.php?owner=32088231&calendarID=10026411"
                            />
                          ) : (
                            <Button
                              text="Get Started"
                              varient="primary"
                              className="w-full"
                              path="/contact-us"
                            />
                          )}
                        </div>
                      </footer>
                    </div>
                  </article>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Pricing;
