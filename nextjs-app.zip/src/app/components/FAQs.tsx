"use client";

import React, { useEffect, useRef, useState } from "react";
import Heading from "./Heading";
import { Plus, Question } from "../SVG";
import Button from "./Button";

interface FAQ {
  heading: string;
  description: string;
}

interface FAQsProps {
  faqs: {
    title: string;

    shortDesc: string;

    faqList: {
      heading: string;

      description: string;
    }[];
  };
}

const FAQs = ({ faqs }: FAQsProps) => {
  const contentRef = useRef<(HTMLDivElement | null)[]>([]);
  const [activeIndex, setActiveIndex] = useState<number | null>(0);

  useEffect(() => {
    if (activeIndex !== null && contentRef.current[activeIndex]) {
      contentRef.current[
        activeIndex
      ].style.maxHeight = `${contentRef.current[activeIndex].scrollHeight}px`;
    }

    contentRef.current.forEach((el, idx) => {
      if (idx !== activeIndex && el) {
        el.style.maxHeight = "0";
      }
    });
  }, [activeIndex]);

  const handleToggle = (index: number) => {
    setActiveIndex((prevIndex) => (prevIndex === index ? null : index));
  };

  return (
    <section
      id="faqs"
      className="py-14"
      aria-label="Frequently Asked Questions"
    >
      <div className="container mx-auto px-4 md:px-6">
        <header className="w-[590px] max-w-full mb-6 md:lg-mb-8 lg:mb-10 mx-auto text-center">
          <Heading tag="h2" text={faqs.title} className="text-center" />
          <p className="mb-5 text-[18px] mt-3">{faqs.shortDesc}</p>
        </header>
        <div className="flex flex-wrap lg:flex-nowrap gap-12 mt-12 md:mt-20 lg:mt-24">
          <div className="w-full lg:w-8/12">
            {faqs.faqList.map((faq: FAQ, index: number) => (
              <article
                key={index}
                className={`${
                  activeIndex === index
                    ? "bg-[#F4E1FF] border-[#F4E1FF]"
                    : "border-[#EBEAED]"
                } [&:not(:last-child)]:mb-7 border overflow-hidden rounded-[14px]`}
                aria-label={`FAQ: ${faq.heading}`}
              >
                <button
                  className="flex justify-between items-center w-full px-3 py-4 lg:px-4 lg:py-5 text-left"
                  onClick={() => handleToggle(index)}
                  aria-expanded={activeIndex === index}
                >
                  <h3 className="text-[#151515] text-[14px] lg:text-[18px] font-semibold leading-[22px] lg:leading-[2px]">
                    {faq.heading}
                  </h3>
                  <div
                    className={`w-5 h-5 ml-4 transform transition-transform duration-300 ${
                      activeIndex === index ? "rotate-45" : "rotate-0"
                    }`}
                    aria-hidden="true"
                  >
                    <Plus />
                  </div>
                </button>
                <div
                  ref={(el) => {
                    contentRef.current[index] = el;
                  }}
                  className="transition-all duration-500 ease-in-out overflow-hidden"
                  style={{ maxHeight: "0" }}
                >
                  <div className="px-3 lg:px-4 pb-5">
                    <p className="text-black text-sm lg:text-base leading-[24px] lg:leading-[28px]">
                      {faq.description}
                    </p>
                  </div>
                </div>
              </article>
            ))}
          </div>
          <aside className="w-full lg:w-4/12">
            <div className="flex items-center border border-[#EBEAED] rounded-[14px] p-6 h-full">
              <div className="w-full text-center">
                <div className="inline-block mx-auto" aria-hidden="true">
                  <Question />
                </div>
                <h4 className="mb-5 text-center text-[25px] font-bold">
                  Do you have more questions?
                </h4>
                <p className="mb-5 text-center text-[18px] leading-[30px] font-bold">
                  We’re here to provide the clarity and support you need—just
                  ask!
                </p>
                <div className="border border-[#EBEAED] rounded-[10px] p-[14px] px-[30px] text-left transition-all duration-300 ease hover:shadow-box">
                  <input
                    type="text"
                    className="border-0 outline-none text-[18px] leading-[32px] w-full"
                    placeholder="Write your query"
                    aria-label="Write your query"
                  />
                </div>
                <div className="mt-8">
                  <Button text="Send" varient="primary" className="py-4 px-8" />
                </div>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </section>
  );
};

export default FAQs;
