"use client";
import React from "react";
import Heading from "./Heading";
// import Image from "next/image";
import Link from "next/link";
import { TickIcon2 } from "../SVG";
import { data } from "../data";
import { notFound } from "next/navigation";
import ProgressiveImage from "./ProgressiveImage";

interface CaseStudy {
  image: string;
  desc: string;
  slug: string;
  summery: string;
}

const CaseStudy = () => {
  const caseStudy = data.caseStudyData;
  if (!caseStudy) {
    return notFound();
  }
  // console.log(caseStudy, "service");
  return (
    <section
      id="case-study"
      className="py-10 lg:py-16"
      aria-label="Case Studies"
    >
      <div className="container mx-auto px-4 md:px-6">
        <header className="w-[800px] max-w-full mb-10 mx-auto">
          <div className="flex flex-wrap lg:flex-nowrap justify-center lg:justify-start gap-10">
            <Heading
              tag="h2"
              text="Case Studies"
              className="text-center flex-none"
            />
            <p className="mb-5 text-base lg:text-[18px] lg:text-left text-center">
              Discover How Businesses Thrive: Real-Life Case Studies Showcasing
              Our Proven Digital Marketing Success.
            </p>
          </div>
        </header>
        <div className="bg-[#F4E1FF] px-6 py-6 lg:px-0 lg:py-[46px] 2xl:py-[56px] rounded-[45px] bg-opacity-50">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-0 md:justify-center">
            {caseStudy.slice(0, 3).map((data: CaseStudy, i: number) => (
              <article
                key={i}
                className="w-full lg:px-[36px] xl:px-[42px] 2xl:px-[50px] lg:py-0 lg:pb-0 md:[&:not(:last-child)]:pb-6 lg:[&:not(:last-child)]:pb-0  [&:not(:last-child)]:border-[#392147] border-0 border-b lg:border-b-0 lg:border-r"
                aria-label={`Case Study ${i + 1}`}
              >
                <div className="group relative">
                  <div className="rounded-[6px] overflow-hidden mb-[20px] relative">
                    <ProgressiveImage
                      src={data.image}
                      alt={`Case Study ${i + 1} image`}
                      height={194}
                      width={285}
                      className="h-full w-full object-center object-cover transition-all ease duration-300 group-hover:scale-[1.3]"
                    />
                  </div>
                  <p className="leading-[23px] text-[18px] text-black mb-4 text-truncate-4  h-[92px]">
                    {data.summery}
                  </p>
                  <footer>
                    <Link
                      href={`/case-study/${data.slug}`}
                      className="group flex items-center gap-5"
                      aria-label="Learn more about this case study"
                      prefetch
                    >
                      <span>Learn More</span>
                      <TickIcon2 className="transition-all delay-100 group-hover:rotate-[30deg]" />
                    </Link>
                  </footer>
                </div>
              </article>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default CaseStudy;
