"use client";

import React from "react";
import { Autoplay, FreeMode, Mousewheel } from "swiper/modules";
import { Swiper, SwiperSlide } from "swiper/react";
import Image from "next/image";
import "swiper/css";
import "swiper/css/mousewheel";
import "swiper/css/autoplay";
import "swiper/css/free-mode";

const clientsData = [
  { name: "Amazon", image: "/images/client/amazon.png" },
  { name: "Dribbble", image: "/images/client/dribble.png" },
  { name: "HubSpot", image: "/images/client/hubspot.png" },
  { name: "Netflix", image: "/images/client/netflix.png" },
  { name: "Notion", image: "/images/client/notion.png" },
  { name: "Zoom", image: "/images/client/zoom.png" },
  { name: "HubSpot", image: "/images/client/hubspot.png" },
  { name: "Netflix", image: "/images/client/netflix.png" },
  { name: "Notion", image: "/images/client/notion.png" },
];

const Clients = () => {
  return (
    <section id="clients" className="py-10 lg:py-16" aria-label="Our Clients">
      <div className="container mx-auto px-4 md:px-6">
        <h2 className="text-center text-[30px] font-bold mb-6">Our Clients</h2>
        <Swiper
          modules={[Autoplay, Mousewheel, FreeMode]}
          freeMode={true}
          loop={true}
          autoplay={{
            delay: 1000,
            disableOnInteraction: false,
          }}
          speed={3000}
          scrollbar={{ draggable: true }}
          breakpoints={{
            300: { slidesPerView: 3, spaceBetween: 10 },
            1024: { slidesPerView: 4, spaceBetween: 20 },
            1200: { slidesPerView: 5, spaceBetween: 30 },
            1500: { slidesPerView: 6, spaceBetween: 40 },
          }}
          className="client-swiper"
        >
          {clientsData.map((item, i) => (
            <SwiperSlide key={i}>
              <div className="text-center">
                <Image
                  src={item.image}
                  height={50}
                  width={125}
                  alt={`${item.name} logo`}
                  className="h-auto w-auto mx-auto"
                />
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </section>
  );
};

export default Clients;
