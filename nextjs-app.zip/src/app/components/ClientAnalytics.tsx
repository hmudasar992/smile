"use client"; // Ensure it runs only on the client-side

import { useEffect } from "react";
import { usePathname } from "next/navigation";
import Script from "next/script";

const GA_MEASUREMENT_ID = process.env.NEXT_PUBLIC_GA_ID || "G-XXXXXXXXXX";

// Extend the global `window` object to include `gtag`
declare global {
  interface Window {
    gtag: (command: "config" | "event", eventName: string, params?: Record<string, unknown>) => void;
  }
}

export default function ClientAnalytics() {
  const pathname = usePathname(); // Get the current route

  useEffect(() => {
    if (GA_MEASUREMENT_ID !== "G-XXXXXXXXXX" && typeof window !== "undefined" && window.gtag) {
      window.gtag("config", GA_MEASUREMENT_ID, {
        page_path: pathname,
      });
    }
  }, [pathname]);

  if (GA_MEASUREMENT_ID === "G-XXXXXXXXXX") return null; // Prevent adding GA when no ID is set

  return (
    <>
      {/* Load Google Analytics script */}
      <Script
        strategy="afterInteractive"
        src={`https://www.googletagmanager.com/gtag/js?id=${GA_MEASUREMENT_ID}`}
      />
      <Script
        id="google-analytics"
        strategy="afterInteractive"
        dangerouslySetInnerHTML={{
          __html: `
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            window.gtag = window.gtag || function(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', '${GA_MEASUREMENT_ID}', {
              page_path: window.location.pathname,
            });
          `,
        }}
      />
    </>
  );
}
