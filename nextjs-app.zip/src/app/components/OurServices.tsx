"use client";

import Image from "next/image";
import Link from "next/link";
import React from "react";
import { LearnMoreIcon } from "../SVG";
import { data } from "../data";

const OurServices = () => {
  const services = data.services;

  return (
    <section
      id="our-services"
      className="py-10 lg:py-16"
      aria-label="Our Services – Digital Growth, Simplified"
    >
      <div className="container mx-auto px-4 md:px-6">
        <div className="w-full lg:w-9/12 mb-10">
          <div className="inline-block flex-none mb-3">
            <h2 className="text-[24px] md:text-[30px] lg:text-[35px] font-bold leading-[51px] mb-3 mb-3 bg-[#F5F5F7] inline py-[2px] px-[6px] flex-none">
              Our Services – Digital Growth, Simplified!
            </h2>
          </div>
          <p className="mb-5">
            We offer <b>strategic marketing solutions</b> tailored for
            businesses looking to <b>grow, rank, and convert</b>. Whether you
            need <b>more traffic, better engagement, or a website that sells</b>
            , we’ve got the expertise to help.
          </p>
          <p className="mb-6">
            <strong>Click on the service below to learn more!</strong>
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 lg:gap-8 xl:gap-10 2xl:gap-16 md:justify-center">
          {services.map((service, i) => (
            <article className="" key={i} aria-label={service.title}>
              <div className="group block bg-white hover:bg-gradient rounded-[14px] shadow-button shadow-box p-[2px] transition-all delay-100">
                <div className="bg-white rounded-[12px] p-7 relative h-full w-full">
                  <div className="flex justify-end">
                    <Image
                      src={service.icon}
                      height={91}
                      width={105}
                      alt={`${service.title} Icon`}
                      className="h-auto w-auto"
                    />
                  </div>
                  <div className="py-4 pe-8">
                    <div className="pb-4">
                      <div className="w-56">
                        <h3 className="inline text-[22px] md:text-[26px] lg:text-[30px] leading-[23px]   md:leading-[27px] lg:leading-[36px] bg-[#F4E1FF] group-hover:bg-[#F5F5F7] transition-all ease">
                          {service.tabTitle}
                        </h3>
                      </div>
                    </div>
                    <p className="text-[14px] lg:text-base 2xl:text-[14px] lg:text-base leading-normal font-medium text-truncate-4 mb-10">
                      {service.tabDescription}
                    </p>
                    <Link
                      href={`/services/${service.slug}`}
                      className="group flex items-center gap-5"
                      aria-label={`Learn more about ${service.title}`}
                      prefetch
                    >
                      <LearnMoreIcon className="transition-all delay-100 group-hover:rotate-[30deg]" />
                      <span className="group-hover:font-bold transition-all delay-100">
                        Learn More
                      </span>
                    </Link>
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

export default OurServices;
