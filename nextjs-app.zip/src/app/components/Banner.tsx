"use client";

import Image from "next/image";
import Button from "./Button";
import { BusinessGrowthIcon, Star, WhatsAppIcon } from "../SVG";

const Banner = () => {
  return (
    <header className="banner py-10 lg:py-14 2xl:py-16">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex justify-between xl:flex-nowrap flex-wrap">
          <div className="w-full xl:w-[45%] lg:pe-8 2xl:pr-10 xl:mb-0 mb-10">
            <h1 className="gradient-text text-[24px] md:text-[30px] lg:text-[36px] xl:text-[40px] 2xl:text-[46px] font-bold leading-[30px] md:leading-[38px] lg:leading-[46px] xl:leading-[50px] 2xl:leading-[63px] mb-5">
              Faeezah Lun – Your Digital Growth Partner in Phoenix!
            </h1>

            {/* ✅ Using backticks to avoid JSX unescaped entities error */}
            <p className="text-[14px] xl:text-base 2xl:text-[18px] leading-normal lg:leading-[35px] font-normal">
              {`Want to attract more customers and boost your online presence?
              I provide services like SEO, social media marketing, and high-converting websites—helping businesses get seen, rank higher, and drive sales with ease.`}
              <br />
              <br />
              {`Based in Scottsdale, we proudly serve businesses across the Phoenix metro area. Let’s take your brand to the next level!`}
            </p>

            <div className="flex gap-4 mt-12">
              <Button
                varient="primary"
                text="Get Free Quote"
                className="py-3 h-[60px]"
                path="/contact-us"
              />

              <a
                href="https://wa.me/19258184494"
                target="_blank"
                className="flex items-center justify-center bg-white rounded-[14px] p-[1px] border border-[#40254F] h-[60px] w-[60px] hover:shadow-custom hover:bg-white transition-all ease"
              >
                <WhatsAppIcon />
              </a>
              <a
                href="https://app.acuityscheduling.com/schedule.php?owner=32088231&calendarID=10026411"
                target="_blank"
                className="flex items-center justify-center bg-white rounded-[14px] p-[1px] border border-[#40254F] h-[60px] w-[60px] hover:shadow-custom hover:bg-white transition-all ease"
              >
                <Image
                  src="/images/calendary.png"
                  height={36}
                  width={39}
                  alt="Book a Meeting Icon"
                />
              </a>
            </div>
          </div>

          <div className="w-full xl:w-[55%] relative">
            <div className="girl-bg h-[250px] overflow-hidden rounded-full ms-auto lg:me-[15%] w-[250px] md:mx-auto md:h-[320px] lg:h-[320px] xl:h-[360px] 2xl:h-[451px] md:w-[320px] lg:w-[320px] xl:w-[360px] 2xl:w-[451px] relative z-1">
              <Image
                src="/images/girl.png"
                height={545}
                width={451}
                alt="Faeezah Lun"
                className="w-full h-full object-cover object-center"
                priority={true}
              />
            </div>

            <div className="absolute top-0 left-[20px] lg:left-[70px] inline-flex gap-2 items-center rounded-[12px] bg-white px-[10px] py-[12px] lg:px-[14px] lg:py-[15px] shadow-box-light z-10">
              <BusinessGrowthIcon />
              <div>
                <h6 className="text-[10px] md:text-[12px] lg:text-[14px] leading-[18px] font-bold mb-1">
                  100% Business Growth
                </h6>
                <div className="flex gap-2 items-center">
                  <Star />
                  <span className="text-[8px] md:text-[10px] lg:text-[12px]">
                    <b className="me-2">4.9</b>
                    <span className="text-[#8A898E]">(10 Reviews)</span>
                  </span>
                </div>
              </div>
            </div>

            <Image
              src="/images/banner-bulb.png"
              height={214}
              width={248}
              alt="Creative Idea Icon"
              className="absolute left-[0%] w-[100px] md:w-[180px] lg-[248px] lg:left-[15%] top-1/2 -translate-y-1/2 "
            />

            <div className="absolute left-[5%] bottom-[20px] md:bottom-[30px] lg:bottom-[50px] h-auto z-[12] rounded-[12px] lg:px-[14px] lg:py-[15px] px-[10px] bg-white py-[12px] shadow-box-light">
              <h6 className="text-[10px] md:text-[12px] lg:text-[14px] leading-[18px] font-bold mb-1">
                20+ Happy Clients
              </h6>
              <div className="flex gap-2 items-center">
                <Star />
                <span className="text-[8px] md:text-[10px] lg:text-[12px]">
                  <b className="me-2">4.9</b>
                  <span className="text-[#8A898E]">(10 Reviews)</span>
                </span>
              </div>
            </div>

            <Image
              src="/images/banner-seo.svg"
              height={97}
              width={107}
              alt="SEO Icon"
              className="absolute top-0 right-[10%] lg:right-[7%] 2xl:right-[10%] w-[55px] md:w-[83px] lg:w-[90px] hidden md:block"
            />
            <Image
              src="/images/banner-services.svg"
              height={120}
              width={120}
              alt="Services Icon"
              className="absolute top-[22%] right-[1%] md:right-[3%] xl:right-0 2xl:right-4 w-[70px] md:w-[100px] lg:w-[110px] hidden md:block"
            />
            <Image
              src="/images/banner-speaker.svg"
              height={120}
              width={120}
              alt="Digital Marketing Speaker Icon"
              className="absolute top-[50%] right-0 lg:right-[.60rem] xl:right-2 w-[70px] md:w-[100px] lg:w-[110px] hidden md:block"
            />
          </div>
        </div>
      </div>
    </header>
  );
};

export default Banner;
