"use client";

import { SwiperSlide } from "swiper/react";
import SwiperSlider from "@/app/components/SwiperSlider";
import Link from "next/link";
import { LearnMoreIcon } from "@/app/SVG";

interface RelatedServicesSliderProps {
  serviceSlug: string;
  serviceList: {
    tabTitle: string;
    tabSubTitle: string;
    slug: string;
  }[];
}

export default function RelatedServicesSlider({
  serviceSlug,
  serviceList,
}: RelatedServicesSliderProps) {
  return (
    <SwiperSlider>
      {serviceList.map((data, i) => (
        <SwiperSlide key={i}>
          <div className="w-full">
            <div className="group block bg-[#797979] bg-opacity-50 hover:bg-gradient rounded-[14px] border p-[1px] transition-all delay-100">
              <div className="bg-white shadow-button shadow box rounded-[12px] p-7 relative h-full w-full">
                <div className="py-4 pe-8">
                  <header className="pb-4">
                    <div className="w-56">
                      <h3 className="inline text-[22px] md:text-[26px] lg:text-[30px] leading-[23px] md:leading-[27px] lg:leading-[36px] bg-[#F4E1FF] group-hover:bg-[#F5F5F7] transition-all ease">
                        {data.tabTitle}
                      </h3>
                    </div>
                  </header>
                  <p className="text-[18px] leading-[23px] font-[400] mb-10">
                    {data.tabSubTitle}
                  </p>
                  <Link
                    href={`/services/${serviceSlug}/${data.slug}`}
                    className="group flex items-center gap-5"
                    aria-label={`Learn more about ${data.tabTitle}`}
                    prefetch
                  >
                    <LearnMoreIcon className="transition-all delay-100 group-hover:rotate-[30deg]" />
                    <span className="group-hover:font-bold transition-all delay-100">
                      Learn More
                    </span>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </SwiperSlide>
      ))}
    </SwiperSlider>
  );
}
