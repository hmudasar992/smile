"use client";

import React from "react";
import Card from "./Card";
import BlogHeading from "./BlogHeading";
import type { BlogPost } from "../types/blog";

const Tags = ({ props }: { props: BlogPost[] }) => {
  // Ensure unique and non-empty tags
  const uniqueTags = [
    ...new Set(props.flatMap((blog) => blog.hashTags || [])),
  ].filter((tag) => tag);

  return (
    <Card>
      <BlogHeading title="Tags" />
      <div className="flex gap-5 flex-wrap">
        {uniqueTags.map((hashTag, index) => (
          <div
            key={index}
            className="border-[#E3E3E3] border rounded-[5px] bg-[#F8F9FC] text-[16px] leading-[28px] font-medium text-[#737588] py-1 px-3 hover:shadow-post hover:bg-white"
          >
            {hashTag}
          </div>
        ))}
      </div>
    </Card>
  );
};

export default Tags;
