"use client";

import React, { useEffect, useState } from "react";
import Heading from "./Heading";
import axios from "axios";
import { apiURL, authToken, capitalizeFirst } from "../utils/constent";
import ProgressiveImage from "./ProgressiveImage";
import Image from "next/image";
import Link from "next/link";

const formatDate = (dateString: string) => {
  const date = new Date(dateString);
  return date.toLocaleDateString("en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
};

const Blogs = () => {
  interface Blog {
    title: string;
    cover?: {
      url: string;
      alternativeText: string;
    };
    description: string;
    author?: {
      name: string;
      updatedAt: string;
    };
    slug: string;
  }

  const [blogs, setBlogs] = useState<Blog[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchBlogs = async () => {
      try {
        const response = await axios.get(`${apiURL}/articles?populate=*`, {
          headers: {
            Authorization: `Bearer ${authToken}`,
          },
        });
        setBlogs(response.data.data);
      } catch (error) {
        console.error("Error fetching blogs:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchBlogs();
  }, []);
  return (
    <section
      id="blog"
      className="py-14"
      aria-label="Expert Insights & Growth Strategies"
    >
      <div className="container mx-auto px-4 md:px-6">
        <header className="w-[790px] max-w-full mb-10 mx-auto text-center">
          <Heading tag="h2" text="Expert Insights & Growth Strategies" />
          <p className="mb-5 text-[18px] mt-3">
            Stay ahead of the curve with our blogs featuring expert tips, SEO
            hacks, social media strategies, and website development insights.
          </p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8 lg:gap-10 xl:gap-12 2xl:gap-14 md:justify-center">
          {loading
            ? // Loading Skeletons
              Array.from({ length: 3 }).map((_, i) => (
                <article
                  key={i}
                  className="w-full"
                  aria-label="Loading blog post"
                >
                  <div className="shadow-blog border border-[#EBEAED] hover:shadow-blog-hover transition-all duration-300 p-6 rounded-[8.6px] w-full">
                    <div className="rounded-[8.6px] overflow-hidden mb-5 animate-pulse">
                      <div className="w-full h-[175px] bg-gray-200 rounded-lg" />
                    </div>

                    <div className="space-y-3">
                      <div className="h-6 bg-gray-200 rounded w-3/4" />
                      <div className="h-4 bg-gray-200 rounded w-full" />
                      <div className="h-4 bg-gray-200 rounded w-5/6" />
                    </div>

                    <footer className="flex gap-5 items-center mt-5 animate-pulse">
                      <div className="flex-1 space-y-2">
                        <div className="h-4 bg-gray-200 rounded w-1/3" />
                        <div className="h-3 bg-gray-200 rounded w-1/4" />
                      </div>
                    </footer>
                  </div>
                </article>
              ))
            : // Actual Blog Items
              blogs?.slice(0, 3)?.map((data: Blog, i: number) => (
                <article
                  key={i}
                  className="w-full"
                  aria-label={`Blog post: ${data?.title}`}
                >
                  <Link
                    href={`/blog/${data?.slug}`}
                    className="block shadow-blog border border-[#EBEAED] hover:shadow-blog-hover transition-all duration-300 p-6 rounded-[8.6px] w-full hover:-translate-y-2"
                    prefetch
                  >
                    <div className="rounded-[8.6px] overflow-hidden mb-5">
                      {data?.cover?.url ? (
                        <ProgressiveImage
                          src={
                            data?.cover?.url.startsWith("http")
                              ? data?.cover?.url
                              : `https://admin.iillestfindsagency.com${data.cover.url}`
                          }
                          height={175}
                          width={276}
                          className="w-full h-full object-center object-cover"
                          alt={`Image for ${
                            data?.cover?.alternativeText || "default"
                          }`}
                          onError={(e) => {
                            (e.target as HTMLImageElement).src =
                              "/images/related-blog-1.jpg";
                          }}
                        />
                      ) : (
                        <Image
                          src="/images/related-blog-1.jpg"
                          height={175}
                          width={276}
                          className="w-full h-full object-center object-cover"
                          alt={`Image for ${
                            data?.cover?.alternativeText || "default"
                          }`}
                        />
                      )}
                    </div>
                    <h2 className="text-[#040503] text-[18px] lg:text-[24px] 2xl:text-[28px] leading-[24px] lg:leading-[30px] 2xl:leading-[36px] font-bold mb-5 text-truncate-2">
                      {capitalizeFirst(data?.title)}
                    </h2>
                    <p className="text-[14px] lg:text-base 2xl:text-[18px] leading-[18px] lg:leading-[20px] 2xl:leading-[23px] font-medium text-truncate-4">
                      {capitalizeFirst(data?.description)}
                    </p>

                    <footer className="flex gap-5 items-center mt-5">
                      <div>
                        <h6 className="text-[11.47px] font-bold leading-[14px] mb-2">
                          {data?.author?.name}
                        </h6>
                        <p className="text-[9px] leading-[11.5px] text-[#2B2C34] flex items-center">
                          {data?.author?.updatedAt
                            ? formatDate(data.author.updatedAt)
                            : "N/A"}
                        </p>
                      </div>
                    </footer>
                  </Link>
                </article>
              ))}
        </div>
      </div>
    </section>
  );
};

export default Blogs;
