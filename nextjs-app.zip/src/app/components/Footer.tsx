"use client";

import React from "react";
import Button from "./Button";
import Link from "next/link";
import { Email, Facebook, Instagram, Location, Phone, Tiktok } from "../SVG";
import LinkTag from "./LinkTag"; // ✅ Removed unused `useRouter`

const servicesLinks = [
  {
    name: "Social Media Marketing",
    desc: "Grow engagement, leads & sales!",
    path: "/services/seo-services-phoenix",
  },
  {
    name: "SEO Services",
    desc: "Rank higher, get traffic & dominate search engines!",
    path: "/services/social-media-marketing-phoenix",
  },
  {
    name: "Website Development",
    desc: "High-performance websites that convert!",
    path: "/services/website-development-phoenix",
  },
];

const socialLinks = [
  {
    icon: <Facebook />,
    path: "https://www.facebook.com/share/1AEuGAPGKZ",
  },
  {
    icon: <Instagram />,
    path: "https://www.instagram.com/iillestfinds",
  },
  {
    icon: <Tiktok />,
    path: "https://www.tiktok.com/@faeezahlun",
  },
];

const Footer = () => {
  return (
    <footer className="pt-12 md:pt-18 lg:pt-20 2xl:pt-24" aria-label="Footer">
      {/* Contact CTA Section */}
      <div className="relative -mb-24" id="contact-us">
        <div className="container mx-auto px-4 md:px-6">
          <div
            className="bg-gradient rounded-[10px] p-7"
            role="region"
            aria-label="Contact Call-to-Action"
          >
            <div className="flex flex-wrap gap-6 md:gap-8 lg:gap-10 lg:flex-nowrap items-center justify-center lg:justify-between">
              <LinkTag
                icon="WhatsAppIcon"
                text="Contact Us"
                className="py-2 lg:py-4 flex-none w-[180px] lg:w-[214px] h-[50px] lg:h-[67px]"
                path="https://wa.me/19258184494"
              />
              <div className="text-center max-w-[736px]">
                <h2 className="text-[18px] md:text-[24px] lg:text-[30px] 2xl:text-[35px] leading-[42px] lg:leading-[57px] font-bold mb-3 text-white">
                  Ready to Grow Your Local Business?
                </h2>
                <p className="text-[14px] lg:text-base 2xl:text-[18px] leading-[28px] font-[400] text-white">
                  Let’s take your online presence to the next level. It’s time
                  to build, rank, and convert—together!
                </p>
              </div>
              <Button
                text="Get a Quote"
                className="py-2 lg:py-4 flex-none w-[180px] lg:w-[214px] h-[50px] lg:h-[67px]"
                path="/contact-us"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Content */}
      <div className="bg-[#F4E1FF] bg-opacity-50 pt-40">
        <div className="container mx-auto px-4 md:px-6 pb-16">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-[2fr_1fr_1fr] gap-6 lg:gap-14 md:justify-center">
            {/* Business Overview */}
            <div>
              <h4 className="text-[26px] leading-[37px] text-gradient tracking-[0.1px] font-bold mb-5">
                Grow Your Business with Expert Digital Solutions in Phoenix!
              </h4>
              <p className="text-[16px] leading-[26px] text-gradient tracking-[0.2px] font-[400] mb-5">
                Struggling to get leads, rank on Google, or build a
                high-converting website? We’ve got you covered—right here in
                Phoenix, AZ.
              </p>
              <div className="flex flex-wrap md:lg-nowrap items-center gap-5">
                <h6 className="text-base text-black font-bold">
                  Have Questions? Let’s Talk!
                </h6>
                <LinkTag
                  text="Book a Meeting"
                  varient="primary"
                  className="flex-none rounded-[10px] text-[18px]"
                  path="https://app.acuityscheduling.com/schedule.php?owner=32088231&calendarID=10026411"
                />
              </div>
            </div>

            {/* Services Links */}
            <nav aria-label="Services">
              <h4 className="text-[20px] leading-[24px] text-gradient tracking-[0.3px] font-medium mb-5">
                Services
              </h4>
              <ul>
                {servicesLinks.map((item, i) => (
                  <li key={i}>
                    <Link
                      href={item.path}
                      className="text-[14px] font-[400] leading-[25px] text-gradient hover:text-black block mb-5"
                      prefetch
                    >
                      <strong>{item.name}</strong> – {item.desc}
                    </Link>
                  </li>
                ))}
              </ul>
            </nav>

            {/* Contact Info & Social Links */}
            <div aria-label="Contact Information">
              <h4 className="text-[20px] leading-[24px] text-gradient tracking-[0.3px] font-medium mb-5">
                Contact Us
              </h4>
              <address className="mb-5 not-italic">
                <ul>
                  <li className="flex gap-3 items-center text-[14px] font-[400] leading-[25px] group mb-3">
                    <Email />
                    <a
                      className="inline-block text-gradient group-hover:text-black"
                      href="mailto:faeezahlun@iillestfinds.com"
                    >
                      faeezahlun@iillestfinds.com
                    </a>
                  </li>
                  <li className="flex gap-3 items-center text-[14px] font-[400] leading-[25px] group mb-3">
                    <Phone />
                    <a
                      className="inline-block text-gradient group-hover:text-black"
                      href="tel:+19258184494"
                    >
                      (+1) 925-818-4494
                    </a>
                  </li>
                  <li className="flex gap-3 items-center text-[14px] font-[400] leading-[25px] group mb-3">
                    <Location />
                    <a
                      className="inline-block text-gradient group-hover:text-black"
                      href="https://www.google.com/maps/place/Iillest+Finds"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      Scottsdale, Greater Phoenix Area, Arizona
                    </a>
                  </li>
                </ul>
              </address>
              <nav aria-label="Social Media Links">
                <ul className="flex gap-4">
                  {socialLinks.map((item, i) => (
                    <li key={i}>
                      <a
                        href={item.path}
                        className="flex items-center justify-center rounded-[5px] h-[30px] w-[30px] bg-[#491F61]"
                        aria-label={`Follow us on ${
                          item.icon.type.name || "Social Media"
                        }`}
                      >
                        {item.icon}
                      </a>
                    </li>
                  ))}
                </ul>
              </nav>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
