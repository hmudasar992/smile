"use client";

import Link from "next/link";
import React from "react";
import { usePathname } from "next/navigation";
import { AngleRight2 } from "../SVG";

interface BreadcrumbProps {
  heading: string;
  slugin: string;
  pageName: string;
  detailPage?: boolean;
  bgImage?: string;
  loading?: boolean;
}

const Breadcrumb: React.FC<BreadcrumbProps> = ({
  heading,
  slugin,
  pageName,
  detailPage,
  bgImage,
  loading = false,
}) => {
  const path = usePathname();
  const baseServicePath = path.split("/").slice(0, 2).join("/");

  if (loading) {
    return (
      <nav
        aria-label="Breadcrumb Loading"
        className="py-6 min-h-[334px] flex items-center relative animate-pulse"
      >
        <div className="bg-gray-200 absolute top-0 left-0 w-full h-full rounded-lg" />
        <div className="container mx-auto px-4 md:px-6 relative">
          <div className="h-[45px] bg-gray-300 rounded-[7px] w-[200px] mb-4" />
          <div className="h-[42px] bg-gray-300 rounded w-3/4 mb-4" />
          <div className="flex items-center gap-4">
            <div className="h-6 bg-gray-300 rounded w-16" />
            <div className="text-gray-300">
              <AngleRight2 />
            </div>
            <div className="h-6 bg-gray-300 rounded w-24" />
          </div>
        </div>
      </nav>
    );
  }

  return (
    <nav
      aria-label="Breadcrumb"
      className={`py-6 min-h-[334px] flex items-center bg-cover bg-no-repeat relative ${
        bgImage ? "bg-right" : "bg-center"
      }`}
      style={{
        backgroundImage: `url(/images/${bgImage ? bgImage : "service-bg.jpg"})`,
      }}
    >
      <div className="bg-black bg-opacity-30 absolute top-0 left-0 w-full h-full"></div>
      <div className="container mx-auto px-4 md:px-6 relative">
        {heading && (
          <h2 className="bg-[#806DF4] rounded-[7px] px-3 text-white font-bold leading-[45px] text-[18px] lg:text-[24px] mb-4 inline-block">
            {heading}
          </h2>
        )}

        {slugin && (
          <h1 className="text-white font-bold leading-[36px] lg:leading-[42px] text-[24px] lg:text-[36px] mb-4 capitalize">
            {slugin}
          </h1>
        )}

        <ul className="flex items-center gap-4">
          <li>
            <Link
              href="/"
              className="inline-block text-base text-white font-semibold leading-[25px]"
              prefetch
            >
              Home
            </Link>
          </li>

          {detailPage ? (
            <li className="flex items-center gap-4 text-white">
              <AngleRight2 />
              <Link
                href={baseServicePath}
                className="inline-block text-base text-white font-semibold leading-[25px]"
                prefetch
              >
                {pageName}
              </Link>
            </li>
          ) : (
            <li className="flex items-center gap-4  text-white">
              <AngleRight2 />
              <span className="inline-block text-base text-white font-semibold leading-[25px]">
                {pageName}
              </span>
            </li>
          )}
        </ul>
      </div>
    </nav>
  );
};

export default Breadcrumb;
