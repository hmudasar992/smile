"use client";
import Image from "next/image";
import React, { useState } from "react";
import { PlayIcon } from "../SVG";

const AboutUs = () => {
  const [isOpen, setIsOpen] = useState(false);
  const videoId = "_4TwscKkRIA";
  return (
    <React.Fragment>
      <section id="about-us" className="py-10 lg:py-16">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-wrap lg:flex-nowrap lg:gap-12 xl:gap-16 2xl:gap-20">
            <div className="w-full lg:w-5/12">
              <div className="rounded-[14px] relative">
                <div className="overflow-hidden h-full-w-full max-h-[529px] relative">
                  <Image
                    src="/images/about-us.png"
                    height={600}
                    width={529}
                    alt="Our team at iillestfindsagency in action"
                    className="w-full h-full object-center object-cover"
                  />
                  <button
                    className="-ml-[52px] cursor-pointer z-[9] -mt-[52px] absolute top-1/2 left-1/2 -translate-y-1/2 -translate-x-1/2 bg-gradient rounded-[50%] h-[106px] w-[106px] flex items-center justify-center shadow-custom animate-pulse-effect group"
                    aria-label="Play video about us"
                    onClick={() => {
                      console.log("click");  // Change comma to semicolon
                      setIsOpen(true);
                    }}
                  >
                    <span className="absolute h-full w-full bg-white opacity-30 rounded-full animate-ring-effect"></span>
                    <PlayIcon />
                  </button>
                </div>
                <div className="absolute -left-5 -bottom-5">
                  <Image
                    src="/images/video-vector.png"
                    alt="Decorative video vector graphic"
                    height={314}
                    width={399}
                    layout="intrinsic"
                    className="2xl:w-[399px] lg:w-[300px] md:w-[250px] object-cover"
                  />
                </div>
              </div>
            </div>

            <article className="w-full lg:w-7/12">
              <header>
                <p className="block text-[#A7A6A6] font-medium text-base lg:text-[18px] 2xl:text-[20px] leading-[25px] mb-6 flex">
                  <span className="w-[30px] h-[2px] bg-gradient mt-2 me-3"></span>
                  Get to Know Us
                </p>
                <h2 className="text-[24px] lg:text-[30px] 2xl:text-[35px] font-bold leading-[28px] lg:leading-[38px] 2xl:leading-[45px] mb-3">
                  Helping Businesses Thrive Online—Beyond Just a Website!
                </h2>
              </header>
              <p className="mb-6">
                Success in the digital world requires more than just a{" "}
                <b>great-looking website</b> or
                <b>occasional social media posts</b>. It’s about{" "}
                <b>strategy, execution, and measurable results</b>—and that’s
                exactly what we deliver.
              </p>
              <ul className="list-1 mb-6">
                <li>
                  Managed <b>multiple social media campaigns</b> that converted
                  leads into loyal customers.
                </li>
                <li>
                  Worked on <b>15+ SEO projects</b>, ranking websites on{" "}
                  <b>Google’s</b> first page using <b>Local SEO, GBP & GMB</b>{" "}
                  strategies.
                </li>
                <li>
                  Built <b>20+ high-converting websites</b> that not only look
                  great but also drive sales.
                </li>
              </ul>
              <h3 className="text-[28px] font-bold leading-[45px] mb-3">
                Our Mission
              </h3>
              <p>
                We don’t just build websites or run ads—we create powerful
                digital strategies that drive real results. Let’s strengthen
                your brand identity and accelerate growth!
              </p>
            </article>
          </div>
        </div>
      </section>
      {isOpen && (
        <div
          className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-[99]"
          onClick={() => setIsOpen(false)} // Close modal on overlay click
        >
          <div
            className="shadow-lg w-full max-w-4xl relative"
            onClick={(e) => e.stopPropagation()} // Prevent closing when clicking inside modal
          >
            {/* Close button */}
            <button
              onClick={() => setIsOpen(false)}
              className="absolute -top-5 -right-5 text-white"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="1.2em"
                height="1.2em"
                viewBox="0 0 15 15"
              >
                <path
                  fill="#fff"
                  d="M3.64 2.27L7.5 6.13l3.84-3.84A.92.92 0 0 1 12 2a1 1 0 0 1 1 1a.9.9 0 0 1-.27.66L8.84 7.5l3.89 3.89A.9.9 0 0 1 13 12a1 1 0 0 1-1 1a.92.92 0 0 1-.69-.27L7.5 8.87l-3.85 3.85A.92.92 0 0 1 3 13a1 1 0 0 1-1-1a.9.9 0 0 1 .27-.66L6.16 7.5L2.27 3.61A.9.9 0 0 1 2 3a1 1 0 0 1 1-1c.24.003.47.1.64.27"
                />
              </svg>
            </button>

            <iframe
              className="w-full aspect-video"
              src={`https://www.youtube.com/embed/${videoId}?autoplay=1`}
              title="YouTube video"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            ></iframe>
          </div>
        </div>
      )}
    </React.Fragment>
  );
};

export default AboutUs;
