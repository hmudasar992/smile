import React from "react";
import { FolderOpen, LearnMoreIcon, User } from "../SVG";
import Image from "next/image";
import Link from "next/link";
import { capitalizeFirst } from "../utils/constent";

interface BlogPost {
  slug: string;
  title: string;
  description: string;
  cover?: {
    url?: string;
    alternativeText?: string;
  };
  author?: {
    name?: string;
  };
  category?: {
    name?: string;
  };
}

interface Props {
  data: BlogPost;
}

const SingleBlog = ({ data }: Props) => {
  return (
    <Link
      href={`/blog/${data.slug}`}
      className="block shadow-blog border border-[#EBEAED] hover:shadow-blog-hover transition-all duration-300 p-6 rounded-[8.6px] w-full hover:-translate-y-2"
      prefetch
    >
      {/* Rest of the component remains the same */}
      <div className="h-[211px] bg-[#F8F9FC]">
        {data.cover?.url ? (
          <div className="w-full h-[300px] md:[400px] lg:h-[500px] xl:h-[589px] rounded-[10px] overflow-hidden mb-6">
            <Image
              src={
                data.cover.url.startsWith("http")
                  ? data.cover.url
                  : `http://31.220.18.85:1337${data.cover.url}`
              }
              height={175}
              width={276}
              className="w-full h-full object-center object-cover"
              alt={data.cover.alternativeText || "Blog Cover Image"}
              onError={(e) => (e.currentTarget.src = "/images/placeholder.jpg")}
            />
          </div>
        ) : (
          <div className="w-full h-[300px] md:[400px] lg:h-[500px] xl:h-[589px] rounded-[10px] overflow-hidden mb-6 flex items-center justify-center bg-gray-200">
            <span className="text-gray-500">No Image Available</span>
          </div>
        )}
      </div>
      <div className="py-8 px-6">
        <div className="flex gap-5 items-center text-[#737588] mb-4">
          <div className="flex gap-3 items-center text-[12px] font-[400] leading-[25px]">
            <User />
            <span>{data.author?.name}</span>
          </div>
          <div className="flex gap-3 items-center text-[12px] font-[400] leading-[25px]">
            <FolderOpen />
            <span>{data.category?.name}</span>
          </div>
        </div>
        <h2 className="text-[#040503] text-[18px] lg:text-[20px] 2xl:text-[28px] leading-normal 2xl:leading-[36px] font-bold mb-5 text-truncate-2">
          {capitalizeFirst(data.title)}
        </h2>
        <p className="text-[14px] lg:text-base leading-normal font-medium text-truncate-4">
          {capitalizeFirst(data.description)}
        </p>
        <div className="group flex items-center gap-5 mt-5">
          <LearnMoreIcon className="transition-all delay-100 group-hover:rotate-[30deg]" />
          <span className="group-hover:font-bold transition-all delay-100">
            Learn More
          </span>
        </div>
      </div>
    </Link>
  );
};

export default SingleBlog;