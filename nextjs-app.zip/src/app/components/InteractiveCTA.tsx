// src/app/components/InteractiveCTA.tsx
"use client";
import React from "react";
import Button from "./Button";

export default function InteractiveCTA() {
  const handleClick = () => {
    window.open(
      "https://app.acuityscheduling.com/schedule.php?owner=32088231&calendarID=10026411",
      "_blank",
      "noopener,noreferrer"
    );
  };

  return <Button text="Book a Meeting" onClick={handleClick} className="py-2 lg:py-4 flex-none" />;
}
