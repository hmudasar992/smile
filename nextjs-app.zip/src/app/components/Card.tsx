import React, { ReactNode } from "react";

// ✅ Define props type explicitly
interface CardProps {
  children: ReactNode;
}

const Card: React.FC<CardProps> = ({ children }) => {
  return (
    <div className="border border-[#E3E3E3] rounded-[6px] p-[30px] mb-10">
      {children}
    </div>
  );
};

export default Card;
