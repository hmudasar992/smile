"use client";

import { useEffect, useRef } from "react";
import gsap from "gsap";

const Counter = () => {
  const projectRef = useRef(null);
  const clientRef = useRef(null);
  const supportRef = useRef(null);

  useEffect(() => {
    gsap.fromTo(
      projectRef.current,
      { innerText: 0 },
      {
        innerText: 20, // Target value
        duration: 2,
        snap: { innerText: 1 }, // Ensures whole numbers
        ease: "power1.out",
      }
    );

    gsap.fromTo(
      clientRef.current,
      { innerText: 0 },
      {
        innerText: 10,
        duration: 2.5,
        snap: { innerText: 1 },
        ease: "power1.out",
      }
    );

    gsap.fromTo(
      supportRef.current,
      { innerText: 0 },
      {
        innerText: 95,
        duration: 3,
        snap: { innerText: 1 },
        ease: "power1.out",
      }
    );
  }, []);

  return (
    <div className="my-10 lg:my-20 bg-[#D7A2F4] pt-10 pb-8">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex gap-10 flex-wrap lg:flex-nowrap justify-around">
          <div className="text-center">
            <h2 className="relative text-[59px] md:text-[75px] lg:text-[90px] text-gradient leading-[37px] md:leading-[50px] lg:leading-[70px] font-bold mb-4">
              <span ref={projectRef}>0</span>
              <span className="absolute -top-2 lg:-top-7  -right-4  lg:-right-9 inline-block text-[26px] md:text[42px] lg:text-[67px]">
                +
              </span>
            </h2>
            <p className="text-base md:text-[20px] text-[26px] leading-[30px] font-bold">
              Projects
            </p>
          </div>

          <div className="text-center">
            <h2 className="relative text-[59px] md:text-[75px] lg:text-[90px] text-gradient leading-[37px] md:leading-[50px] lg:leading-[70px] font-bold mb-4">
              <span ref={clientRef}>0</span>
              <span className="absolute -top-2 lg:-top-7  -right-4  lg:-right-9 inline-block text-[26px] md:text[42px] lg:text-[67px]">
                +
              </span>
            </h2>
            <p className="text-base md:text-[20px] text-[26px] leading-[30px] font-bold">
              Clients
            </p>
          </div>

          <div className="text-center">
            <h2 className="relative text-[59px] md:text-[75px] lg:text-[90px] text-gradient leading-[37px] md:leading-[50px] lg:leading-[70px] font-bold mb-4">
              <span ref={supportRef}>0</span>
              <span className="absolute -top-2 lg:-top-7  -right-4  lg:-right-9 inline-block text-[26px] md:text[42px] lg:text-[67px]">
                %
              </span>
            </h2>
            <p className="text-base md:text-[20px] text-[26px] leading-[30px] font-bold">
              24/7 Support
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Counter;
