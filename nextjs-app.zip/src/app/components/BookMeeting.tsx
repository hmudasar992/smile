"use client";
import React from "react";
import LinkTag from "./LinkTag";

const BookMeeting = () => {
  return (
    <section
      id="book-meeting"
      className="py-10 lg:py-16"
      aria-label="Book a Meeting Call-to-Action"
    >
      <div className="container mx-auto px-4 md:px-6">
        <div className="bg-gradient rounded-[14px] p-5 flex flex-wrap lg:flex-nowrap gap-6 items-center justify-center lg:justify-between w-full lg:w-10/12 mx-auto">
          <h2 className="text-white text-[20px] lg:text-[22px] xl:text-[24px] 2xl:text-[28px] font-bold px-3 lg:text-left text-center">
            Ready to scale? Let’s build, rank, and convert—together!
          </h2>
          <LinkTag
            text="Book a Meeting"
            className="py-3 lg:py-4 flex-none"
            path="https://app.acuityscheduling.com/schedule.php?owner=32088231&calendarID=10026411"
          />
        </div>
      </div>
    </section>
  );
};

export default BookMeeting;
