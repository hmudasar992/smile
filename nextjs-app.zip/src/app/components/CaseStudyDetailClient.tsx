"use client";

import React from "react";
import SwiperSlider from "@/app/components/SwiperSlider";
import { SwiperSlide } from "swiper/react";
import { LearnMoreIcon } from "@/app/SVG";
import Image from "next/image";
import Link from "next/link";
import { data } from "../data";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import rehypeRaw from "rehype-raw";
import styles from "@/app/Markdown.module.css";

interface CaseStudy {
  slug: string;
  title: string;
  subTitle: string;
  desc: string;
  image?: string;
  serviceList?: {
    tabTitle: string;
    tabSubTitle: string;
    parentSlug: string;
    slug: string;
  }[];
}

interface CaseStudyDetailClientProps {
  slug: string;
  parentSlug: string;
}

const CaseStudyDetailClient = ({ slug }: CaseStudyDetailClientProps) => {
  // ✅ Use the correct type for `b`
  const caseStudy = data.caseStudyData.find((b: CaseStudy) => b.slug === slug);

  return (
    <div className="case-study">
      <section className="py-16 md:py-18 lg:py-20" aria-label="Service Detail">
        <div className="container mx-auto px-4 md:px-6">
          <div className="mb-6">
            {caseStudy?.image && (
              <div className="inline-block rounded-[10px] overflow-hidden mb-6">
                <Image
                  src={caseStudy?.image || "/images/blogs/52-Blog.jpg"}
                  alt={caseStudy?.title}
                  height={400}
                  width={800}
                  className="max-w-full"
                />
              </div>
            )}
          </div>

          <div className="pb-8">
            <div className="mb-12 w-full lg:w-[75%]">
              <h2 className="text-[24px] lg:text-[30px] 2xl:text-[35px] font-bold leading-[28px] lg:leading-[38px] 2xl:leading-[45px] mb-6">
                {caseStudy?.subTitle}
              </h2>
              <div className={styles.markdownReset}>
                <ReactMarkdown
                  remarkPlugins={[remarkGfm]}
                  rehypePlugins={[rehypeRaw]}
                >
                  {caseStudy?.desc}
                </ReactMarkdown>
              </div>
            </div>
          </div>
        </div>
      </section>

      {caseStudy?.serviceList && caseStudy.serviceList.length > 0 && (
        <section
          className="pb-16 md:pb-18 lg:pb-20"
          aria-label="Related Services"
        >
          <div className="container mx-auto px-4 md:px-6">
            <div className="mb-16">
              <h2 className="text-[28px] md:text-[36px] lg:text-[42px] leading-[60px] font-bold inline-block z-[9]">
                Related Services
              </h2>
            </div>
            <SwiperSlider>
              {caseStudy?.serviceList?.map((data, i) => (
                <SwiperSlide key={i}>
                  <div className="w-full">
                    <div className="group block bg-[#797979] bg-opacity-50 hover:bg-gradient rounded-[14px] border p-[1px] transition-all delay-100">
                      <div className="bg-white shadow-button shadow box rounded-[12px] p-7 relative h-full w-full">
                        <div className="py-4 pe-8">
                          <header className="pb-4">
                            <div className="w-56">
                              <h3 className="inline text-[22px] md:text-[26px] lg:text-[30px] leading-[23px] md:leading-[27px] lg:leading-[36px] bg-[#F4E1FF] group-hover:bg-[#F5F5F7] transition-all ease">
                                {data.tabTitle}
                              </h3>
                            </div>
                          </header>
                          <p className="text-[18px] leading-[23px] font-[400] mb-10">
                            {data.tabSubTitle}
                          </p>
                          <Link
                            href={`/services/${data?.parentSlug}/${data.slug}`}
                            className="group flex items-center gap-5"
                            aria-label={`Learn more about ${data.tabTitle}`}
                            prefetch
                          >
                            <LearnMoreIcon className="transition-all delay-100 group-hover:rotate-[30deg]" />
                            <span className="group-hover:font-bold transition-all delay-100">
                              Learn More
                            </span>
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
              ))}
            </SwiperSlider>
          </div>
        </section>
      )}
    </div>
  );
};

export default CaseStudyDetailClient;
