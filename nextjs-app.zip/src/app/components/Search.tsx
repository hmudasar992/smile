import React from "react";
import Card from "./Card";
import { AngleRight } from "../SVG";

const Search = () => {
  return (
    <Card>
      <form className="flex border border-[#E3E3E3] rounded-[10px] relative overflow-hidden group focus-within:border-[#6BBD45]">
        <input
          type="text"
          className="border-0 h-full w-full py-4 px-5 pr-20 text-[#737588] font-[500] text-[16px] focus:outline-none bg-transparent"
          placeholder="Search for ..."
        />
        <button className="w-[50px] h-[full] bg-gradient flex justify-center items-center absolute right-0 top-0 bottom-0">
          <AngleRight fill="white" />
        </button>
      </form>
    </Card>
  );
};

export default Search;
