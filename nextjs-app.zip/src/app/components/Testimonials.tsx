"use client";
import React from "react";
import Heading from "./Heading";
import Image from "next/image";
import { Star } from "../SVG";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Mousewheel, Navigation } from "swiper/modules";

import "swiper/css";
import "swiper/css/mousewheel";
import "swiper/css/autoplay";
import "swiper/css/navigation";

const testimonialData = [
  {
    userImage: "/images/reviews/janita.png",
    rating: "5.0",
    stars: "5",
    authorName: "Janita",
    designation: "Founder @ Flirty Girl Fashions",
    desc: "IILLest Finds never disappoints every single invitation done for me was wonderful. (via Google Reviews)",
  },
  {
    userImage: "/images/reviews/smart.png",
    rating: "5.0",
    stars: "5",
    authorName: "Mr. Smart Money",
    designation: "",
    desc: "Best front door girl. Very kind and friendly to employees and customers. (via Google Reviews)",
  },
  {
    userImage: "/images/reviews/gavin.jpeg",
    rating: "4.8",
    stars: "5",
    authorName: "Gavin",
    designation: "CTO @ ESpire Tech",
    desc: "We were impressed with their ability to adapt to our changing requirements. (via Freelance Platform)",
  },
];

const Testimonials = () => {
  return (
    <section
      id="testimonials"
      className="py-10 lg:py-16 lg:pb-0"
      aria-label="Testimonials"
    >
      <div className="container mx-auto px-4 md:px-6">
        <header className="w-[800px] max-w-full mb-10 mx-auto text-center">
          <div className="flex flex-wrap lg:flex-nowrap justify-center lg:justify-start gap-10">
            <Heading tag="h2" text="Testimonials" className="flex-none" />
            <p className="mb-5 text-base lg:text-[18px] lg:text-left text-center">
              Hear What Your Neighbors Are Saying: Read Testimonials from
              Satisfied Local Clients About Our Digital Marketing Services.
            </p>
          </div>
        </header>
        <div>
          <Swiper
            modules={[Autoplay, Mousewheel, Navigation]}
            freeMode={true}
            loop={true}
            autoplay={{
              delay: 2000,
              disableOnInteraction: false,
            }}
            navigation
            scrollbar={{ draggable: true }}
            breakpoints={{
              640: { slidesPerView: 1 },
              768: { slidesPerView: 2 },
              1024: { slidesPerView: 3 },
            }}
          >
            {testimonialData.map((data, i) => (
              <SwiperSlide key={i}>
                <article
                  className="group bg-[#EBEAED] hover:bg-gradient hover:shadow-box rounded-[14px] p-[2px] transition-all delay-100"
                  aria-label={`Testimonial from ${data.authorName}`}
                >
                  <div className="bg-white rounded-[12px] p-7 relative h-full w-full">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="text-[24px] text-black font-bold">
                        {data.rating}
                      </div>
                      <div className="flex gap-2">
                        {Array.from({ length: Number(data.stars) }).map(
                          (_, index) => (
                            <span key={index}>
                              <Star />
                            </span>
                          )
                        )}
                      </div>
                    </div>
                    <p className="leading-[30px] text-base font-[400] text-[#425466] mb-4">
                      {data.desc}
                    </p>
                    <footer className="flex gap-3 items-center text-[12px] font-[400] leading-[25px]">
                      <div className="overflow-hidden h-[40px] w-[40px] rounded-full bg-gray-400">
                        <Image
                          src={data.userImage}
                          height={40}
                          width={40}
                          alt={`${data.authorName} profile picture`}
                        />
                      </div>
                      <div>
                        <p className="leading-[20px] text-base font-bold text-[#425466] mb-3">
                          {data.authorName}
                        </p>
                        <p className="leading-[10px] text-[10px] font-[400] text-black">
                          {data.designation}
                        </p>
                      </div>
                    </footer>
                  </div>
                </article>
              </SwiperSlide>
            ))}
          </Swiper>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
