// src/app/utils/imageLoader.js
export default function customImageLoader({ src, width, quality = 75 }) {
  // Local images
  if (src.startsWith('/images/')) {
    return `${src}?w=${width}&q=${quality}`;
  }

  // Absolute URLs from frontend domain
  if (src.includes('iillestfindsagency.com/images/')) {
    return `${src}?w=${width}&q=${quality}`;
  }

  // CMS images with URI encoding
  try {
    const decodedSrc = decodeURIComponent(src);
    const url = new URL(decodedSrc);
    url.searchParams.set('w', width);
    url.searchParams.set('q', quality);
    return url.toString();
  } catch (error) {
    console.error('Error processing image URL:', error);
    return src;
  }
}