// src/app/case-study/CaseStudyListWrapper.tsx
"use client";

import { Suspense } from "react";
import dynamic from "next/dynamic";
import Breadcrumb from "../components/Breadcrumb";

const CaseStudyList = dynamic(() => import("./CaseStudyList"), {
  ssr: false,
  loading: () => <LoadingSkeleton />,
});

function LoadingSkeleton() {
  return (
    <div className="case-study">
      <div>
        {/* Breadcrumb Skeleton */}
        <Breadcrumb loading heading="" slugin="" pageName="" />

        <div className="pt-20 pb-0">
          <div className="container px-6 mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8 lg:gap-10 xl:gap-12 2xl:gap-14 md:justify-center">
              {Array.from({ length: 6 }).map((_, i) => (
                <article
                  key={i}
                  className="p-[20px] md:p-[25px] lg:p-[30px] xl:p-[40px] 2xl:[50px] rounded-[14px] bg-[#F4E1FF] bg-opacity-50 animate-pulse"
                >
                  <div className="group relative">
                    {/* Image Skeleton */}
                    <div className="rounded-[6px] overflow-hidden mb-[20px] relative aspect-video bg-gray-200" />

                    {/* Text Skeleton */}
                    <div className="space-y-2">
                      <div className="h-4 bg-gray-200 rounded w-full" />
                      <div className="h-4 bg-gray-200 rounded w-4/5" />
                      <div className="h-4 bg-gray-200 rounded w-3/4" />
                    </div>

                    {/* Button Skeleton */}
                    <div className="flex items-center gap-5 mt-4">
                      <div className="h-4 bg-gray-200 rounded w-20" />
                      <div className="w-6 h-6 bg-gray-200 rounded-full" />
                    </div>
                  </div>
                </article>
              ))}
            </div>

            {/* Pagination Skeleton */}
            <div className="flex justify-center gap-4 mt-10 animate-pulse">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="h-10 w-10 bg-gray-200 rounded-full" />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function CaseStudyListWrapper() {
  return (
    <Suspense fallback={<LoadingSkeleton />}>
      <CaseStudyList />
    </Suspense>
  );
}
