// src/app/case-study/page.tsx
import type { Metadata } from "next";
import { Suspense } from "react";
import CaseStudyListWrapper from "./CaseStudyListWrapper";

export async function generateMetadata(): Promise<Metadata> {
  return {
    title: "Case Studies | Proven Digital Marketing Success in Phoenix",
    description:
      "Explore real-life case studies showcasing how our digital marketing strategies have transformed businesses in Phoenix. Discover our success stories and measurable results.",
    alternates: {
      canonical: "https://www.iillestfindsagency.com/case-study",
    },
    openGraph: {
      title: "Case Studies | Proven Digital Marketing Success in Phoenix",
      description:
        "Discover how our digital marketing strategies have driven success for Phoenix businesses through detailed case studies.",
      type: "website",
      url: "https://www.iillestfindsagency.com/case-study",
    },
    robots: "index, follow",
  };
}

export default function BlogListPage() {
  return (
    <div className="case-study">
      <Suspense fallback={<div className="container py-20 text-center">Loading case studies...</div>}>
        <CaseStudyListWrapper />
      </Suspense>
    </div>
  );
}