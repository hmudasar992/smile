"use client";

import React, { useState } from "react";
import Breadcrumb from "../components/Breadcrumb";
import { data } from "../data";
import { notFound } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { ChevronRight, TickIcon2 } from "../SVG";

// SEO Metadata export

interface CaseStudy {
  image: string;
  desc: string;
  slug: string;
  title: string;
  summery: string;
}
const CaseStudyList = () => {
  const caseStudy = data.caseStudyData;

  // ✅ Always call hooks at the top level
  const [currentPage, setCurrentPage] = useState(1);
  const caseStudyPerPage = 6;

  // ✅ Handle caseStudy being undefined after hooks are declared
  if (!caseStudy || caseStudy.length === 0) {
    return notFound();
  }

  const indexOfLastBlog = currentPage * caseStudyPerPage;
  const indexOfFirstBlog = indexOfLastBlog - caseStudyPerPage;
  const currentCaseStudies = caseStudy.slice(indexOfFirstBlog, indexOfLastBlog);
  const totalPages = Math.ceil(caseStudy.length / caseStudyPerPage);

  const handlePageChange = (page: number) => {
    if (page > 0 && page <= totalPages) {
      setCurrentPage(page);
    }
  };

  return (
    <div className="case-study">
      <div>
        <Breadcrumb
          heading="Our Case Study"
          slugin="Case Study"
          pageName="Services"
          bgImage="case-study-banner.jpg"
        />
        <div className="pt-20 pb-0">
          <div className="container px-6 mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8 lg:gap-10 xl:gap-12 2xl:gap-14 md:justify-center">
              {currentCaseStudies.map((data: CaseStudy, i: number) => (
                <article key={i} className="p-[20px] md:p-[25px] lg:p-[30px] xl:p-[40px] 2xl:[50px] rounded-[14px] bg-[#F4E1FF] bg-opacity-50 hover:shadow-blog-hover transition-all duration-300">
                  <div className="group relative">
                    <div className="rounded-[6px] overflow-hidden mb-[20px] relative">
                      <Image
                        src={data.image}
                        alt={`Case Study ${i + 1} image`}
                        height={194}
                        width={285}
                        className="h-full w-full object-center object-cover transition-all ease duration-300 group-hover:scale-[1.3]"
                      />
                    </div>
                    <p className="leading-[23px] text-[18px] text-black mb-4 text-truncate-4 h-[92px]">
                      {data.summery}
                    </p>
                    <footer>
                      <Link href={`/case-study/${data.slug}`} className="group flex items-center gap-5">
                        <span>Learn More</span>
                        <TickIcon2 className="transition-all delay-100 group-hover:rotate-[30deg]" />
                      </Link>
                    </footer>
                  </div>
                </article>
              ))}
            </div>
            
            {/* Pagination */}
            {currentCaseStudies.length > caseStudyPerPage && (
              <div className="pagination flex justify-center items-center mt-10 gap-4">
                <button
                  onClick={() => handlePageChange(currentPage - 1)}
                  className={`flex items-center justify-center rounded bg-[#F8F9FC] lg:h-[40px] lg:w-[40px] h-[30px] w-[30px] transition-all group ${
                    currentPage === 1 ? "opacity-50 cursor-not-allowed hidden" : "hover:bg-gradient hover:text-white"
                  }`}
                >
                  <ChevronRight fill={currentPage === 1 ? "#000" : "currentColor"} className="rotate-180 group-hover:fill-white" />
                </button>
                
                {Array.from({ length: totalPages }, (_, index) => {
                  if (index === 0 || index === totalPages - 1 || (index >= currentPage - 2 && index <= currentPage)) {
                    return (
                      <button
                        key={index}
                        onClick={() => handlePageChange(index + 1)}
                        className={`flex items-center justify-center rounded lg:h-[40px] lg:w-[40px] h-[30px] w-[30px] transition-all ${
                          currentPage === index + 1 ? "bg-gradient text-white" : "hover:bg-gradient hover:text-white"
                        }`}
                      >
                        {index + 1}
                      </button>
                    );
                  }
                  if ((index === currentPage - 3 && index !== 0) || (index === currentPage + 2 && index !== totalPages - 1)) {
                    return <span key={index} className="flex items-center justify-center lg:h-[40px] lg:w-[40px] h-[30px] w-[30px]">...</span>;
                  }
                  return null;
                })}
                
                <button
                  onClick={() => handlePageChange(currentPage + 1)}
                  className={`flex items-center justify-center rounded bg-[#F8F9FC] lg:h-[40px] lg:w-[40px] h-[30px] w-[30px] group transition-all ${
                    currentPage === totalPages ? "opacity-50 cursor-not-allowed hidden" : "hover:bg-gradient hover:text-white"
                  }`}
                >
                  <ChevronRight fill={currentPage === totalPages ? "#000" : "currentColor"} className="group-hover:fill-white" />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CaseStudyList;

