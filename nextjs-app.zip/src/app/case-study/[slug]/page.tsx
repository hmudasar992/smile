import type { Metadata } from "next";
import { data } from "../../data";
import CaseStudyDetailClient from "@/app/components/CaseStudyDetailClient";
import BreadcrumbWrapper from "@/app/components/BreadcrumbWrapper"; // ✅ Import the breadcrumb wrapper

interface CaseStudy {
  slug: string;
  title: string;
  metaTitle: string;
  metaDescription: string;
}

// Remove CaseStudyPageProps interface and use page props directly
export async function generateMetadata({ 
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const resolvedParams = await params;
  const { slug } = resolvedParams;

  const caseStudy = data.caseStudyData.find((b: CaseStudy) => b?.slug === slug);

  if (!caseStudy) {
    return {
      title: "Case Study Not Found",
      description: "The case study you are looking for does not exist.",
    };
  }

  return {
    title: caseStudy.metaTitle,
    description: caseStudy.metaDescription,
    alternates: {
      canonical: `https://www.iillestfindsagency.com/case-study/${caseStudy.slug}`,
    },
    openGraph: {
      title: caseStudy.metaTitle,
      description: caseStudy.metaDescription,
      url: `https://www.iillestfindsagency.com/case-study/${caseStudy.slug}`,
      type: "article",
    },
    robots: "index, follow",
  };
}

// ✅ Ensure params are awaited properly and fetch `caseStudy.title`
export default async function CaseStudyPage({ 
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const resolvedParams = await params;
  const { slug } = resolvedParams;

  // ✅ Fetch the case study data
  const caseStudy = data.caseStudyData.find((b: CaseStudy) => b?.slug === slug);

  return (
    <div>
      {/* ✅ Pass `caseStudy?.title` to Breadcrumb */}
      <BreadcrumbWrapper
        heading="Case Study"
        slugin={caseStudy?.title || "Unknown Case Study"} // ✅ This will now show the title in Breadcrumb
        pageName="Case Study"
        bgImage="case-study-banner.jpg"
      />

      {/* ✅ Render the case study detail */}
      <CaseStudyDetailClient slug={slug} parentSlug="" />
    </div>
  );
}
