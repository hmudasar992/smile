"use client";

import React, { useState } from "react";
import Breadcrumb from "../components/Breadcrumb";
import ProgressiveImage from "../components/ProgressiveImage";
import { notFound } from "next/navigation";
import Image from "next/image";
import { ChevronRight, FolderOpen, LearnMoreIcon, User } from "../SVG";
import Link from "next/link";
import Search from "../components/Search";
import BlogsCategory from "../components/BlogsCategories";
import Tags from "../components/Tags";
import { capitalizeFirst } from "../utils/constent";
import type { BlogPost, BlogListProps } from "../types/blog";

export function BlogListClient({ initialPosts }: BlogListProps) {
  const [blogs] = useState<BlogPost[]>(initialPosts);
  const [currentPage, setCurrentPage] = useState(1);
  const blogsPerPage = 4;
  const totalPages = Math.ceil(blogs.length / blogsPerPage);
  const currentBlogs = blogs.slice(
    (currentPage - 1) * blogsPerPage,
    currentPage * blogsPerPage
  );

  const handlePageChange = (page: number) => {
    if (page > 0 && page <= totalPages) {
      setCurrentPage(page);
    }
  };

  if (!blogs.length) return notFound();

  return (
    <div className="blogs">
      {/* Breadcrumb - Becomes skeleton when loading */}
      <Breadcrumb
        heading="Expert Insights & Growth Strategies"
        slugin="Blogs"
        pageName="Blogs"
        bgImage="case-study-banner.jpg"
      />

      <div className="py-16 md:py-18 lg:py-20 pb-0">
        <div className="container px-6 mx-auto">
          <div className="flex gap-10 flex-wrap lg:flex-nowrap">
            {/* Main Content */}
            <div className="w-full lg:w-9/12 relative">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
                {currentBlogs.map((data, i) => (
                  <Link
                    href={`/blog/${data.slug}`}
                    key={i}
                    className="group overflow-hidden rounded-[15px] shadow-custom"
                    prefetch
                  >
                    <div className="bg-[#F8F9FC]">
                      {data?.cover?.url ? (
                        <ProgressiveImage
                          src={
                            data.cover.url.startsWith("http")
                              ? data.cover.url
                              : `https://admin.iillestfindsagency.com${data.cover.url}`
                          }
                          height={175}
                          width={276}
                          className="w-full h-auto"
                          alt={`Image for ${
                            data.cover.alternativeText || "blog cover"
                          }`}
                          onError={(e) => {
                            (e.target as HTMLImageElement).src =
                              "/images/related-blog-1.jpg";
                          }}
                        />
                      ) : (
                        <div className="relative aspect-[276/175] w-full">
                          <Image
                            src="/images/related-blog-1.jpg"
                            fill
                            className="object-cover"
                            alt="Fallback blog cover"
                            sizes="(max-width: 768px) 100vw, 276px"
                          />
                        </div>
                      )}
                    </div>

                    <div className="py-8 px-6">
                      <div className="flex gap-5 items-center text-[#737588] mb-4">
                        <div className="flex gap-3 items-center text-[12px] font-[400] leading-[25px]">
                          <User />
                          <span>{data.author?.name}</span>
                        </div>
                        <div className="flex gap-3 items-center text-[12px] font-[400] leading-[25px]">
                          <FolderOpen />
                          <span>{data.category?.name}</span>
                        </div>
                      </div>

                      <h2 className="text-[#040503] text-[18px] lg:text-[20px] 2xl:text-[28px] leading-normal 2xl:leading-[36px] font-bold mb-5 text-truncate-2">
                        {capitalizeFirst(data.title)}
                      </h2>

                      <p className="text-[14px] lg:text-base leading-normal font-medium text-truncate-4">
                        {capitalizeFirst(data.description)}
                      </p>

                      <div className="group flex items-center gap-5 mt-5">
                        <LearnMoreIcon className="transition-all delay-100 group-hover:rotate-[30deg]" />
                        <span className="group-hover:font-bold transition-all delay-100">
                          Learn More
                        </span>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="pagination flex justify-center items-center mt-10 gap-4">
                  <button
                    onClick={() => handlePageChange(currentPage - 1)}
                    disabled={currentPage === 1}
                    className="flex items-center justify-center rounded bg-[#F8F9FC] lg:h-10 lg:w-10 h-8 w-8 transition-all hover:bg-gradient hover:text-white disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <ChevronRight className="rotate-180" />
                  </button>

                  {Array.from({ length: totalPages }, (_, index) => (
                    <button
                      key={index}
                      onClick={() => handlePageChange(index + 1)}
                      className={`flex items-center justify-center rounded lg:h-10 lg:w-10 h-8 w-8 transition-all ${
                        currentPage === index + 1
                          ? "bg-gradient text-white"
                          : "hover:bg-gradient hover:text-white"
                      }`}
                    >
                      {index + 1}
                    </button>
                  ))}

                  <button
                    onClick={() => handlePageChange(currentPage + 1)}
                    disabled={currentPage === totalPages}
                    className="flex items-center justify-center rounded bg-[#F8F9FC] lg:h-10 lg:w-10 h-8 w-8 transition-all hover:bg-gradient hover:text-white disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <ChevronRight />
                  </button>
                </div>
              )}
            </div>

            {/* Sidebar */}
            <div className="w-full lg:w-3/12 space-y-8">
              <Search />
              <BlogsCategory props={blogs} />
              <Tags props={blogs} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default BlogListClient;
