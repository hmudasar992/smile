"use client";

import { useState, useEffect } from "react";
import Breadcrumb from "@/app/components/Breadcrumb";
import { FolderOpen, User } from "@/app/SVG";
import { apiURL, authToken } from "@/app/utils/constent";
import axios from "axios";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import rehypeRaw from "rehype-raw";
import styles from "@/app/Markdown.module.css";
import RelatedBlogsSlider from "@/app/components/RelatedBlogsSlider";
import ProgressiveImage from "../../components/ProgressiveImage";
import Loading from "./loading";
import { useParams } from "next/navigation";

interface Blog {
  title: string;
  cover?: {
    url: string;
    alternativeText: string;
  };
  description: string;
  author?: {
    name: string;
    updatedAt: string;
  };
  slug: string;
  category: { name: string };
  seo: {
    metaTitle: string;
    metaDescription: string;
  };
  body: string;
  hashTags: string;
  related_articles?: Array<{
    title: string;
    slug: string;
    description: string;
    cover?: {
      url: string;
      alternativeText: string;
    };
    body: string;
    author?: {
      name: string;
      updatedAt: string;
    };
    category: { name: string };
  }>;
}

export default function BlogDetail() {
  const params = useParams(); // Unwrap params using useParams
  const slug = params?.slug as string;
  const [blog, setBlog] = useState<Blog | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!slug) return;

    async function fetchBlogData() {
      try {
        const response = await axios.get<{ data: Blog[] }>(
          `${apiURL}/articles?populate=*`,
          {
            headers: { Authorization: `Bearer ${authToken}` },
          }
        );
        const blogs = response.data.data;
        const foundBlog = blogs.find((b: Blog) => b.slug === slug) || null;
        setBlog(foundBlog);
      } catch (error) {
        console.error("Error fetching blog:", error);
      } finally {
        setLoading(false);
      }
    }

    fetchBlogData();
  }, [slug]);

  if (loading) {
    return <Loading />;
  }

  if (!blog) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p className="text-lg font-medium text-red-500">Blog not found</p>
      </div>
    );
  }

  return (
    <div className="services">
      <Breadcrumb
        heading="Blog"
        slugin={blog.title}
        pageName="Blog"
        bgImage="case-study-banner.jpg"
        detailPage
      />
      <div className="py-16">
        <div className="container mx-auto px-4 md:px-6">
          <div className="border border-[#E3E3E3] rounded-[10px] p-4">
            <div className="mb-6">
              {blog.cover?.url && (
                <div className="w-full h-full rounded-[10px] overflow-hidden mb-6">
                  <ProgressiveImage
                    src={
                      blog.cover.url.startsWith("http")
                        ? blog.cover.url
                        : `https://admin.iillestfindsagency.com${blog.cover.url}`
                    }
                    height={175}
                    width={276}
                    className="max-w-full max-h-full"
                    alt={`Image for ${blog.cover.alternativeText}`}
                  />
                </div>
              )}
            </div>
            <div className="flex gap-5 items-center text-[#737588] mb-4">
              <div className="flex gap-3 items-center">
                <User />
                <span>{blog.author?.name}</span>
              </div>
              <div className="flex gap-3 items-center">
                <FolderOpen />
                <span>{blog.category.name}</span>
              </div>
            </div>
            {blog.body && (
              <div className="pb-10">
                <div className={styles.markdownReset}>
                  <ReactMarkdown
                    remarkPlugins={[remarkGfm]}
                    rehypePlugins={[rehypeRaw]}
                  >
                    {blog.body}
                  </ReactMarkdown>
                </div>
              </div>
            )}
          </div>
          <div className="py-16 md:py-18 lg:py-20">
            <div className="container mx-auto px-4 md:px-6">
              <div className="mb-16">
                <h2 className="text-[28px] md:text-[36px] lg:text-[42px] leading-[60px] font-bold inline-block z-[9]">
                  Related Blogs
                </h2>
              </div>
              <RelatedBlogsSlider relatedBlogs={blog.related_articles || []} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
