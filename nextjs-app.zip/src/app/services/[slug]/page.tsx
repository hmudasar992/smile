import type { Metadata } from "next";
import Breadcrumb from "@/app/components/Breadcrumb";
import Link from "next/link";
import { LearnMoreIcon } from "@/app/SVG";
import { data as staticData } from "../../data"; // Adjust the path if needed
import { notFound } from "next/navigation";
import Button from "@/app/components/Button";
import Image from "next/image";
import Counter from "@/app/components/Counter";
import FAQs from "@/app/components/FAQs";
import InteractiveCTA from "@/app/components/InteractiveCTA"; // Client Component for interactivity

// Dynamic metadata generation for this service page
export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const resolvedParams = await params;
  const { slug } = resolvedParams;
  const service = staticData.services.find((s) => s.slug === slug);
  if (!service) {
    return {
      title: "Service Not Found",
      description: "The requested service was not found.",
    };
  }
  return {
    title: service.metaTitle,
    description: service.metaDescription,
    alternates: {
      canonical: `https://www.iillestfindsagency.com/services/${service.slug}`,
    },
    openGraph: {
      title: service.metaTitle,
      description: service.metaDescription,
      url: `https://www.iillestfindsagency.com/services/${service.slug}`,
      type: "website",
    },
  };
}

interface Service {
  metaTitle: string;
  metaDescription: string;
  slug: string;
  tabTitle: string;
  tabDescription: string;
  title: string;
  subTitle: string;
  icon: string;
  image: string;
  aboutTitle: string;
  aboutService: string;
  keyBenefits: string[];
  cta: string;
  serviceList: {
    tabTitle: string;
    tabSubTitle: string;
    slug: string;
  }[];
  faqs: {
    title: string;
    shortDesc: string;
    faqList: {
      heading: string;
      description: string;
    }[];
  };
}

export default async function ServicePage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const resolvedParams = await params;
  const { slug } = resolvedParams;
  const service: Service | undefined = staticData.services.find(
    (s) => s.slug === slug
  );
  if (!service) {
    return notFound();
  }

  return (
    <div>
      <Breadcrumb
        heading={service.title}
        slugin={service.subTitle}
        pageName="Services"
        bgImage={
          service.title === "SEO Services Phoenix"
            ? "services/banners/SEO.jpg"
            : service.title === "Social Media Marketing Phoenix"
            ? "services/banners/SOCIAL-01.jpg"
            : service.title === "Website Development Phoenix"
            ? "services/banners/WEB-01.jpg"
            : "service-bg.jpg"
        }
      />

      {/* Service Tabs Section */}
      <section className="py-16 md:py-18 lg:py-20">
        <div className="container px-6 mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 lg:gap-8 xl:gap-10 2xl:gap-16 md:justify-center">
            {service?.serviceList?.map((data, i) => (
              <article
                className="w-full"
                key={i}
                aria-label={`Service: ${data.tabTitle}`}
              >
                <div className="group block bg-white hover:bg-gradient rounded-[14px] shadow-button shadow-box p-[2px] transition-all delay-100">
                  <div className="bg-white rounded-[12px] p-7 relative h-full w-full">
                    <div className="py-4 pe-8">
                      <header className="pb-4">
                        <div className="w-56">
                          <h3 className="inline text-[22px] md:text-[26px] lg:text-[30px] leading-[23px] md:leading-[27px] lg:leading-[36px] bg-[#F4E1FF] group-hover:bg-[#F5F5F7] transition-all ease">
                            {data.tabTitle}
                          </h3>
                        </div>
                      </header>
                      <p className="text-[14px] lg:text-base 2xl:text-[14px] lg:text-base leading-normal font-medium text-truncate-4 mb-10">
                        {data.tabSubTitle}
                      </p>
                      <footer>
                        <Link
                          href={`/services/${service.slug}/${data.slug}`}
                          className="group flex items-center gap-5"
                          aria-label={`Learn more about ${data.tabTitle}`}
                          prefetch
                        >
                          <LearnMoreIcon className="transition-all delay-100 group-hover:rotate-[30deg]" />
                          <span className="group-hover:font-bold transition-all delay-100">
                            Learn More
                          </span>
                        </Link>
                      </footer>
                    </div>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient" aria-label="Call to Action">
        <div className="container mx-auto px-4 md:px-6">
          <div className="py-14 flex flex-wrap lg:flex-nowrap gap-6 items-center justify-center lg:justify-between">
            <h2 className="text-white lg:text-left text-center text-[24px] lg:text-[35px] font-bold px-3">
              Got a Project in Mind? Let’s Make It Happen!
            </h2>
            <InteractiveCTA />
          </div>
        </div>
      </section>

      {/* About Service Section */}
      <section className="py-16 md:py-18 lg:py-20" aria-label="About Service">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            <div>
              <Image
                src={service.image || "/default-image.jpg"}
                alt={service.title}
                height={432}
                width={518}
                className="object-cover"
              />
            </div>
            <div>
              <header>
                <h1 className="text-[#040503] text-[24px] lg:text-[35px] font-bold mb-5">
                  {service.title}
                </h1>
                <h2 className="text-[28px] font-bold mb-4">
                  {service.aboutTitle}
                </h2>
              </header>
              <p className="text-[20px] leading-[34px] font-medium mb-5">
                {service.aboutService}
              </p>
              <ul className="mb-5 list-disc pl-5">
                {service.keyBenefits?.map((point, index) => (
                  <li key={index} className="text-[16px] leading-[26px]">
                    {point}
                  </li>
                ))}
              </ul>
              <footer>
                <p className="text-[18px] leading-[28px] font-bold mb-4">
                  {service.cta}
                </p>
                <Button text="Let's Dive into Your Project" varient="primary" />
              </footer>
            </div>
          </div>
        </div>
      </section>

      <Counter />
      {service.faqs && <FAQs faqs={service.faqs} />}
    </div>
  );
}
