import type { Metadata } from "next";
import Breadcrumb from "@/app/components/Breadcrumb";
import Button from "@/app/components/Button";
import { data } from "@/app/data";
import { AngleRightColor, DoubleChevronRight } from "@/app/SVG";
import Image from "next/image";
import Link from "next/link";
import React from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import rehypeRaw from "rehype-raw";
import styles from "@/app/Markdown.module.css";
import RelatedServicesSlider from "@/app/components/RelatedServicesSlider";

interface ServiceDetail {
  title: string;
  slug: string;
  detail: {
    title: string;
    subTitle?: string;
    metaTitle?: string;
    metaDescription?: string;
    image?: string;
    onPage: string;
  };
}

interface Service {
  title: string;
  slug: string;
  serviceList: ServiceDetail[];
}

// Use Next.js 13's Metadata API for SEO
export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string; detailSlug: string }>;
}): Promise<Metadata> {
  const resolvedParams = await params;
  const { slug, detailSlug } = resolvedParams;
  const services = data.services as unknown as Service[];
  const service = services.find((b: Service) => String(b?.slug) === slug);
  const singleService = service?.serviceList.find(
    (item: ServiceDetail) => String(item?.slug) === detailSlug
  );
  const content = singleService?.detail;

  const metaTitle = content?.metaTitle || "Service Page";
  const metaDescription = content?.metaDescription || "";
  const canonicalUrl = `https://www.iillestfindsagency.com/${
    service?.slug || ""
  }`;

  return {
    title: metaTitle,
    description: metaDescription,
    alternates: {
      canonical: canonicalUrl,
    },
    openGraph: {
      title: metaTitle,
      description: metaDescription,
      url: canonicalUrl,
      type: "website",
    },
  };
}

export default async function ServiceDetail({
  params,
}: {
  params: Promise<{ slug: string; detailSlug: string }>;
}) {
  const resolvedParams = await params;
  const { slug, detailSlug } = resolvedParams;
  const services = data.services as unknown as Service[];
  const service = services.find((b: Service) => String(b?.slug) === slug);
  const singleService = service?.serviceList.find(
    (item: ServiceDetail) => String(item?.slug) === detailSlug
  );
  const content = singleService?.detail;

  return (
    <div>
      <Breadcrumb
        heading={content?.title || ""}
        slugin={content?.subTitle || ""}
        pageName="Services"
        detailPage
        bgImage={
          service?.title === "SEO Services Phoenix"
            ? "services/banners/SEO.jpg"
            : service?.title === "Social Media Marketing Phoenix"
            ? "services/banners/SOCIAL-01.jpg"
            : service?.title === "Website Development Phoenix"
            ? "services/banners/WEB-01.jpg"
            : "service-bg.jpg"
        }
      />

      {/* Detail Content Section */}
      <section className="pt-16 md:pt-18 lg:pt-20" aria-label="Service Detail">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-wrap lg:flex-nowrap gap-10">
            <div className="w-full lg:w-8/12">
              {singleService?.detail?.image && (
                <div className="w-full h-[411px] rounded-[10px] overflow-hidden">
                  <Image
                    src={
                      singleService?.detail?.image ||
                      "/images/blogs/52-Blog.jpg"
                    }
                    alt={singleService?.detail?.title}
                    height={400}
                    width={800}
                    className="h-full w-full object-cover object-center"
                  />
                </div>
              )}
              {content && (
                <div className="py-10 lg:py-16">
                  <div className={styles.markdownReset}>
                    <ReactMarkdown
                      remarkPlugins={[remarkGfm]}
                      rehypePlugins={[rehypeRaw]}
                    >
                      {content.onPage}
                    </ReactMarkdown>
                  </div>
                </div>
              )}
            </div>
            <aside className="w-full lg:w-4/12">
              <div className="bg-[#F5F5F7] py-[30px] px-[20px] rounded-[10px] mb-6">
                <div className="flex items-center gap-4 mb-[20px]">
                  <AngleRightColor />
                  <h4 className="text-[20px] leading-[26px] text-[#1C1C1C] font-bold">
                    All Service Lists
                  </h4>
                </div>
                <ul>
                  {services.map((list, i) => (
                    <li
                      key={i}
                      className="group hover:border-0 [&:not(:last-child)]:border-b border-[#e3e3e3]"
                    >
                      <Link
                        href={`/services/${list.slug}`}
                        className="hover:bg-gradient hover:text-white rounded-[10px] text-[#737588] block text-base font-bold leading-[25px] py-[10px] px-[20px] transition-all duration-300 ease"
                        prefetch
                      >
                        {list.title}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="relative mb-14">
                <div className="overflow-hidden rounded-[10px] w-full">
                  <Image
                    src="/images/company.jpg"
                    alt="Our Company"
                    height={370}
                    width={410}
                    className="w-full h-full object-center object-cover"
                  />
                </div>
                <div className="absolute -bottom-5 left-0 right-0 flex justify-center items-center">
                  <a
                    href="#"
                    className="bg-gradient text-white text-[14px] inline-flex items-center justify-center py-4 px-[50px] rounded-[10px]"
                  >
                    Discover Our Company +
                  </a>
                </div>
              </div>
              <div className="bg-[#F5F5F7] py-[30px] px-[20px] rounded-[10px] mb-6">
                <div className="flex items-center gap-4 mb-[20px]">
                  <AngleRightColor />
                  <h4 className="text-[20px] leading-[26px] text-[#1C1C1C] font-bold">
                    Download
                  </h4>
                </div>
                <a
                  href=""
                  className="group relative bg-white rounded-[10px] flex items-center justify-between text-base font-bold leading-[28px] py-[10px] px-[20px] transition-all duration-300 ease"
                >
                  <span className="group-hover:gradient-text text-[#737588] block">
                    Company Profile
                  </span>
                  <span className="flex items-center justify-center h-[30px] w-[30px] rounded-full bg-[#806DF4] bg-opacity-20">
                    <DoubleChevronRight />
                  </span>
                </a>
              </div>
            </aside>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient" aria-label="Call to Action">
        <div className="container mx-auto px-4 md:px-6">
          <div className="py-14 flex flex-wrap lg:flex-nowrap gap-16 md:gap-20 lg:gap-24 items-center justify-center lg:justify-between">
            <h2 className="text-white lg:text-left text-center text-[24px] lg:text-[35px] font-bold px-3">
              Would you like recommendations for Off-Page SEO tools or specific
              strategies for your website?
            </h2>
            <Button
              text="Contact Us Now!"
              className="py-2 lg:py-4 flex-none"
              path="/contact-us"
            />
          </div>
        </div>
      </section>

      {/* Related Services Section */}
      <section
        className="py-16 md:py-18 lg:py-20"
        aria-label="Related Services"
      >
        <div className="container mx-auto px-4 md:px-6">
          <div className="mb-16">
            <h2 className="text-[24px] md:text-[36px] lg:text-[42px] 2xl:text-[50px] leading-[64px] font-bold inline-block z-[9]">
              Related Services
            </h2>
          </div>
          {service && (
            <RelatedServicesSlider
              serviceSlug={service.slug}
              serviceList={service.serviceList.map((item) => ({
                tabTitle: item.detail.title,
                tabSubTitle: item.detail.subTitle || "",
                slug: item.slug,
              }))}
            />
          )}
        </div>
      </section>
    </div>
  );
}
