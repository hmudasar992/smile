// src/app/services/page.tsx
import type { Metadata } from "next";
import Breadcrumb from "../components/Breadcrumb";
import Link from "next/link";
import { LearnMoreIcon } from "../SVG";
import { data as staticData } from "../data";

// interface Service {
//   metaTitle: string;
//   metaDescription: string;
//   slug: string;
//   tabTitle: string;
//   tabDescription: string;
//   title: string;
//   subTitle: string;
//   icon: string;
//   image: string;
//   aboutTitle: string;
//   aboutService: string;
//   keyBenefits: string[];
//   cta: string;
//   serviceList: {
//     tabTitle: string;
//     tabSubTitle: string;
//     slug: string;
//   }[];
//   faqs: {
//     title: string;
//     shortDesc: string;
//     faqList: {
//       heading: string;
//       description: string;
//     }[];
//   };
// }



// Export page-specific metadata (Server Component)
export const metadata: Metadata = {
  title: "Our Services | Digital Marketing & Web Development Phoenix",
  description:
    "Explore our range of digital marketing and web development services in Phoenix. From SEO to social media marketing, we provide tailored solutions to grow your business.",
  alternates: {
    canonical: "https://www.iillestfindsagency.com/services",
  },
  openGraph: {
    title: "Our Services | Digital Marketing & Web Development Phoenix",
    description:
      "Explore our range of digital marketing and web development services in Phoenix. Discover tailored solutions for your business success.",
    url: "https://www.iillestfindsagency.com/services",
    type: "website",
  },
};

export default function Services() {
  const services = staticData?.services || [];

  if (!services.length) {
    return (
      <p className="text-center text-[24px] text-gray-500">
        No services found.
      </p>
    );
  }

  return (
    <div className="services">
      <Breadcrumb
        heading="Our Services"
        slugin="Services"
        pageName="Services"
      />
      <div className="pt-20 pb-0">
        <div className="container px-6 mx-auto">
          {services.map((service, i) => (
            <div key={i} className="pb-20">
              <h2 className="text-[#040503] text-[24px] lg:text-[35px] font-bold mb-5">
                {service.title}
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 lg:gap-8 xl:gap-10 2xl:gap-16 md:justify-center">
                {service?.serviceList?.map((data, index) => (
                  <div className="w-full" key={index}>
                    <div className="group block bg-white hover:bg-gradient rounded-[14px] shadow-button shadow-box p-[2px] transition-all delay-100">
                      <div className="bg-white shadow-button shadow-box rounded-[12px] p-7 relative h-full w-full">
                        <div className="py-4 pe-8">
                          <div className="pb-4">
                            <div className="w-56">
                              <h3 className="inline text-[18px] md:text-[20px] lg:text-[22px] xl:text-[26px] 2xl:text-[30px] leading-[23px] md:leading-[27px] lg:leading-[32px] bg-[#F4E1FF] group-hover:bg-[#F5F5F7] transition-all ease">
                                {data.tabTitle}
                              </h3>
                            </div>
                          </div>
                          <p className="text-[14px] lg:text-base 2xl:text-[14px] lg:text-base leading-normal font-medium text-truncate-4 mb-10">
                            {data.tabSubTitle}
                          </p>
                          <Link
                            href={`/services/${service.slug}/${data.slug}`}
                            className="group flex items-center gap-5"
                            prefetch
                          >
                            <LearnMoreIcon className="transition-all delay-100 group-hover:rotate-[30deg]" />
                            <span className="group-hover:font-bold transition-all delay-100">
                              Learn More
                            </span>
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
