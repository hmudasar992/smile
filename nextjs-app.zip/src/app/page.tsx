// app/page.tsx
// "Digital Marketing Agency Phoenix | SEO, Social Media & Web Design"
{/* <title>Digital Marketing Agency Phoenix | SEO & Social Media | iillestfinds</title> */}
// "Top-rated Phoenix digital marketing agency: Drive growth with expert SEO, social media, & web development. Free consultation today! | iillestfinds"
export const metadata = {
  title: "Digital Marketing Agency Phoenix | iillest finds – Faeezah Lun",
  description:
    "Looking for a top digital marketing agency in Phoenix, AZ? At Iillest Finds Agency, Faeezah Lun and his team specialize in SEO, social media marketing, and website development to boost your online success. Get your free quote today!",
  alternates: {
    canonical: "https://www.iillestfindsagency.com/",
  },
  openGraph: {
    title: "Digital Marketing Agency Phoenix | iillestfindsagency.com",
    description:
      "Looking for a top digital marketing agency in Phoenix, AZ? At Iillest Finds Agency, Faeezah Lun and his team specialize in SEO, social media marketing, and website development to boost your online success. Get your free quote today!",
    url: "https://www.iillestfindsagency.com/",
    type: "website",
  },
};

import Banner from "./components/Banner";
import AboutUs from "./components/AboutUs";
import BookMeeting from "./components/BookMeeting";
import OurServices from "./components/OurServices";
// import Clients from "./components/Clients";
import Pricing from "./components/Pricing";
import CaseStudy from "./components/CaseStudy";
import Testimonials from "./components/Testimonials";
import FAQs from "./components/FAQs";
import Blogs from "./components/Blogs";
import { data } from "./data";

export default function Home() {
  const faqsData = data.faqs;
  return (
    <div className="bg-white" id="home">
      <Banner />
      <AboutUs />
      <BookMeeting />
      <OurServices />
      {/* <Clients /> */}
      <Pricing />
      <CaseStudy />
      <Testimonials />
      <FAQs faqs={faqsData} />
      <Blogs />
    </div>
  );
}
