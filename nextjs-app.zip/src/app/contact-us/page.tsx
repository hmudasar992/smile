// ContactUs.tsx
import type { Metadata } from "next";
import React from "react";
import Breadcrumb from "../components/Breadcrumb";
import Image from "next/image";
import {
  CallIcon,
  Facebook,
  Instagram,
  Tiktok,
  UserName,
  YourEmail,
} from "../SVG";
import Button from "../components/Button";

export const metadata: Metadata = {
  title: "Contact Us | Digital Marketing Agency Phoenix",
  description:
    "Get in touch with iillest finds agency, your local digital marketing partner in Phoenix, AZ. Contact us today for expert SEO, social media, and website development solutions.",
  alternates: {
    canonical: "https://www.iillestfindsagency.com/contact-us",
  },
  openGraph: {
    title: "Contact Us | Digital Marketing Agency Phoenix",
    description:
      "Reach out to iillestfindsagency.com, your trusted digital marketing partner in Phoenix. Let&rsquo;s work together to elevate your online presence.",
    url: "https://www.iillestfindsagency.com/contact-us",
    type: "website",
  },
  robots: "index, follow",
};

const contactUsData = [
  {
    name: "Call us",
    link: "925-818-4494",
    icon: "/images/icons/call-us.svg",
  },
  {
    name: "Make a quote",
    link: "faeezahlun@iillestfinds.com",
    icon: "/images/icons/make-email.svg",
  },
  {
    name: "Location",
    link: "Scottsdale, Greater Phoenix Area, Maricopa County, Arizona, USA",
    icon: "/images/icons/get-location.svg",
  },
];

const socialLinks = [
  {
    icon: <Facebook />,
    path: "https://www.facebook.com/share/1AEuGAPGKZ",
  },
  {
    icon: <Instagram />,
    path: "https://www.instagram.com/iillestfinds",
  },
  {
    icon: <Tiktok />,
    path: "https://www.tiktok.com/@faeezahlun",
  },
];

const ContactUs = () => {
  return (
    <div>
      <Breadcrumb
  slugin="Let&rsquo;s Connect & Create Something Amazing"
  heading="Contact"
  pageName="Contact"
  bgImage="contact-us-banner.jpg"
/>
      <div className="py-16 md:py-18 lg:py-20 mb-0">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-wrap lg:flex-nowrap gap-10 lg:gap-12 xl:gap-16 2xl:gap-20">
            <div className="w-full lg:w-5/12">
              <div className="bg-gradient rounded-[10px] h-full px-6 py-4 2xl:py-8">
                <h2 className="font-bold text-[24px] lg:text-[30px] leading-[65px] text-white">
                  Contact Information
                </h2>
                <p className="text-base leading-[28px] text-white">
                  Reach out to us for tailored digital marketing solutions
                  designed to drive growth in Phoenix. Our expert team is ready
                  to provide personalized support for your unique needs. Let’s
                  connect and bring your vision to life!
                </p>
                <div className="py-6">
                  {contactUsData.map((data, i) => (
                    <div className="flex gap-6 items-center mb-4" key={i}>
                      <div className="h-[50px] w-[50px] lg:h-[60px] lg:w-[60px] 2xl:h-[70px] 2xl:w-[70px] bg-white rounded-[50%] p-1 flex-none">
                        <div className="w-full h-full rounded-[50%] border-[#40254F] border border-dashed flex items-center justify-center">
                          <Image
                            src={data.icon}
                            alt={data.name}
                            height={30}
                            width={30}
                          />
                        </div>
                      </div>
                      <div>
                        <h2 className="font-bold text-[18px] lg:text-[20px] 2xl:text-[24px] leading-[32px] text-white">
                          {data.name}
                        </h2>
                        <a
                          href={
                            data.name === "Call us"
                              ? `tel:9258184494`
                              : data.name === "Make a quote"
                              ? `mailto:${data.link}`
                              : ""
                          }
                          className="block text-[12px] lg:text-[14px] 2xl:text-base leading-[32px] text-white"
                        >
                          {data.link}
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
                <h2 className="font-bold text-[24px] lg:text-[30px] leading-[65px] text-white">
                  Follow Social
                </h2>
                <nav aria-label="Social Media Links">
                  <ul className="flex gap-4">
                    {socialLinks.map((item, i) => (
                      <li key={i}>
                        <a
                          href={item.path}
                          className="flex items-center justify-center rounded-[5px] h-[30px] w-[30px] bg-[#491F61]"
                          aria-label={`Follow us on ${
                            item.icon.type.name || "Social Media"
                          }`}
                        >
                          {item.icon}
                        </a>
                      </li>
                    ))}
                  </ul>
                </nav>
              </div>
            </div>
            <div className="w-full lg:w-7/12">
              <div className="mb-5">
                <h2 className="text-[24px] md:text-[32px] lg:text-[40px] font-bold leading-[46px] md:leading-[42px] lg:leading-[51px] mb-3 bg-[#F5F5F7] inline py-[2px] px-[6px] text-center flex-none">
                  Ready To Get Started ?
                </h2>
              </div>
              <p className="text-base leading-[23px]">
  Ready to transform your digital presence? Let&rsquo;s join forces and
  elevate your business to new heights.
</p>
              <form className="pt-5">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-3">
                  <div className="w-full">
                    <h6 className="text-base lg:text-[18px] leading-[32px] font-semibold mb-2">
                      Your Name
                    </h6>
                    <div className="border border-[#EBEAED] rounded-[10px] flex items-center gap-4 px-4 hover:border-[#491F61] transition ease">
                      <UserName />
                      <input
                        type="text"
                        placeholder="Full name here"
                        className="w-full p-4 pl-2 bg-transparent focus:outline-none"
                      />
                    </div>
                  </div>
                  <div className="w-full">
                    <h6 className="text-base lg:text-[18px] leading-[32px] font-semibold mb-2">
                      Phone Number
                    </h6>
                    <div className="border border-[#EBEAED] rounded-[10px] flex items-center gap-4 px-4 hover:border-[#491F61] transition ease">
                      <CallIcon />
                      <input
                        type="text"
                        placeholder="Number here"
                        className="w-full p-4 pl-2 bg-transparent focus:outline-none"
                      />
                    </div>
                  </div>
                </div>
                <div className="mb-3">
                  <h6 className="text-base lg:text-[18px] leading-[32px] font-semibold mb-2">
                    Your Email
                  </h6>
                  <div className="border border-[#EBEAED] rounded-[10px] flex items-center gap-4 px-4 hover:border-[#491F61] transition ease">
                    <YourEmail />
                    <input
                      type="text"
                      placeholder="Number here"
                      className="w-full p-4 pl-2 bg-transparent focus:outline-none"
                    />
                  </div>
                </div>
                <div className="mb-3">
                  <h6 className="text-base lg:text-[18px] leading-[32px] font-semibold mb-3">
                    Your Message
                  </h6>
                  <div className="border border-[#EBEAED] rounded-[10px] flex items-center hover:border-[#491F61] transition ease">
                    <textarea
                      placeholder="Type your message here"
                      className="w-full p-4 bg-transparent focus:outline-none"
                      rows={6}
                    />
                  </div>
                </div>
                <Button
                  className="text-[24px] leading-[30px] font-semibold bg-[#F5F5F7] py-4"
                  varient="secondary"
                  text="Send Message"
                />
              </form>
            </div>
          </div>
          <div className="rounded-[10px] overflow-hidden shadow-lg mt-20 h-[350px] lg:h-[450px] 2xl:h-[600px]">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d425563.637139154!2d-112.2820019588213!3d33.56075664856908!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xadbfdd69eb94967d%3A0x945954682ee637b3!2sIillest%20Finds!5e0!3m2!1sen!2s!4v1741984213563!5m2!1sen!2s"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              className="w-[100%] h-[100%]"
              title="Iillest Finds Digital Marketing Agency"
            ></iframe>
            {/* <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!2d1737737.5537956224!2d-112.30434904056995!3d33.384469028852!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xadbfdd69eb94967d%3A0x945954682ee637b3!2sIillest%20Finds!5e0!3m2!1sen!2s!4v1741805471346!5m2!1sen!2s"
                width="100%"
                style={{ border: 0, height: "100%" }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="w-full h-full"
                title="iillest finds agency location"
              ></iframe> */}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactUs;
