// Home > Services > SEO Services Phoenix
import {
  onPageSEOData,
  offPageSEOData,
  technicalSEOData,
  localSEOData,
  ecommerceSEOData,
  googleBusinessProfileData,
  socialMediaStrategyData,
  socialMediaPaidMarketingData,
  contentCreationData,
  socialMediaAdvertisingData,
  communityEngagementData,
  influencerMarketingData,
  landingPageDevelopmentData,
  wordpressWebsiteDevelopmentData,
  customWebsiteDevelopmentData,
  eCommStoreDevelopmentData,
  websiteRedesignOptimizationData,
  speedPerformanceOptimizationData,
} from "./ServicesDetailPageData";

import {
  caseForOckland,
  caseForKarkaoke,
  caseForDental,
  caseForConstruction,
  caseForBockmann,
  caseForPaddock,
} from "./case-study-data";
// console.log("Rich Content Data:", richContentData);
export const data = {
  services: [
    {
      metaTitle: "SEO Services in Phoenix | Your Trusted Local SEO Agency",
      metaDescription:
        "Enhance your online presence with expert SEO services tailored for businesses in Phoenix and nearby areas. From on-page and off-page to technical and local SEO, we deliver measurable results.",
      slug: "seo-services-phoenix",
      tabTitle: "Search Engine Optimization",
      tabDescription:
        "We provide comprehensive SEO strategies, including website audits, local SEO, and GBP optimization, ensuring your business stands out in Phoenix, AZ.",
      title: "SEO Services",
      subTitle:
        "Expert SEO solutions designed to boost your visibility and drive organic growth across Phoenix and neighboring cities.",
      icon: "/images/service-seo.png",
      image: "/images/services/single-seo.png",
      aboutTitle: "About Our SEO Services",
      aboutService:
        "Our SEO solutions help businesses in Phoenix and nearby areas improve their website visibility and attract the right audience. We craft personalized strategies aligned with your goals to maximize online success.",
      keyBenefits: [
        "Comprehensive website audits & keyword research",
        "Tailored on-page and off-page optimization strategies",
        "Technical SEO enhancements for improved performance",
        "Local SEO solutions to connect with customers in your area",
        "Transparent reporting and ongoing performance tracking",
      ],
      cta: "Ready to enhance your online presence?",
      serviceList: [
        {
          tabTitle: "On-Page SEO",
          tabSubTitle:
            "Optimize your website’s content, structure, and metadata to boost rankings, improve user experience, and attract organic traffic.",
          slug: "on-page-seo",
          detail: {
            title: "On-Page SEO Services",
            subTitle:
              "Unlock your website's potential with strategic on-page SEO, giving businesses a competitive edge in Phoenix and beyond.",
            metaTitle:
              "On-Page SEO Services | Improve Rankings & User Experience",
            metaDescription:
              "Optimize your website’s content, structure, and metadata with expert on-page SEO strategies designed to improve search rankings and increase traffic.",
            image: "",
            onPage: onPageSEOData.richContent,
          },
        },
        {
          tabTitle: "Off-Page SEO",
          tabSubTitle:
            "Strengthen your website’s authority with high-quality backlinks, influencer outreach, and strategic brand mentions.",
          slug: "off-page-seo",
          detail: {
            title: "Off-Page SEO Services",
            subTitle:
              "Boost your website’s credibility and search visibility with powerful off-page SEO strategies.",
            metaTitle:
              "Off-Page SEO Services | Strengthen Your Online Authority",
            metaDescription:
              "Increase your website's authority and rankings with expert off-page SEO, including strategic link building and brand engagement.",
            image: "",
            onPage: offPageSEOData.richContent,
          },
        },
        {
          tabTitle: "Technical SEO",
          tabSubTitle:
            "Optimize your website’s speed, mobile-friendliness, and security to improve search rankings and user experience.",
          slug: "technical-seo",
          detail: {
            title: "Technical SEO Services",
            subTitle:
              "Ensure your website is optimized for performance, accessibility, and search engine indexing.",
            metaTitle:
              "Technical SEO Services | Improve Website Speed & Performance",
            metaDescription:
              "Enhance your website’s speed, security, and mobile optimization with expert technical SEO solutions.",
            image: "",
            onPage: technicalSEOData.richContent,
          },
        },
        {
          tabTitle: "Local SEO",
          tabSubTitle:
            "Boost your business visibility in local search results and attract customers from Phoenix and surrounding communities.",
          slug: "local-seo",
          detail: {
            title: "Local SEO Services",
            subTitle:
              "Help your business stand out in local search and connect with nearby customers.",
            metaTitle: "Local SEO Services | Dominate Local Search Results",
            metaDescription:
              "Increase your visibility in local search and attract more customers with expert local SEO strategies, including Google My Business optimization and local citations.",
            image: "",
            onPage: localSEOData.richContent,
          },
        },
        {
          tabTitle: "E-comme SEO",
          tabSubTitle:
            "Optimize your online store with targeted strategies to improve product visibility, increase traffic, and drive sales.",
          slug: "ecommerce-seo",
          detail: {
            title: "E-commerce SEO Services",
            subTitle:
              "Maximize your store’s potential with specialized E-commerce SEO solutions designed to drive traffic and boost conversions.",
            metaTitle: "E-commerce SEO Services | Grow Your Online Sales",
            metaDescription:
              "Optimize your e-commerce site with expert SEO strategies that increase product visibility and improve conversions.",
            image: "",
            onPage: ecommerceSEOData.richContent,
          },
        },
        {
          tabTitle: "Google My Business",
          tabSubTitle:
            "Optimize your Google Business Profile to enhance local credibility and attract more customers.",
          slug: "gmp",
          detail: {
            title: "Google Business Profile Optimization",
            subTitle:
              "Increase local visibility and engagement with an optimized Google Business Profile.",
            metaTitle:
              "Google Business Profile Services | Improve Local Search Visibility",
            metaDescription:
              "Enhance your local presence with expert Google Business Profile optimization, driving more traffic to your business.",
            image: "",
            onPage: googleBusinessProfileData.richContent,
          },
        },
      ],
      faqs: {
        title: "SEO Services FAQs",
        shortDesc: "Get answers to common questions about our SEO services.",
        faqList: [
          {
            heading: "How long does it take to see SEO results?",
            description:
              "SEO results typically start showing within 3-6 months, depending on your industry and competition.",
          },
          {
            heading: "What is included in your SEO services?",
            description:
              "We offer a complete range of SEO services, including on-page, off-page, technical, and local SEO strategies.",
          },
          {
            heading: "Do you provide local SEO services?",
            description:
              "Yes, we specialize in local SEO to help businesses improve visibility and attract customers from their area.",
          },
          {
            heading: "How do you measure SEO success?",
            description:
              "We track key metrics such as search rankings, organic traffic, and conversions using advanced analytics.",
          },
          {
            heading: "Can SEO help increase my sales?",
            description:
              "Absolutely! A well-executed SEO strategy drives targeted traffic, leading to more conversions and higher revenue.",
          },
        ],
      },
    },

    {
      metaTitle:
        "Social Media Marketing in Phoenix | Expert SMM Agency in Arizona",
      metaDescription:
        "Boost your brand with expert social media marketing services in Phoenix and surrounding areas. From content management to paid campaigns, we drive engagement, growth, and ROI.",
      slug: "social-media-marketing-phoenix",
      tabTitle: "Social Media Marketing",
      tabDescription:
        "We create high-impact social media strategies that build trust, increase engagement, and generate leads on platforms like Facebook, Instagram, X, LinkedIn, and TikTok.",
      title: "Social Media Marketing",
      subTitle:
        "Amplify your brand’s presence with dynamic, data-driven social media strategies designed to connect with your audience.",
      icon: "/images/service-social-media.png",
      image: "/images/services/social-media.jpg",
      aboutTitle: "About Our Social Media Marketing Services",
      aboutService:
        "Our social media marketing services help businesses in Phoenix and beyond establish a strong digital presence. By blending creativity with data-driven insights, we deliver measurable results tailored to your brand.",
      keyBenefits: [
        "Customized social media strategy aligned with your brand identity.",
        "Engaging content creation and consistent channel management.",
        "Targeted paid campaigns for increased reach and conversions.",
        "Active community engagement to foster brand loyalty.",
        "Detailed analytics for performance tracking and continuous improvement.",
      ],
      cta: "Ready to level up your social media strategy?",
      serviceList: [
        {
          tabTitle: "Social Media Strategy",
          tabSubTitle:
            "Develop innovative social media strategies that resonate with your audience, increase engagement, and position your brand as a local leader.",
          slug: "social-media-strategy",
          detail: {
            title: "Social Media Strategy Services",
            subTitle:
              "Empower your brand with a results-driven social media strategy designed to boost engagement and drive measurable success.",
            metaTitle:
              "Social Media Strategy Services | Build a Strong Digital Presence",
            metaDescription:
              "Maximize your brand’s impact with our expert social media strategy services. We craft tailored plans to increase engagement, grow your audience, and drive conversions.",
            image: "",
            onPage: socialMediaStrategyData.richContent,
          },
        },

        {
          tabTitle: "Content Creation",
          tabSubTitle:
            "Create high-quality, engaging content that strengthens your brand, encourages audience interaction, and ensures consistency across platforms.",
          slug: "content-creation-management",
          detail: {
            title: "Content Creation & Management",
            subTitle:
              "Stand out with compelling content that attracts, engages, and converts your audience.",
            metaTitle:
              "Content Creation & Management | Elevate Your Brand with Engaging Content",
            metaDescription:
              "Enhance your brand’s online presence with expert content creation and management services. We craft high-quality content that drives engagement and builds trust.",
            image: "",
            onPage: contentCreationData.richContent,
          },
        },
        {
          tabTitle: "Social Media Advertising",
          tabSubTitle:
            "Run targeted paid advertising campaigns on platforms like Facebook and Instagram to maximize brand exposure and drive measurable results.",
          slug: "social-media-advertising",
          detail: {
            title: "Social Media Advertising",
            subTitle:
              "Expand your brand’s reach with precision-targeted social media ads designed to drive engagement and conversions.",
            metaTitle:
              "Social Media Advertising | Maximize ROI with Targeted Campaigns",
            metaDescription:
              "Achieve better results with our expert social media advertising services. We create high-performing ad campaigns that reach your ideal audience and boost conversions.",
            image: "",
            onPage: socialMediaAdvertisingData.richContent,
          },
        },

        {
          tabTitle: "Community Engagement",
          tabSubTitle:
            "Build strong relationships with your audience through interactive campaigns and responsive communication that foster brand loyalty.",
          slug: "community-engagement",
          detail: {
            title: "Community Engagement Services",
            subTitle:
              "Strengthen your brand’s presence by fostering a vibrant and engaged online community.",
            metaTitle:
              "Community Engagement | Build Lasting Connections with Your Audience",
            metaDescription:
              "Enhance brand loyalty with expert community engagement services. We foster genuine interactions that create meaningful relationships and drive long-term engagement.",
            image: "",
            onPage: communityEngagementData.richContent,
          },
        },

        {
          tabTitle: "Influencer Marketing",
          tabSubTitle:
            "Leverage partnerships with influencers to amplify your brand message, boost credibility, and expand your audience reach.",
          slug: "influencer-marketing",
          detail: {
            title: "Influencer Marketing",
            subTitle:
              "Grow your brand through strategic influencer collaborations that build trust and engagement.",
            metaTitle:
              "Influencer Marketing | Elevate Your Brand with Trusted Partnerships",
            metaDescription:
              "Expand your brand’s influence with targeted influencer marketing. We connect you with the right creators to increase engagement, credibility, and conversions.",
            image: "",
            onPage: influencerMarketingData.richContent,
          },
        },

        {
          tabTitle: "Social Media Paid Marketing",
          tabSubTitle:
            "Execute data-driven paid marketing campaigns to drive immediate traffic, generate leads, and maximize conversions.",
          slug: "social-media-paid-marketing",
          detail: {
            title: "Social Media Paid Marketing",
            subTitle:
              "Boost brand visibility and ROI with expertly crafted paid social media campaigns.",
            metaTitle:
              "Social Media Paid Marketing | Drive Conversions with Targeted Ads",
            metaDescription:
              "Optimize your ad spend with high-performing social media paid marketing campaigns. Our data-driven approach ensures maximum impact and ROI.",
            image: "",
            onPage: socialMediaPaidMarketingData.richContent,
          },
        },
      ],
      faqs: {
        title: "Social Media Marketing FAQs",
        shortDesc:
          "Get answers to common questions about our social media marketing services and discover how we can help your brand thrive.",
        faqList: [
          {
            heading:
              "How soon can I expect to see results from social media marketing?",
            description:
              "Most brands see increased engagement within the first 1-3 months, with continued growth over time.",
          },
          {
            heading: "Which social media platforms do you specialize in?",
            description:
              "We manage Facebook, Instagram, LinkedIn, X, TikTok, and more—customizing strategies for the best platform fit.",
          },
          {
            heading: "How do you handle paid social media marketing?",
            description:
              "We create and optimize data-driven ad campaigns tailored to your brand’s goals, maximizing ROI and engagement.",
          },
          {
            heading:
              "Can you manage both organic and paid social media efforts?",
            description:
              "Yes, we offer a full-service approach, combining organic content with paid advertising for maximum growth.",
          },
          {
            heading:
              "How do you measure the success of social media campaigns?",
            description:
              "We track key performance indicators like engagement, reach, conversions, and ROI using advanced analytics and reporting.",
          },
        ],
      },
    },
    {
      metaTitle:
        "Website Development in Phoenix | Expert Web Development Services",
      metaDescription:
        "Build a strong online presence with our website development services in Phoenix and nearby areas. From custom websites to e-commerce solutions, we drive growth and conversions.",
      slug: "website-development-phoenix",
      tabTitle: "Web Development",
      tabDescription:
        "We craft high-performance websites that captivate visually, deliver seamless user experiences, enhance brand credibility, and drive real business growth.",
      title: "Website Development",
      subTitle:
        "Create a lasting digital impact with custom web solutions designed for growth, performance, and conversion.",
      icon: "/images/service-web-dev.png",
      image: "/images/services/web-development.jpg",
      aboutTitle: "About Our Web Development Services",
      aboutService:
        "Our web development solutions are built to help businesses in Phoenix and surrounding areas establish a strong digital presence. We design custom, high-performing websites tailored to your business needs, ensuring an exceptional user experience and measurable growth.",
      keyBenefits: [
        "Custom design tailored to your brand identity.",
        "Mobile-friendly and responsive for seamless usability.",
        "SEO-optimized coding to improve search rankings.",
        "E-commerce solutions to maximize online sales.",
        "Ongoing support and optimization for peak performance.",
      ],
      cta: "Ready to take your website to the next level?",
      serviceList: [
        {
          tabTitle: "Landing Page Development",
          tabSubTitle:
            "Design high-converting landing pages that instantly capture leads and showcase your brand with impactful messaging.",
          slug: "landing-page-development",
          detail: {
            title: "Landing Page Development",
            subTitle:
              "Turn visitors into customers with conversion-focused landing pages designed to drive sales and engagement.",
            metaTitle:
              "Landing Page Development | High-Converting Webpages for Your Business",
            metaDescription:
              "Boost your conversions with expertly designed landing pages. We create fast, engaging, and visually compelling pages tailored to your business goals.",
            image: "",
            onPage: landingPageDevelopmentData.richContent,
          },
        },

        {
          tabTitle: "WordPress Website Development",
          tabSubTitle:
            "Build SEO-friendly, scalable WordPress websites that are easy to manage and customized to your business needs.",
          slug: "wordpress-website-development",
          detail: {
            title: "WordPress Website Development",
            subTitle:
              "Harness the power of WordPress with a custom, user-friendly website designed for performance and growth.",
            metaTitle:
              "WordPress Website Development | Custom, SEO-Optimized Websites",
            metaDescription:
              "Create a stunning and functional website with our WordPress development services. We design SEO-friendly, responsive websites that enhance your brand's online presence.",
            image: "",
            onPage: wordpressWebsiteDevelopmentData.richContent,
          },
        },

        {
          tabTitle: "Custom Website Development",
          tabSubTitle:
            "Get a fully customized website tailored to your brand, built with the latest technologies for high performance and scalability.",
          slug: "custom-website-development",
          detail: {
            title: "Custom Website Development",
            subTitle:
              "Stand out with a bespoke website built to match your brand’s unique needs and deliver exceptional user experiences.",
            metaTitle:
              "Custom Website Development | Tailored Digital Solutions",
            metaDescription:
              "Transform your business with a fully customized website. We develop feature-rich, high-performance websites using cutting-edge technologies like React, Next.js, Vue.js, and Laravel.",
            image: "",
            onPage: customWebsiteDevelopmentData.richContent,
          },
        },
        {
          tabTitle: "E-Commerce Store Development",
          tabSubTitle:
            "Develop a seamless, high-performing e-commerce website that enhances the shopping experience and boosts online sales.",
          slug: "ecommerce-website-development",
          detail: {
            title: "E-Commerce Store Development",
            subTitle:
              "Launch and grow your online store with a fully optimized e-commerce platform designed for conversions.",
            metaTitle:
              "E-Commerce Website Development | Scalable Online Store Solutions",
            metaDescription:
              "Build a high-performing online store with our expert e-commerce development services. We create seamless, conversion-driven shopping experiences that increase sales and customer retention.",
            image: "",
            onPage: eCommStoreDevelopmentData.richContent,
          },
        },
        {
          tabTitle: "Website Redesign & Optimization",
          tabSubTitle:
            "Revamp outdated websites with modern designs and optimization strategies to enhance user experience and improve search rankings.",
          slug: "website-redesign-optimization",
          detail: {
            title: "Website Redesign & Optimization",
            subTitle:
              "Give your website a fresh new look with enhanced functionality, speed, and user experience.",
            metaTitle:
              "Website Redesign & Optimization | Upgrade Your Online Presence",
            metaDescription:
              "Revitalize your website with modern design updates, improved performance, and strategic SEO enhancements to attract and retain visitors.",
            image: "",
            onPage: websiteRedesignOptimizationData.richContent,
          },
        },

        {
          tabTitle: "Speed & Performance Optimization",
          tabSubTitle:
            "Enhance website speed and performance with advanced optimization techniques to improve user experience and rankings.",
          slug: "speed-performance-optimization",
          detail: {
            title: "Speed & Performance Optimization",
            subTitle:
              "Ensure lightning-fast load times and smooth navigation with expert website performance enhancements.",
            metaTitle:
              "Speed & Performance Optimization | Faster Load Times & Better UX",
            metaDescription:
              "Optimize your website’s speed and performance to provide a seamless browsing experience, improve rankings, and boost engagement.",
            image: "",
            onPage: speedPerformanceOptimizationData.richContent,
          },
        },
      ],
      faqs: {
        title: "Website Development FAQs",
        shortDesc:
          "Find answers to common questions about our website development services and how we help businesses grow online.",
        faqList: [
          {
            heading: "How long does it take to develop a website?",
            description:
              "Timelines vary based on project complexity—simple sites take 4-6 weeks, while custom solutions may require 8-12 weeks.",
          },
          {
            heading: "What technologies do you use for website development?",
            description:
              "We use cutting-edge technologies like HTML5, CSS3, JavaScript, React, Next.js, WordPress, and more.",
          },
          {
            heading: "Can you create a custom design for my website?",
            description:
              "Yes, we offer fully tailored design services to ensure your website stands out and aligns with your brand identity.",
          },
          {
            heading: "How do you make sure my website is SEO-friendly?",
            description:
              "Our development process includes SEO best practices, ensuring clean code, responsive design, and optimized metadata for better rankings.",
          },
          {
            heading: "Do you offer post-launch support and maintenance?",
            description:
              "Yes, we provide ongoing maintenance, updates, and performance optimization to keep your site running smoothly.",
          },
        ],
      },
    },
  ],
  faqs: {
    title: "FAQ's",
    shortDesc: "Got questions? We’ve got answers!",
    faqList: [
      {
        heading:
          "What sets iillest finds apart from other digital marketing agencies?",
        description:
          "We combine deep local knowledge with hands-on experience. Faeezah Lun, our founder, has over 5 years of experience helping US businesses grow through personalized strategies. Our focus on local SEO, community engagement, and tailored solutions ensures you’re not just another client—you’re a neighbor we genuinely want to see succeed.",
      },
      {
        heading: "Do you work with all types of businesses?",
        description:
          "Absolutely! Whether you’re a startup, a small business, or an established local brand, we tailor our digital marketing strategies to meet your unique needs. Our services are designed to help every type of Local business shine online.",
      },
      {
        heading:
          "How soon can I expect results from your digital marketing strategies?",
        description:
          "Digital marketing is a long-term game, but many of our clients start noticing improvements in as little as 4-6 weeks. More significant growth usually happens within 3-6 months as we refine strategies and build momentum.",
      },
      {
        heading:
          "How do you determine which digital marketing services are right for my business?",
        description:
          "We begin with a free consultation to understand your goals, challenges, and target audience. This personalized approach allows us to recommend a mix of SEO, social media marketing, and website development services that are best suited to help your Phoenix business grow.",
      },
      {
        heading: "Can I see examples of your work with other local businesses?",
        description:
          "Yes! We’re proud of the results we’ve achieved locally. Check out our Case Studies page to see how we’ve helped other local businesses boost their online presence and drive real growth.",
      },
    ],
  },
  caseStudyData: [
    {
      title:
        "How We Tripled Engagement for Oakland Central’s Community Revival",
      subTitle:
        "Non-Profit Social Media Case Study: 5,164 Followers & Sold-Out Events",
      summery:
        "Tripled Oakland Central’s social impact – grew to 5k+ followers & 103% event capacity using hyperlocal strategies. 83+ biz partnerships forged.",
      slug: "oakland-central-social-media-case-study",
      metaTitle:
        "Oakland Non-Profit Social Media Success | Downtown Revival Strategy | Iillest Finds",
      metaDescription:
        "See how our social strategies tripled engagement for Oakland Central - 5k+ followers & sold-out local events. Perfect for community orgs.",
      category: "Social Media Marketing",
      image: "/images/case-study/oakland-case-study.jpg",
      client: "Tech Innovators",
      address: "San Francisco, USA",
      table: [
        {
          key: "Title",
          value: "data",
        },
        {
          key: "Title 2",
          value: "data",
        },
        {
          key: "Title 3",
          value: "data",
        },
      ],
      desc: caseForOckland.richContent,
      serviceList: [
        {
          tabTitle: "Social Media Strategy",
          tabSubTitle:
            "Develop innovative social media strategies that resonate with your audience, increase engagement, and position your brand as a local leader.",
          slug: "social-media-strategy",

          parentSlug: "seo-services-phoenix",
          detail: {
            title: "Social Media Strategy Services",
            subTitle:
              "Empower your brand with a results-driven social media strategy designed to boost engagement and drive measurable success.",
            metaTitle:
              "Social Media Strategy Services | Build a Strong Digital Presence",
            metaDescription:
              "Maximize your brand’s impact with our expert social media strategy services. We craft tailored plans to increase engagement, grow your audience, and drive conversions.",
            image: "",
            onPage: socialMediaStrategyData.richContent,
          },
        },

        {
          tabTitle: "Content Creation",
          tabSubTitle:
            "Create high-quality, engaging content that strengthens your brand, encourages audience interaction, and ensures consistency across platforms.",
          parentSlug: "seo-services-phoenix",
          slug: "content-creation-management",
          detail: {
            title: "Content Creation & Management",
            subTitle:
              "Stand out with compelling content that attracts, engages, and converts your audience.",
            metaTitle:
              "Content Creation & Management | Elevate Your Brand with Engaging Content",
            metaDescription:
              "Enhance your brand’s online presence with expert content creation and management services. We craft high-quality content that drives engagement and builds trust.",
            image: "",
            onPage: contentCreationData.richContent,
          },
        },
        {
          tabTitle: "Social Media Advertising",
          tabSubTitle:
            "Run targeted paid advertising campaigns on platforms like Facebook and Instagram to maximize brand exposure and drive measurable results.",
          parentSlug: "seo-services-phoenix",
          slug: "social-media-advertising",
          detail: {
            title: "Social Media Advertising",
            subTitle:
              "Expand your brand’s reach with precision-targeted social media ads designed to drive engagement and conversions.",
            metaTitle:
              "Social Media Advertising | Maximize ROI with Targeted Campaigns",
            metaDescription:
              "Achieve better results with our expert social media advertising services. We create high-performing ad campaigns that reach your ideal audience and boost conversions.",
            image: "",
            onPage: socialMediaAdvertisingData.richContent,
          },
        },

        {
          tabTitle: "Community Engagement",
          tabSubTitle:
            "Build strong relationships with your audience through interactive campaigns and responsive communication that foster brand loyalty.",
          parentSlug: "seo-services-phoenix",
          slug: "community-engagement",
          detail: {
            title: "Community Engagement Services",
            subTitle:
              "Strengthen your brand’s presence by fostering a vibrant and engaged online community.",
            metaTitle:
              "Community Engagement | Build Lasting Connections with Your Audience",
            metaDescription:
              "Enhance brand loyalty with expert community engagement services. We foster genuine interactions that create meaningful relationships and drive long-term engagement.",
            image: "",
            onPage: communityEngagementData.richContent,
          },
        },

        {
          tabTitle: "Influencer Marketing",
          tabSubTitle:
            "Leverage partnerships with influencers to amplify your brand message, boost credibility, and expand your audience reach.",
          parentSlug: "seo-services-phoenix",
          slug: "influencer-marketing",
          detail: {
            title: "Influencer Marketing",
            subTitle:
              "Grow your brand through strategic influencer collaborations that build trust and engagement.",
            metaTitle:
              "Influencer Marketing | Elevate Your Brand with Trusted Partnerships",
            metaDescription:
              "Expand your brand’s influence with targeted influencer marketing. We connect you with the right creators to increase engagement, credibility, and conversions.",
            image: "",
            onPage: influencerMarketingData.richContent,
          },
        },

        {
          tabTitle: "Social Media Paid Marketing",
          tabSubTitle:
            "Execute data-driven paid marketing campaigns to drive immediate traffic, generate leads, and maximize conversions.",
          parentSlug: "seo-services-phoenix",
          slug: "social-media-paid-marketing",
          detail: {
            title: "Social Media Paid Marketing",
            subTitle:
              "Boost brand visibility and ROI with expertly crafted paid social media campaigns.",
            metaTitle:
              "Social Media Paid Marketing | Drive Conversions with Targeted Ads",
            metaDescription:
              "Optimize your ad spend with high-performing social media paid marketing campaigns. Our data-driven approach ensures maximum impact and ROI.",
            image: "",
            onPage: socialMediaPaidMarketingData.richContent,
          },
        },
      ],
    },
    {
      title: "How We Sold Out a Cross-Country Karaoke Event in 30 Days",
      subTitle:
        "Afro Karaoke Social Media Case Study: 200+ Attendees & Sponsorship Success",
      summery:
        "Sold out Afro Karaoke’s Bay Area debut – 200+ attendees & 5 sponsors secured through geo-targeted social blitz. 18.7k reach achieved.",
      slug: "afro-karaoke-event-marketing-case-study",
      metaTitle:
        "National Event Promotion Success | Afro Karaoke Case Study | Iillest Finds",
      metaDescription:
        "Discover how we sold out a Bay Area karaoke event in 4 weeks using social media magic + sponsor hunting. Perfect for touring entertainers.",
      category: "Social Media Marketing",
      image: "/images/case-study/afro-case-study.jpg",
      client: "Tech Innovators",
      address: "San Francisco, USA",
      table: [
        {
          key: "Title",
          value: "data",
        },
        {
          key: "Title 2",
          value: "data",
        },
        {
          key: "Title 3",
          value: "data",
        },
      ],
      desc: caseForKarkaoke.richContent,
      serviceList: [
        {
          tabTitle: "Social Media Strategy",
          tabSubTitle:
            "Develop innovative social media strategies that resonate with your audience, increase engagement, and position your brand as a local leader.",
          slug: "social-media-strategy",
          parentSlug: "social-media-marketing-phoenix",
          detail: {
            title: "Social Media Strategy Services",
            subTitle:
              "Empower your brand with a results-driven social media strategy designed to boost engagement and drive measurable success.",
            metaTitle:
              "Social Media Strategy Services | Build a Strong Digital Presence",
            metaDescription:
              "Maximize your brand’s impact with our expert social media strategy services. We craft tailored plans to increase engagement, grow your audience, and drive conversions.",
            image: "",
            onPage: socialMediaStrategyData.richContent,
          },
        },

        {
          tabTitle: "Content Creation",
          tabSubTitle:
            "Create high-quality, engaging content that strengthens your brand, encourages audience interaction, and ensures consistency across platforms.",
          slug: "content-creation-management",
          parentSlug: "social-media-marketing-phoenix",
          detail: {
            title: "Content Creation & Management",
            subTitle:
              "Stand out with compelling content that attracts, engages, and converts your audience.",
            metaTitle:
              "Content Creation & Management | Elevate Your Brand with Engaging Content",
            metaDescription:
              "Enhance your brand’s online presence with expert content creation and management services. We craft high-quality content that drives engagement and builds trust.",
            image: "",
            onPage: contentCreationData.richContent,
          },
        },
        {
          tabTitle: "Social Media Advertising",
          tabSubTitle:
            "Run targeted paid advertising campaigns on platforms like Facebook and Instagram to maximize brand exposure and drive measurable results.",
          slug: "social-media-advertising",
          parentSlug: "social-media-marketing-phoenix",
          detail: {
            title: "Social Media Advertising",
            subTitle:
              "Expand your brand’s reach with precision-targeted social media ads designed to drive engagement and conversions.",
            metaTitle:
              "Social Media Advertising | Maximize ROI with Targeted Campaigns",
            metaDescription:
              "Achieve better results with our expert social media advertising services. We create high-performing ad campaigns that reach your ideal audience and boost conversions.",
            image: "",
            onPage: socialMediaAdvertisingData.richContent,
          },
        },

        {
          tabTitle: "Community Engagement",
          tabSubTitle:
            "Build strong relationships with your audience through interactive campaigns and responsive communication that foster brand loyalty.",
          slug: "community-engagement",
          parentSlug: "social-media-marketing-phoenix",
          detail: {
            title: "Community Engagement Services",
            subTitle:
              "Strengthen your brand’s presence by fostering a vibrant and engaged online community.",
            metaTitle:
              "Community Engagement | Build Lasting Connections with Your Audience",
            metaDescription:
              "Enhance brand loyalty with expert community engagement services. We foster genuine interactions that create meaningful relationships and drive long-term engagement.",
            image: "",
            onPage: communityEngagementData.richContent,
          },
        },

        {
          tabTitle: "Influencer Marketing",
          tabSubTitle:
            "Leverage partnerships with influencers to amplify your brand message, boost credibility, and expand your audience reach.",
          slug: "influencer-marketing",
          parentSlug: "social-media-marketing-phoenix",
          detail: {
            title: "Influencer Marketing",
            subTitle:
              "Grow your brand through strategic influencer collaborations that build trust and engagement.",
            metaTitle:
              "Influencer Marketing | Elevate Your Brand with Trusted Partnerships",
            metaDescription:
              "Expand your brand’s influence with targeted influencer marketing. We connect you with the right creators to increase engagement, credibility, and conversions.",
            image: "",
            onPage: influencerMarketingData.richContent,
          },
        },

        {
          tabTitle: "Social Media Paid Marketing",
          tabSubTitle:
            "Execute data-driven paid marketing campaigns to drive immediate traffic, generate leads, and maximize conversions.",
          slug: "social-media-paid-marketing",
          parentSlug: "social-media-marketing-phoenix",
          detail: {
            title: "Social Media Paid Marketing",
            subTitle:
              "Boost brand visibility and ROI with expertly crafted paid social media campaigns.",
            metaTitle:
              "Social Media Paid Marketing | Drive Conversions with Targeted Ads",
            metaDescription:
              "Optimize your ad spend with high-performing social media paid marketing campaigns. Our data-driven approach ensures maximum impact and ROI.",
            image: "",
            onPage: socialMediaPaidMarketingData.richContent,
          },
        },
      ],
    },
    // {
    //   title: "How We Boosted Greenwich Workshop’s Phoenix Art Sales with SEO (Real Results Inside)",
    //   subTitle:
    //     "A Phoenix-Based SEO Case Study for Art Galleries & Collectors",
    //     summery:"Boosted Greenwich Workshop's art sales with 8.6K clicks (+230%) and #1 rankings for 'Phoenix giclée printing.' Proven AZ-local strategy for galleries & artists.",
    //   slug: "greenwich-workshop-seo-case-study-phoenix-az",
    //   metaTitle:"Greenwich Workshop SEO Success | Phoenix Art Marketing Results",
    //   metaDescription: "Discover how we increased Phoenix art sales by 4,690+ clicks using SEO strategies for Greenwich Workshop. Perfect for AZ galleries & collectors.",
    //   category: "Local SEO",
    //   image: "/images/case-study/Greewich-Workshop.webp",
    //   client: "Cameron",
    //   address: "City, Country",
    //   projectInfoTitle:"Statistics",
    //   tableHeaders: ["Metric", "Before SEO", "After SEO"],
    //   tableRows: [
    //   ["Monthly Visitors", "890", "4,690"],
    //   ["Phoenix Traffic %", "12%", "38%"],
    //   ["Sales Inquiries", "20/mo", "67/mo"]
    //   ],
    //   desc: caseStudy1.richContent,
    //   serviceList: [
    //     {
    //       tabTitle: "On-Page SEO",
    //       tabSubTitle:
    //         "Optimize your website’s content, structure, and metadata to boost rankings, improve user experience, and drive targeted organic traffic—discover how every detail matters.",
    //       slug: "on-page-seo",
    //       parentSlug: "seo-services-phoenix",
    //       detail: {
    //         title: "On-Page SEO Services Phoenix",
    //         subTitle:
    //           "Unlock your website's potential with expert on-page SEO, giving Phoenix businesses a competitive edge.",
    //         metaTitle:
    //           "On-Page SEO Services Phoenix | Boost Your Website's Visibility",
    //         metaDescription:
    //           "Discover expert on-page SEO services in Phoenix that optimize your website’s content, structure, and metadata to drive organic traffic, improve rankings, and maximize ROI.",
    //         image: "/images/services/seo.jpg",
    //         onPage: onPageSEOData.richContent,
    //       },
    //     },
    //     {
    //       tabTitle: "Off-Page SEO",
    //       tabSubTitle:
    //         "Build and acquire high-quality backlinks to elevate your site's authority and trust—uncover the secret sauce to outperform your competitors.",
    //       slug: "off-page-seo",
    //       parentSlug: "seo-services-phoenix",
    //       detail: {
    //         title: "Off-Page SEO Services Phoenix",
    //         subTitle:
    //           "Transform your website's authority and organic traffic with our expert off‑page SEO solutions—designed especially for Phoenix businesses.",
    //         metaTitle:
    //           "Off-Page SEO Services Phoenix | Boost Your Authority & Organic Traffic",
    //         metaDescription:
    //           "Elevate your website's performance with expert off‑page SEO services in Phoenix. Our tailored link building, influencer outreach, and social media engagement strategies drive real, measurable growth.",
    //         image: "/images/blogs/52-Blog.jpg",
    //         onPage: offPageSEOData.richContent,
    //       },
    //     },
    //     {
    //       tabTitle: "Technical SEO",
    //       tabSubTitle:
    //         "Enhance your website’s speed, crawlability, mobile responsiveness, and security to ensure smooth indexing and superior performance—experience seamless optimization.",
    //       slug: "technical-seo",
    //       parentSlug: "seo-services-phoenix",
    //       detail: {
    //         title: "Technical SEO Services Phoenix",
    //         subTitle:
    //           "Supercharge your website’s performance with our Technical SEO services—designed to improve speed, accessibility, and overall user experience for Phoenix businesses.",
    //         metaTitle:
    //           "Technical SEO Services Phoenix | Optimize Your Website’s Performance",
    //         metaDescription:
    //           "Enhance your website’s performance with our expert Technical SEO services in Phoenix. From site speed to mobile optimization and secure coding, we ensure your site is primed for success.",
    //         image: "/images/blogs/52-Blog.jpg",
    //         onPage: technicalSEOData.richContent,
    //       },
    //     },
    //     {
    //       tabTitle: "Local SEO",
    //       tabSubTitle:
    //         "Harness tailored local strategies to capture nearby searches and boost your Phoenix market presence—find out how to dominate your local scene.",
    //       slug: "local-seo",
    //       parentSlug: "seo-services-phoenix",
    //       detail: {
    //         title: "Local SEO Services Phoenix",
    //         subTitle:
    //           "Empower your business to stand out locally and attract nearby customers with our tailored Local SEO solutions.",
    //         metaTitle:
    //           "Local SEO Services Phoenix | Dominate Your Local Market",
    //         metaDescription:
    //           "Boost your local online presence with our expert Local SEO services in Phoenix. Improve your Google My Business listing, local citations, and customer reviews to drive foot traffic and sales.",
    //         image: "/images/blogs/52-Blog.jpg",
    //         onPage: localSEOData.richContent,
    //       },
    //     },
    //     {
    //       tabTitle: "E-com SEO",
    //       tabSubTitle:
    //         "Revamp your ecommerce platform by optimizing product pages, streamlining navigation, and implementing conversion-focused tactics—get ready to skyrocket your sales.",
    //       slug: "ecommerce-seo",
    //       parentSlug: "seo-services-phoenix",
    //       detail: {
    //         title: "Ecommerce SEO Services Phoenix",
    //         subTitle:
    //           "Maximize your online store’s potential with our specialized Ecommerce SEO solutions—designed to drive traffic, improve conversions, and boost sales for Phoenix businesses.",
    //         metaTitle:
    //           "Ecommerce SEO Services Phoenix | Boost Your Online Store's Sales",
    //         metaDescription:
    //           "Optimize your online store with our expert Ecommerce SEO services in Phoenix. Increase visibility, drive traffic, and boost conversions with tailored strategies designed for ecommerce success.",
    //         image: "/images/blogs/52-Blog.jpg",
    //         onPage: ecommerceSEOData.richContent,
    //       },
    //     },
    //     {
    //       tabTitle: "GMP",
    //       tabSubTitle:
    //         "Optimize and manage your Google My Business profile to build local credibility and customer trust—step into the spotlight in Phoenix search results.",
    //       slug: "gmp",
    //       parentSlug: "seo-services-phoenix",
    //       detail: {
    //         title: "Google Business Profile (GMP) Services Phoenix",
    //         subTitle:
    //           "Put your business on the local map with our Google Business Profile services—designed to increase visibility, drive foot traffic, and boost customer engagement for Phoenix businesses.",
    //         metaTitle:
    //           "Google Business Profile (GMP) Services Phoenix | Boost Your Local Visibility",
    //         metaDescription:
    //           "Enhance your local presence with our expert Google Business Profile (GMP) services in Phoenix. Optimize your listing, gather positive reviews, and drive local traffic to your business.",
    //         image: "/images/blogs/52-Blog.jpg",
    //         onPage: googleBusinessProfileData.richContent,
    //       },
    //     },
    //   ],
    // },
    {
      title:
        "How We Helped Parkland Dental Dominate Red Deer Search Results (Canadian SEO Success)",
      subTitle:
        "Alberta Dental Marketing Case Study: 27,000 Clicks & Local Visibility Boost",
      summery:
        "Drove local search dominance for Parkland Dental in Red Deer through Canadian dental SEO – 27k+ clicks & 320% patient growth.",
      slug: "parkland-dental-seo-case-study-red-deer",
      metaTitle:
        "Red Deer Dental SEO Success Story | Parkland Dental Case Study | iilest finds",
      metaDescription:
        "See how our Alberta SEO strategies brought Parkland Dental 27,000+ clicks & #1 rankings in Red Deer. Perfect for Canadian dental practices.",
      category: "SEO",
      image: "/images/case-study/dental-case-study.jpg",
      client: "B2B Software Corp",
      address: "City, Country",
      table: [
        {
          key: "Title",
          value: "data",
        },
        {
          key: "Title 2",
          value: "data",
        },
        {
          key: "Title 3",
          value: "data",
        },
      ],
      desc: caseForDental.richContent,
      serviceList: [
        {
          tabTitle: "On-Page SEO",
          tabSubTitle:
            "Optimize your website’s content, structure, and metadata to boost rankings, improve user experience, and attract organic traffic.",
          parentSlug: "seo-services-phoenix",
          slug: "on-page-seo",
          detail: {
            title: "On-Page SEO Services",
            subTitle:
              "Unlock your website's potential with strategic on-page SEO, giving businesses a competitive edge in Phoenix and beyond.",
            metaTitle:
              "On-Page SEO Services | Improve Rankings & User Experience",
            metaDescription:
              "Optimize your website’s content, structure, and metadata with expert on-page SEO strategies designed to improve search rankings and increase traffic.",
            image: "",
            onPage: onPageSEOData.richContent,
          },
        },
        {
          tabTitle: "Off-Page SEO",
          tabSubTitle:
            "Strengthen your website’s authority with high-quality backlinks, influencer outreach, and strategic brand mentions.",
          parentSlug: "seo-services-phoenix",
          slug: "off-page-seo",
          detail: {
            title: "Off-Page SEO Services",
            subTitle:
              "Boost your website’s credibility and search visibility with powerful off-page SEO strategies.",
            metaTitle:
              "Off-Page SEO Services | Strengthen Your Online Authority",
            metaDescription:
              "Increase your website's authority and rankings with expert off-page SEO, including strategic link building and brand engagement.",
            image: "",
            onPage: offPageSEOData.richContent,
          },
        },
        {
          tabTitle: "Technical SEO",
          tabSubTitle:
            "Optimize your website’s speed, mobile-friendliness, and security to improve search rankings and user experience.",
          parentSlug: "seo-services-phoenix",
          slug: "technical-seo",
          detail: {
            title: "Technical SEO Services",
            subTitle:
              "Ensure your website is optimized for performance, accessibility, and search engine indexing.",
            metaTitle:
              "Technical SEO Services | Improve Website Speed & Performance",
            metaDescription:
              "Enhance your website’s speed, security, and mobile optimization with expert technical SEO solutions.",
            image: "",
            onPage: technicalSEOData.richContent,
          },
        },
        {
          tabTitle: "Local SEO",
          tabSubTitle:
            "Boost your business visibility in local search results and attract customers from Phoenix and surrounding communities.",
          parentSlug: "seo-services-phoenix",
          slug: "local-seo",
          detail: {
            title: "Local SEO Services",
            subTitle:
              "Help your business stand out in local search and connect with nearby customers.",
            metaTitle: "Local SEO Services | Dominate Local Search Results",
            metaDescription:
              "Increase your visibility in local search and attract more customers with expert local SEO strategies, including Google My Business optimization and local citations.",
            image: "",
            onPage: localSEOData.richContent,
          },
        },
        {
          tabTitle: "E-comme SEO",
          tabSubTitle:
            "Optimize your online store with targeted strategies to improve product visibility, increase traffic, and drive sales.",
          parentSlug: "seo-services-phoenix",
          slug: "ecommerce-seo",
          detail: {
            title: "E-commerce SEO Services",
            subTitle:
              "Maximize your store’s potential with specialized E-commerce SEO solutions designed to drive traffic and boost conversions.",
            metaTitle: "E-commerce SEO Services | Grow Your Online Sales",
            metaDescription:
              "Optimize your e-commerce site with expert SEO strategies that increase product visibility and improve conversions.",
            image: "",
            onPage: ecommerceSEOData.richContent,
          },
        },
        {
          tabTitle: "Google My Business",
          tabSubTitle:
            "Optimize your Google Business Profile to enhance local credibility and attract more customers.",
          parentSlug: "seo-services-phoenix",
          slug: "gmp",
          detail: {
            title: "Google Business Profile Optimization",
            subTitle:
              "Increase local visibility and engagement with an optimized Google Business Profile.",
            metaTitle:
              "Google Business Profile Services | Improve Local Search Visibility",
            metaDescription:
              "Enhance your local presence with expert Google Business Profile optimization, driving more traffic to your business.",
            image: "",
            onPage: googleBusinessProfileData.richContent,
          },
        },
      ],
    },
    {
      title:
        "How Elbaz Construction Became Miami’s Go-To Remodeler with Local SEO",
      subTitle:
        "Florida Bathroom Renovation Case Study: 4.2K Clicks & 300% More Calls",
      summery:
        "Delivered 4,236+ Miami remodel leads** for Elbaz Construction using tri-county SEO – dominated 'luxury bathroom renovations' searches across Dade, Broward & Palm Beach. 300% more calls!",
      slug: "elbaz-construction-seo-case-study-miami",
      metaTitle:
        "Miami Construction SEO Success | Elbaz Remodeling Results | Iillest Finds",
      metaDescription:
        "See how our Florida SEO strategies drove Elbaz Construction 4,236+ clicks & 300% call growth. Perfect for tri-county contractors.",
      category: "SEO",
      image: "/images/case-study/elbaz-case-study.jpg",
      client: "Cameron",
      address: "City, Country",
      desc: caseForConstruction.richContent,
      table: [
        {
          key: "Title",
          value: "data",
        },
        {
          key: "Title 2",
          value: "data",
        },
        {
          key: "Title 3",
          value: "data",
        },
      ],
      serviceList: [
        {
          tabTitle: "On-Page SEO",
          tabSubTitle:
            "Optimize your website’s content, structure, and metadata to boost rankings, improve user experience, and attract organic traffic.",
          parentSlug: "seo-services-phoenix",
          slug: "on-page-seo",
          detail: {
            title: "On-Page SEO Services",
            subTitle:
              "Unlock your website's potential with strategic on-page SEO, giving businesses a competitive edge in Phoenix and beyond.",
            metaTitle:
              "On-Page SEO Services | Improve Rankings & User Experience",
            metaDescription:
              "Optimize your website’s content, structure, and metadata with expert on-page SEO strategies designed to improve search rankings and increase traffic.",
            image: "",
            onPage: onPageSEOData.richContent,
          },
        },
        {
          tabTitle: "Off-Page SEO",
          tabSubTitle:
            "Strengthen your website’s authority with high-quality backlinks, influencer outreach, and strategic brand mentions.",
          parentSlug: "seo-services-phoenix",
          slug: "off-page-seo",
          detail: {
            title: "Off-Page SEO Services",
            subTitle:
              "Boost your website’s credibility and search visibility with powerful off-page SEO strategies.",
            metaTitle:
              "Off-Page SEO Services | Strengthen Your Online Authority",
            metaDescription:
              "Increase your website's authority and rankings with expert off-page SEO, including strategic link building and brand engagement.",
            image: "",
            onPage: offPageSEOData.richContent,
          },
        },
        {
          tabTitle: "Technical SEO",
          tabSubTitle:
            "Optimize your website’s speed, mobile-friendliness, and security to improve search rankings and user experience.",
          parentSlug: "seo-services-phoenix",
          slug: "technical-seo",
          detail: {
            title: "Technical SEO Services",
            subTitle:
              "Ensure your website is optimized for performance, accessibility, and search engine indexing.",
            metaTitle:
              "Technical SEO Services | Improve Website Speed & Performance",
            metaDescription:
              "Enhance your website’s speed, security, and mobile optimization with expert technical SEO solutions.",
            image: "",
            onPage: technicalSEOData.richContent,
          },
        },
        {
          tabTitle: "Local SEO",
          tabSubTitle:
            "Boost your business visibility in local search results and attract customers from Phoenix and surrounding communities.",
          parentSlug: "seo-services-phoenix",
          slug: "local-seo",
          detail: {
            title: "Local SEO Services",
            subTitle:
              "Help your business stand out in local search and connect with nearby customers.",
            metaTitle: "Local SEO Services | Dominate Local Search Results",
            metaDescription:
              "Increase your visibility in local search and attract more customers with expert local SEO strategies, including Google My Business optimization and local citations.",
            image: "",
            onPage: localSEOData.richContent,
          },
        },
        {
          tabTitle: "E-comme SEO",
          tabSubTitle:
            "Optimize your online store with targeted strategies to improve product visibility, increase traffic, and drive sales.",
          parentSlug: "seo-services-phoenix",
          slug: "ecommerce-seo",
          detail: {
            title: "E-commerce SEO Services",
            subTitle:
              "Maximize your store’s potential with specialized E-commerce SEO solutions designed to drive traffic and boost conversions.",
            metaTitle: "E-commerce SEO Services | Grow Your Online Sales",
            metaDescription:
              "Optimize your e-commerce site with expert SEO strategies that increase product visibility and improve conversions.",
            image: "",
            onPage: ecommerceSEOData.richContent,
          },
        },
        {
          tabTitle: "Google My Business",
          tabSubTitle:
            "Optimize your Google Business Profile to enhance local credibility and attract more customers.",
          parentSlug: "seo-services-phoenix",
          slug: "gmp",
          detail: {
            title: "Google Business Profile Optimization",
            subTitle:
              "Increase local visibility and engagement with an optimized Google Business Profile.",
            metaTitle:
              "Google Business Profile Services | Improve Local Search Visibility",
            metaDescription:
              "Enhance your local presence with expert Google Business Profile optimization, driving more traffic to your business.",
            image: "",
            onPage: googleBusinessProfileData.richContent,
          },
        },
      ],
    },
    {
      title:
        "How LYDB Became the #1 Life Coaching Resource Through Strategic SEO",
      subTitle:
        "Relationship & Self-Discovery Coaching Case Study: 72.5K Clicks & 6K Rankings",
      summery:
        "Drove 72.5K coaching leads- for LYDB using emotional-intelligence SEO – ranked #1 for 'broken heart recovery' & 6k+ keywords. 210+ monthly inquiries secured!",
      slug: "life-coaching-seo-case-study",
      metaTitle:
        "Life Coach SEO Success | Let Your Dreams Begin Case Study | Iillest Finds",
      metaDescription:
        "Discover how we drove 72,500+ organic clicks for certified life coach Mitzi Bockmann using relationship-focused SEO strategies.",
      category: "SEO",
      image: "/images/case-study/coaching-leads-case-study.jpg",
      client: "Elite Fashions",
      address: "New York, USA",
      table: [
        {
          key: "Title",
          value: "data",
        },
        {
          key: "Title 2",
          value: "data",
        },
        {
          key: "Title 3",
          value: "data",
        },
      ],
      desc: caseForBockmann.richContent,
      serviceList: [
        {
          tabTitle: "On-Page SEO",
          tabSubTitle:
            "Optimize your website’s content, structure, and metadata to boost rankings, improve user experience, and attract organic traffic.",
          parentSlug: "seo-services-phoenix",
          slug: "on-page-seo",
          detail: {
            title: "On-Page SEO Services",
            subTitle:
              "Unlock your website's potential with strategic on-page SEO, giving businesses a competitive edge in Phoenix and beyond.",
            metaTitle:
              "On-Page SEO Services | Improve Rankings & User Experience",
            metaDescription:
              "Optimize your website’s content, structure, and metadata with expert on-page SEO strategies designed to improve search rankings and increase traffic.",
            image: "",
            onPage: onPageSEOData.richContent,
          },
        },
        {
          tabTitle: "Off-Page SEO",
          tabSubTitle:
            "Strengthen your website’s authority with high-quality backlinks, influencer outreach, and strategic brand mentions.",
          parentSlug: "seo-services-phoenix",
          slug: "off-page-seo",
          detail: {
            title: "Off-Page SEO Services",
            subTitle:
              "Boost your website’s credibility and search visibility with powerful off-page SEO strategies.",
            metaTitle:
              "Off-Page SEO Services | Strengthen Your Online Authority",
            metaDescription:
              "Increase your website's authority and rankings with expert off-page SEO, including strategic link building and brand engagement.",
            image: "",
            onPage: offPageSEOData.richContent,
          },
        },
        {
          tabTitle: "Technical SEO",
          tabSubTitle:
            "Optimize your website’s speed, mobile-friendliness, and security to improve search rankings and user experience.",
          parentSlug: "seo-services-phoenix",
          slug: "technical-seo",
          detail: {
            title: "Technical SEO Services",
            subTitle:
              "Ensure your website is optimized for performance, accessibility, and search engine indexing.",
            metaTitle:
              "Technical SEO Services | Improve Website Speed & Performance",
            metaDescription:
              "Enhance your website’s speed, security, and mobile optimization with expert technical SEO solutions.",
            image: "",
            onPage: technicalSEOData.richContent,
          },
        },
        {
          tabTitle: "Local SEO",
          tabSubTitle:
            "Boost your business visibility in local search results and attract customers from Phoenix and surrounding communities.",
          parentSlug: "seo-services-phoenix",
          slug: "local-seo",
          detail: {
            title: "Local SEO Services",
            subTitle:
              "Help your business stand out in local search and connect with nearby customers.",
            metaTitle: "Local SEO Services | Dominate Local Search Results",
            metaDescription:
              "Increase your visibility in local search and attract more customers with expert local SEO strategies, including Google My Business optimization and local citations.",
            image: "",
            onPage: localSEOData.richContent,
          },
        },
        {
          tabTitle: "E-comme SEO",
          tabSubTitle:
            "Optimize your online store with targeted strategies to improve product visibility, increase traffic, and drive sales.",
          parentSlug: "seo-services-phoenix",
          slug: "ecommerce-seo",
          detail: {
            title: "E-commerce SEO Services",
            subTitle:
              "Maximize your store’s potential with specialized E-commerce SEO solutions designed to drive traffic and boost conversions.",
            metaTitle: "E-commerce SEO Services | Grow Your Online Sales",
            metaDescription:
              "Optimize your e-commerce site with expert SEO strategies that increase product visibility and improve conversions.",
            image: "",
            onPage: ecommerceSEOData.richContent,
          },
        },
        {
          tabTitle: "Google My Business",
          tabSubTitle:
            "Optimize your Google Business Profile to enhance local credibility and attract more customers.",
          parentSlug: "seo-services-phoenix",
          slug: "gmp",
          detail: {
            title: "Google Business Profile Optimization",
            subTitle:
              "Increase local visibility and engagement with an optimized Google Business Profile.",
            metaTitle:
              "Google Business Profile Services | Improve Local Search Visibility",
            metaDescription:
              "Enhance your local presence with expert Google Business Profile optimization, driving more traffic to your business.",
            image: "",
            onPage: googleBusinessProfileData.richContent,
          },
        },
      ],
    },
    {
      title:
        "How We Built a Flutter-Powered Inventory Revolution for UK Auto Parts",
      subTitle: "Paddock Dock Case Study: Cross-Platform Management Solution",
      summery:
        "Built UK's first Flutter-based auto inventory system – 98.7% scan accuracy & real-time web/mobile sync. Reduced stock errors from 18% to 0.9%.",
      slug: "paddock-dock-flutter-development-case-study",
      metaTitle:
        "Flutter Auto Parts App Development | Paddock Dock Case Study | Iillest Finds",
      metaDescription:
        "Discover how we built a barcode-scanning inventory system for UK auto businesses using Flutter. iOS/Android + Web sync included.  ",
      category: "Website Development",
      image: "/images/case-study/paddock-case-study.jpg",
      client: "Tech Innovators",
      address: "San Francisco, USA",
      table: [
        {
          key: "Title",
          value: "data",
        },
        {
          key: "Title 2",
          value: "data",
        },
        {
          key: "Title 3",
          value: "data",
        },
      ],
      desc: caseForPaddock.richContent,
      serviceList: [
        {
          tabTitle: "Landing Page Development",
          tabSubTitle:
            "Design high-converting landing pages that instantly capture leads and showcase your brand with impactful messaging.",
          parentSlug: "website-development-phoenix",
          slug: "landing-page-development",
          detail: {
            title: "Landing Page Development",
            subTitle:
              "Turn visitors into customers with conversion-focused landing pages designed to drive sales and engagement.",
            metaTitle:
              "Landing Page Development | High-Converting Webpages for Your Business",
            metaDescription:
              "Boost your conversions with expertly designed landing pages. We create fast, engaging, and visually compelling pages tailored to your business goals.",
            image: "",
            onPage: landingPageDevelopmentData.richContent,
          },
        },

        {
          tabTitle: "WordPress Website Development",
          tabSubTitle:
            "Build SEO-friendly, scalable WordPress websites that are easy to manage and customized to your business needs.",
          parentSlug: "website-development-phoenix",
          slug: "wordpress-website-development",
          detail: {
            title: "WordPress Website Development",
            subTitle:
              "Harness the power of WordPress with a custom, user-friendly website designed for performance and growth.",
            metaTitle:
              "WordPress Website Development | Custom, SEO-Optimized Websites",
            metaDescription:
              "Create a stunning and functional website with our WordPress development services. We design SEO-friendly, responsive websites that enhance your brand's online presence.",
            image: "",
            onPage: wordpressWebsiteDevelopmentData.richContent,
          },
        },

        {
          tabTitle: "Custom Website Development",
          tabSubTitle:
            "Get a fully customized website tailored to your brand, built with the latest technologies for high performance and scalability.",
          parentSlug: "website-development-phoenix",
          slug: "custom-website-development",
          detail: {
            title: "Custom Website Development",
            subTitle:
              "Stand out with a bespoke website built to match your brand’s unique needs and deliver exceptional user experiences.",
            metaTitle:
              "Custom Website Development | Tailored Digital Solutions",
            metaDescription:
              "Transform your business with a fully customized website. We develop feature-rich, high-performance websites using cutting-edge technologies like React, Next.js, Vue.js, and Laravel.",
            image: "",
            onPage: customWebsiteDevelopmentData.richContent,
          },
        },
        {
          tabTitle: "E-Commerce Store Development",
          tabSubTitle:
            "Develop a seamless, high-performing e-commerce website that enhances the shopping experience and boosts online sales.",
          parentSlug: "website-development-phoenix",
          slug: "ecommerce-website-development",
          detail: {
            title: "E-Commerce Store Development",
            subTitle:
              "Launch and grow your online store with a fully optimized e-commerce platform designed for conversions.",
            metaTitle:
              "E-Commerce Website Development | Scalable Online Store Solutions",
            metaDescription:
              "Build a high-performing online store with our expert e-commerce development services. We create seamless, conversion-driven shopping experiences that increase sales and customer retention.",
            image: "",
            onPage: eCommStoreDevelopmentData.richContent,
          },
        },
        {
          tabTitle: "Website Redesign & Optimization",
          tabSubTitle:
            "Revamp outdated websites with modern designs and optimization strategies to enhance user experience and improve search rankings.",
          parentSlug: "website-development-phoenix",
          slug: "website-redesign-optimization",
          detail: {
            title: "Website Redesign & Optimization",
            subTitle:
              "Give your website a fresh new look with enhanced functionality, speed, and user experience.",
            metaTitle:
              "Website Redesign & Optimization | Upgrade Your Online Presence",
            metaDescription:
              "Revitalize your website with modern design updates, improved performance, and strategic SEO enhancements to attract and retain visitors.",
            image: "",
            onPage: websiteRedesignOptimizationData.richContent,
          },
        },

        {
          tabTitle: "Speed & Performance Optimization",
          tabSubTitle:
            "Enhance website speed and performance with advanced optimization techniques to improve user experience and rankings.",
          parentSlug: "website-development-phoenix",
          slug: "speed-performance-optimization",
          detail: {
            title: "Speed & Performance Optimization",
            subTitle:
              "Ensure lightning-fast load times and smooth navigation with expert website performance enhancements.",
            metaTitle:
              "Speed & Performance Optimization | Faster Load Times & Better UX",
            metaDescription:
              "Optimize your website’s speed and performance to provide a seamless browsing experience, improve rankings, and boost engagement.",
            image: "",
            onPage: speedPerformanceOptimizationData.richContent,
          },
        },
      ],
    },
  ],
};
