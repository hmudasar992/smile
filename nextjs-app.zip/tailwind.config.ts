import type { Config } from "tailwindcss";

export default {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        background: "var(--background)",
        foreground: "var(--foreground)",
        border: "#EBEAED",
        primary: "#040503",
      },
      backgroundImage: {
        gradient: "var(--gradientBackground)",
        "gradient-light": "var(--gradientLight)",
      },
      fontFamily: {
        space: ["var(--font-space-grotesk)", "sans-serif"],
      },
      boxShadow: {
        custom: "0px 4px 24px 0px rgba(35, 57, 94, 0.29)",
        blog: "2.87px 4.3px 9.32px 0px #D7D7D740",
        "blog-hover": "2.87px 4.3px 24.32px 0px rgba(0, 0, 0, 0.30)",
      },
      animation: {
        slideIn: "slideIn 0.4s cubic-bezier(0.4, 0, 0.2, 1) forwards",
        "ring-effect": "ringPulse 1.5s infinite ease-out",
        "pulse-effect": "pulseScale 1.5s infinite",
        shimmer: "shimmer 2s infinite", // Added shimmer animation
      },
      keyframes: {
        slideIn: {
          "0%": { opacity: "0", transform: "translateY(-8px) scale(0.98)" },
          "100%": { opacity: "1", transform: "translateY(0) scale(1)" },
        },
        ringPulse: {
          "0%": { transform: "scale(1)", opacity: "0.6" },
          "100%": { transform: "scale(1.5)", opacity: "0" },
        },
        pulseScale: {
          "0%, 100%": { transform: "scale(1)" },
          "50%": { transform: "scale(1.1)" },
        },
        // Added shimmer keyframes
        shimmer: {
          "100%": { transform: "translateX(100%)" },
        },
      },
    },
  },
  plugins: [],
} satisfies Config;