(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_f04e2a._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_f04e2a._.js",
  "chunks": [
    "static/chunks/src_app_8ebc15._.js",
    "static/chunks/node_modules_ee6a3f._.js",
    "static/chunks/node_modules_swiper_bae032._.css"
  ],
  "source": "dynamic"
});
