(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_tsx_61af54._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_tsx_61af54._.js",
  "chunks": [
    "static/chunks/[root of the server]__6e162e._.css",
    "static/chunks/src_app_19dc24._.js",
    "static/chunks/node_modules_next_88393e._.js"
  ],
  "source": "dynamic"
});
