(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_blog_error_tsx_f04e2a._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_blog_error_tsx_f04e2a._.js",
  "chunks": [
    "static/chunks/src_app_blog_error_tsx_714600._.js"
  ],
  "source": "dynamic"
});
