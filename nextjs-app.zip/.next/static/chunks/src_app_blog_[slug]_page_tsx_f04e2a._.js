(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_blog_[slug]_page_tsx_f04e2a._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_blog_[slug]_page_tsx_f04e2a._.js",
  "chunks": [
    "static/chunks/node_modules_swiper_364bcf._.js",
    "static/chunks/src_app_a0e8d9._.js",
    "static/chunks/_12cd26._.css"
  ],
  "source": "dynamic"
});
