(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/src_app_19dc24._.js", {

"[project]/src/app/utils/imageLoader.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
// src/app/utils/imageLoader.js
__turbopack_esm__({
    "default": (()=>customImageLoader)
});
function customImageLoader({ src, width, quality }) {
    // Handle local images
    if (src.startsWith('/') || src.includes('iillestfindsagency.com/images/')) {
        return `${src}?w=${width}&q=${quality || 75}`;
    }
    // Handle remote CMS images
    const decodedSrc = decodeURIComponent(src);
    const [baseUrl, existingQuery] = decodedSrc.split('?');
    const params = [
        `w=${width}`
    ];
    if (quality) {
        params.push(`q=${quality}`);
    }
    const queryString = existingQuery ? `${existingQuery}&${params.join('&')}` : params.join('&');
    return `${baseUrl}?${queryString}`;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/SVG.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "AngleRight": (()=>AngleRight),
    "AngleRightColor": (()=>AngleRightColor),
    "BusinessGrowthIcon": (()=>BusinessGrowthIcon),
    "CallIcon": (()=>CallIcon),
    "ChevronRight": (()=>ChevronRight),
    "DoubleChevronRight": (()=>DoubleChevronRight),
    "Email": (()=>Email),
    "EmailWhite": (()=>EmailWhite),
    "Facebook": (()=>Facebook),
    "FolderOpen": (()=>FolderOpen),
    "Instagram": (()=>Instagram),
    "LearnMoreIcon": (()=>LearnMoreIcon),
    "Location": (()=>Location),
    "LocationWhite": (()=>LocationWhite),
    "Phone": (()=>Phone),
    "PhoneWhite": (()=>PhoneWhite),
    "Pinterest": (()=>Pinterest),
    "PlayIcon": (()=>PlayIcon),
    "Plus": (()=>Plus),
    "Question": (()=>Question),
    "Star": (()=>Star),
    "TickIcon": (()=>TickIcon),
    "TickIcon2": (()=>TickIcon2),
    "Tiktok": (()=>Tiktok),
    "Twitter": (()=>Twitter),
    "User": (()=>User),
    "UserName": (()=>UserName),
    "WhatsAppIcon": (()=>WhatsAppIcon),
    "YourEmail": (()=>YourEmail)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
const WhatsAppIcon = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "35",
        height: "35",
        viewBox: "0 0 35 35",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                clipPath: "url(#clip0_17_15)",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        d: "M0.746777 17.2906C0.745957 20.2313 1.52033 23.1026 2.99279 25.6335L0.605957 34.2807L9.52439 31.9603C11.9911 33.2928 14.7549 33.9909 17.5635 33.9912H17.5708C26.8424 33.9912 34.3897 26.5051 34.3937 17.3038C34.3954 12.845 32.6471 8.65238 29.4706 5.49803C26.2946 2.34397 22.0707 0.606039 17.5702 0.604004C8.29748 0.604004 0.750742 8.08966 0.746914 17.2906",
                        fill: "url(#paint0_linear_17_15)"
                    }, void 0, false, {
                        fileName: "[project]/src/app/SVG.tsx",
                        lineNumber: 11,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        d: "M0.146289 17.2851C0.145332 20.3316 0.947461 23.3057 2.47242 25.9271L0 34.8843L9.23822 32.4808C11.7837 33.8579 14.6496 34.5839 17.5658 34.585H17.5733C27.1775 34.585 34.9959 26.8297 35 17.299C35.0016 12.68 33.1904 8.33665 29.9004 5.0693C26.61 1.80236 22.235 0.00189922 17.5733 0C7.96742 0 0.150117 7.75426 0.146289 17.2851ZM5.64799 25.4757L5.30305 24.9323C3.85301 22.6446 3.08766 20.0009 3.08875 17.2862C3.09176 9.3644 9.58918 2.91938 17.5788 2.91938C21.4479 2.92101 25.0841 4.4176 27.819 7.13295C30.5538 9.84857 32.0586 13.4584 32.0577 17.2979C32.0541 25.2197 25.5566 31.6655 17.5733 31.6655H17.5675C14.9681 31.6641 12.4187 30.9715 10.1954 29.6625L9.66629 29.3512L4.18414 30.7773L5.64799 25.4757Z",
                        fill: "url(#paint1_linear_17_15)"
                    }, void 0, false, {
                        fileName: "[project]/src/app/SVG.tsx",
                        lineNumber: 15,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        d: "M13.2177 10.0588C12.8915 9.33943 12.5482 9.32491 12.2379 9.3123C11.9839 9.30145 11.6935 9.30226 11.4034 9.30226C11.113 9.30226 10.6412 9.41065 10.2424 9.84273C9.84318 10.2752 8.71826 11.3203 8.71826 13.446C8.71826 15.5716 10.2786 17.626 10.4962 17.9146C10.7139 18.2026 13.5085 22.7043 17.9343 24.4361C21.6126 25.8753 22.3612 25.5891 23.1595 25.5169C23.9579 25.445 25.7358 24.472 26.0985 23.4632C26.4615 22.4544 26.4615 21.5897 26.3527 21.409C26.2438 21.229 25.9534 21.1209 25.518 20.9049C25.0825 20.6889 22.9417 19.6435 22.5426 19.4993C22.1434 19.3553 21.8531 19.2834 21.5627 19.716C21.2723 20.1479 20.4385 21.1209 20.1843 21.409C19.9304 21.6978 19.6763 21.7338 19.241 21.5177C18.8052 21.3009 17.4029 20.8452 15.7392 19.3734C14.4447 18.2282 13.5708 16.814 13.3168 16.3813C13.0628 15.9494 13.2896 15.7153 13.5079 15.5C13.7036 15.3064 13.9435 14.9955 14.1614 14.7433C14.3786 14.4909 14.451 14.3109 14.5962 14.0228C14.7415 13.7344 14.6688 13.482 14.5601 13.2659C14.451 13.0498 13.6049 10.9131 13.2177 10.0588Z",
                        fill: "white"
                    }, void 0, false, {
                        fileName: "[project]/src/app/SVG.tsx",
                        lineNumber: 19,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 10,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("linearGradient", {
                        id: "paint0_linear_17_15",
                        x1: "1689.99",
                        y1: "3368.27",
                        x2: "1689.99",
                        y2: "0.604004",
                        gradientUnits: "userSpaceOnUse",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                                stopColor: "#1FAF38"
                            }, void 0, false, {
                                fileName: "[project]/src/app/SVG.tsx",
                                lineNumber: 33,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                                offset: "1",
                                stopColor: "#60D669"
                            }, void 0, false, {
                                fileName: "[project]/src/app/SVG.tsx",
                                lineNumber: 34,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/SVG.tsx",
                        lineNumber: 25,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("linearGradient", {
                        id: "paint1_linear_17_15",
                        x1: "1750",
                        y1: "3488.43",
                        x2: "1750",
                        y2: "0",
                        gradientUnits: "userSpaceOnUse",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                                stopColor: "#F9F9F9"
                            }, void 0, false, {
                                fileName: "[project]/src/app/SVG.tsx",
                                lineNumber: 44,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                                offset: "1",
                                stopColor: "white"
                            }, void 0, false, {
                                fileName: "[project]/src/app/SVG.tsx",
                                lineNumber: 45,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/SVG.tsx",
                        lineNumber: 36,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("clipPath", {
                        id: "clip0_17_15",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            width: "35",
                            height: "35",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/src/app/SVG.tsx",
                            lineNumber: 48,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/SVG.tsx",
                        lineNumber: 47,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 24,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/SVG.tsx",
        lineNumber: 3,
        columnNumber: 5
    }, this);
};
_c = WhatsAppIcon;
const PlayIcon = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "29",
        height: "36",
        viewBox: "0 0 29 36",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M27.5355 20.9021L4.46963 35.1049C2.51213 36.309 0 34.851 0 32.4236V4.01797C0 1.59442 2.5085 0.132586 4.46963 1.34052L27.5355 15.5433C27.9808 15.8131 28.3509 16.203 28.6084 16.6736C28.8658 17.1442 29.0014 17.6786 29.0014 18.2227C29.0014 18.7668 28.8658 19.3013 28.6084 19.7719C28.3509 20.2424 27.9808 20.6323 27.5355 20.9021Z",
            fill: "white"
        }, void 0, false, {
            fileName: "[project]/src/app/SVG.tsx",
            lineNumber: 64,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/SVG.tsx",
        lineNumber: 57,
        columnNumber: 5
    }, this);
};
_c1 = PlayIcon;
const LearnMoreIcon = ({ className })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "36",
        height: "36",
        viewBox: "0 0 41 42",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        className: className,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                cx: "20.5",
                cy: "20.6516",
                r: "20.5",
                fill: "url(#paint0_linear_1_146)"
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 81,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M11.25 24.8526C10.5326 25.2668 10.2867 26.1842 10.701 26.9016C11.1152 27.6191 12.0326 27.8649 12.75 27.4506L11.25 24.8526ZM30.7694 16.5398C30.9838 15.7396 30.5089 14.9171 29.7087 14.7027L16.6687 11.2087C15.8685 10.9943 15.046 11.4691 14.8316 12.2693C14.6172 13.0695 15.0921 13.892 15.8923 14.1064L27.4834 17.2123L24.3776 28.8034C24.1631 29.6036 24.638 30.4261 25.4382 30.6405C26.2384 30.8549 27.0609 30.38 27.2753 29.5798L30.7694 16.5398ZM12.75 27.4506L30.0705 17.4506L28.5705 14.8526L11.25 24.8526L12.75 27.4506Z",
                fill: "#F5F5F7"
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 87,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("linearGradient", {
                    id: "paint0_linear_1_146",
                    x1: "20.5",
                    y1: "0.151611",
                    x2: "20.5",
                    y2: "41.1516",
                    gradientUnits: "userSpaceOnUse",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                            stopColor: "#40254F"
                        }, void 0, false, {
                            fileName: "[project]/src/app/SVG.tsx",
                            lineNumber: 100,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                            offset: "1",
                            stopColor: "#1A0E24"
                        }, void 0, false, {
                            fileName: "[project]/src/app/SVG.tsx",
                            lineNumber: 101,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/SVG.tsx",
                    lineNumber: 92,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 91,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/SVG.tsx",
        lineNumber: 73,
        columnNumber: 5
    }, this);
};
_c2 = LearnMoreIcon;
const TickIcon = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "20",
        height: "20",
        viewBox: "0 0 20 20",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M6.01685 10.3464L8.44132 12.7709L13.983 7.22925",
            stroke: "black",
            strokeWidth: "1.25",
            strokeLinecap: "round",
            strokeLinejoin: "round"
        }, void 0, false, {
            fileName: "[project]/src/app/SVG.tsx",
            lineNumber: 116,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/SVG.tsx",
        lineNumber: 109,
        columnNumber: 5
    }, this);
};
_c3 = TickIcon;
const TickIcon2 = ({ className })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "21",
        height: "20",
        viewBox: "0 0 21 20",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        className: className,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M1.25 13.701C0.532561 14.1152 0.286748 15.0326 0.700962 15.75C1.11518 16.4674 2.03256 16.7133 2.75 16.299L1.25 13.701ZM20.7694 5.38823C20.9838 4.58803 20.5089 3.76552 19.7087 3.55111L6.66874 0.0570541C5.86854 -0.157359 5.04603 0.317515 4.83162 1.11771C4.61721 1.91791 5.09208 2.74042 5.89228 2.95483L17.4834 6.06066L14.3776 17.6518C14.1631 18.452 14.638 19.2745 15.4382 19.4889C16.2384 19.7033 17.0609 19.2284 17.2753 18.4282L20.7694 5.38823ZM2.75 16.299L20.0705 6.29904L18.5705 3.70096L1.25 13.701L2.75 16.299Z",
                fill: "url(#paint0_linear_4_219)"
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 136,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("linearGradient", {
                    id: "paint0_linear_4_219",
                    x1: "10.6603",
                    y1: "10",
                    x2: "11.1603",
                    y2: "10.866",
                    gradientUnits: "userSpaceOnUse",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                            stopColor: "#40254F"
                        }, void 0, false, {
                            fileName: "[project]/src/app/SVG.tsx",
                            lineNumber: 149,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                            offset: "1",
                            stopColor: "#1A0E24"
                        }, void 0, false, {
                            fileName: "[project]/src/app/SVG.tsx",
                            lineNumber: 150,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/SVG.tsx",
                    lineNumber: 141,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 140,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/SVG.tsx",
        lineNumber: 128,
        columnNumber: 5
    }, this);
};
_c4 = TickIcon2;
const Star = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "18",
        height: "16",
        viewBox: "0 0 18 16",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M8.84124 0L10.9027 5.94811H17.5739L12.1768 9.62424L14.2383 15.5724L8.84124 11.8962L3.44416 15.5724L5.50566 9.62424L0.108582 5.94811H6.77974L8.84124 0Z",
            fill: "#FBB040"
        }, void 0, false, {
            fileName: "[project]/src/app/SVG.tsx",
            lineNumber: 165,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/SVG.tsx",
        lineNumber: 158,
        columnNumber: 5
    }, this);
};
_c5 = Star;
const Plus = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "20",
        height: "20",
        viewBox: "0 0 20 20",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M10 4.1665V15.8332",
                stroke: "#151515",
                strokeWidth: "1.6",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 181,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M4.16699 10H15.8336",
                stroke: "#151515",
                strokeWidth: "1.6",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 188,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/SVG.tsx",
        lineNumber: 174,
        columnNumber: 5
    }, this);
};
_c6 = Plus;
const Question = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "68",
        height: "64",
        viewBox: "0 0 68 64",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M13.7977 53.0397L0.5 63.9531V0.953125H67.5V53.0397H13.7977Z",
                fill: "url(#paint0_linear_42_53)"
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 208,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("linearGradient", {
                    id: "paint0_linear_42_53",
                    x1: "34",
                    y1: "0.953125",
                    x2: "34",
                    y2: "63.9531",
                    gradientUnits: "userSpaceOnUse",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                            stopColor: "#40254F"
                        }, void 0, false, {
                            fileName: "[project]/src/app/SVG.tsx",
                            lineNumber: 221,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                            offset: "1",
                            stopColor: "#1A0E24"
                        }, void 0, false, {
                            fileName: "[project]/src/app/SVG.tsx",
                            lineNumber: 222,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/SVG.tsx",
                    lineNumber: 213,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 212,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/SVG.tsx",
        lineNumber: 201,
        columnNumber: 5
    }, this);
};
_c7 = Question;
const Facebook = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "10",
        height: "16",
        viewBox: "0 0 10 16",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M8.71875 9L9.15625 6.125H6.375V4.25C6.375 3.4375 6.75 2.6875 8 2.6875H9.28125V0.21875C9.28125 0.21875 8.125 0 7.03125 0C4.75 0 3.25 1.40625 3.25 3.90625V6.125H0.6875V9H3.25V16H6.375V9H8.71875Z",
            fill: "white"
        }, void 0, false, {
            fileName: "[project]/src/app/SVG.tsx",
            lineNumber: 237,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/SVG.tsx",
        lineNumber: 230,
        columnNumber: 5
    }, this);
};
_c8 = Facebook;
const Instagram = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "15",
        height: "15",
        viewBox: "0 0 15 15",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M8 3.40625C6 3.40625 4.40625 5.03125 4.40625 7C4.40625 9 6 10.5938 8 10.5938C9.96875 10.5938 11.5938 9 11.5938 7C11.5938 5.03125 9.96875 3.40625 8 3.40625ZM8 9.34375C6.71875 9.34375 5.65625 8.3125 5.65625 7C5.65625 5.71875 6.6875 4.6875 8 4.6875C9.28125 4.6875 10.3125 5.71875 10.3125 7C10.3125 8.3125 9.28125 9.34375 8 9.34375ZM12.5625 3.28125C12.5625 3.75 12.1875 4.125 11.7188 4.125C11.25 4.125 10.875 3.75 10.875 3.28125C10.875 2.8125 11.25 2.4375 11.7188 2.4375C12.1875 2.4375 12.5625 2.8125 12.5625 3.28125ZM14.9375 4.125C14.875 3 14.625 2 13.8125 1.1875C13 0.375 12 0.125 10.875 0.0625C9.71875 0 6.25 0 5.09375 0.0625C3.96875 0.125 3 0.375 2.15625 1.1875C1.34375 2 1.09375 3 1.03125 4.125C0.96875 5.28125 0.96875 8.75 1.03125 9.90625C1.09375 11.0312 1.34375 12 2.15625 12.8438C3 13.6562 3.96875 13.9062 5.09375 13.9688C6.25 14.0312 9.71875 14.0312 10.875 13.9688C12 13.9062 13 13.6562 13.8125 12.8438C14.625 12 14.875 11.0312 14.9375 9.90625C15 8.75 15 5.28125 14.9375 4.125ZM13.4375 11.125C13.2188 11.75 12.7188 12.2188 12.125 12.4688C11.1875 12.8438 9 12.75 8 12.75C6.96875 12.75 4.78125 12.8438 3.875 12.4688C3.25 12.2188 2.78125 11.75 2.53125 11.125C2.15625 10.2188 2.25 8.03125 2.25 7C2.25 6 2.15625 3.8125 2.53125 2.875C2.78125 2.28125 3.25 1.8125 3.875 1.5625C4.78125 1.1875 6.96875 1.28125 8 1.28125C9 1.28125 11.1875 1.1875 12.125 1.5625C12.7188 1.78125 13.1875 2.28125 13.4375 2.875C13.8125 3.8125 13.7188 6 13.7188 7C13.7188 8.03125 13.8125 10.2188 13.4375 11.125Z",
            fill: "white"
        }, void 0, false, {
            fileName: "[project]/src/app/SVG.tsx",
            lineNumber: 253,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/SVG.tsx",
        lineNumber: 246,
        columnNumber: 5
    }, this);
};
_c9 = Instagram;
const Twitter = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "16",
        height: "14",
        viewBox: "0 0 16 14",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M14.3438 3.75C14.3438 3.90625 14.3438 4.03125 14.3438 4.1875C14.3438 8.53125 11.0625 13.5 5.03125 13.5C3.15625 13.5 1.4375 12.9688 0 12.0312C0.25 12.0625 0.5 12.0938 0.78125 12.0938C2.3125 12.0938 3.71875 11.5625 4.84375 10.6875C3.40625 10.6562 2.1875 9.71875 1.78125 8.40625C2 8.4375 2.1875 8.46875 2.40625 8.46875C2.6875 8.46875 3 8.40625 3.25 8.34375C1.75 8.03125 0.625 6.71875 0.625 5.125V5.09375C1.0625 5.34375 1.59375 5.46875 2.125 5.5C1.21875 4.90625 0.65625 3.90625 0.65625 2.78125C0.65625 2.15625 0.8125 1.59375 1.09375 1.125C2.71875 3.09375 5.15625 4.40625 7.875 4.5625C7.8125 4.3125 7.78125 4.0625 7.78125 3.8125C7.78125 2 9.25 0.53125 11.0625 0.53125C12 0.53125 12.8438 0.90625 13.4688 1.5625C14.1875 1.40625 14.9062 1.125 15.5312 0.75C15.2812 1.53125 14.7812 2.15625 14.0938 2.5625C14.75 2.5 15.4062 2.3125 15.9688 2.0625C15.5312 2.71875 14.9688 3.28125 14.3438 3.75Z",
            fill: "white"
        }, void 0, false, {
            fileName: "[project]/src/app/SVG.tsx",
            lineNumber: 269,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/SVG.tsx",
        lineNumber: 262,
        columnNumber: 5
    }, this);
};
_c10 = Twitter;
const Pinterest = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "11",
        height: "15",
        viewBox: "0 0 11 15",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M5.57812 0.941406C2.76172 0.941406 0 2.80078 0 5.83594C0 7.75 1.06641 8.84375 1.72266 8.84375C1.99609 8.84375 2.16016 8.10547 2.16016 7.88672C2.16016 7.64062 1.50391 7.09375 1.50391 6.02734C1.50391 3.83984 3.17188 2.28125 5.33203 2.28125C7.21875 2.28125 8.58594 3.34766 8.58594 5.28906C8.58594 6.73828 8.01172 9.44531 6.125 9.44531C5.44141 9.44531 4.83984 8.95312 4.83984 8.26953C4.83984 7.23047 5.57812 6.21875 5.57812 5.15234C5.57812 3.34766 3.00781 3.67578 3.00781 5.86328C3.00781 6.32812 3.0625 6.82031 3.28125 7.25781C2.89844 8.87109 2.13281 11.3047 2.13281 12.9727C2.13281 13.4922 2.1875 13.9844 2.24219 14.5039C2.32422 14.6133 2.29688 14.6133 2.43359 14.5586C3.80078 12.6719 3.77344 12.2891 4.375 9.82812C4.73047 10.457 5.57812 10.8125 6.28906 10.8125C9.1875 10.8125 10.5 7.96875 10.5 5.42578C10.5 2.71875 8.14844 0.941406 5.57812 0.941406Z",
            fill: "white"
        }, void 0, false, {
            fileName: "[project]/src/app/SVG.tsx",
            lineNumber: 285,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/SVG.tsx",
        lineNumber: 278,
        columnNumber: 5
    }, this);
};
_c11 = Pinterest;
const Email = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: "14",
        height: "11",
        viewBox: "0 0 14 11",
        fill: "none",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M12.6875 0.5C13.3984 0.5 14 1.10156 14 1.8125C14 2.25 13.7812 2.63281 13.4531 2.87891L7.51953 7.33594C7.19141 7.58203 6.78125 7.58203 6.45312 7.33594L0.519531 2.87891C0.191406 2.63281 0 2.25 0 1.8125C0 1.10156 0.574219 0.5 1.3125 0.5H12.6875ZM5.93359 8.04688C6.5625 8.51172 7.41016 8.51172 8.03906 8.04688L14 3.5625V9.25C14 10.2344 13.207 11 12.25 11H1.75C0.765625 11 0 10.2344 0 9.25V3.5625L5.93359 8.04688Z",
                fill: "#40254F"
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 301,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("linearGradient", {
                    id: "paint0_linear_44_94",
                    x1: "8",
                    y1: "-1",
                    x2: "8",
                    y2: "15",
                    gradientUnits: "userSpaceOnUse",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                            stopColor: "#40254F"
                        }, void 0, false, {
                            fileName: "[project]/src/app/SVG.tsx",
                            lineNumber: 314,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                            offset: "1",
                            stopColor: "#1A0E24"
                        }, void 0, false, {
                            fileName: "[project]/src/app/SVG.tsx",
                            lineNumber: 315,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/SVG.tsx",
                    lineNumber: 306,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 305,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/SVG.tsx",
        lineNumber: 294,
        columnNumber: 5
    }, this);
};
_c12 = Email;
const Phone = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: "15",
        height: "15",
        viewBox: "0 0 15 15",
        fill: "none",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M13.9727 11.332L13.3164 14.0938C13.2344 14.5039 12.9062 14.7773 12.4961 14.7773C5.60547 14.75 0 9.14453 0 2.25391C0 1.84375 0.246094 1.51562 0.65625 1.43359L3.41797 0.777344C3.80078 0.695312 4.21094 0.914062 4.375 1.26953L5.66016 4.25C5.79688 4.60547 5.71484 5.01562 5.41406 5.23438L3.9375 6.4375C4.86719 8.32422 6.39844 9.85547 8.3125 10.7852L9.51562 9.30859C9.73438 9.03516 10.1445 8.92578 10.5 9.0625L13.4805 10.3477C13.8359 10.5391 14.0547 10.9492 13.9727 11.332Z",
                fill: "#40254F"
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 330,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("linearGradient", {
                    id: "paint0_linear_44_98",
                    x1: "7",
                    y1: "1",
                    x2: "7",
                    y2: "15",
                    gradientUnits: "userSpaceOnUse",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                            stopColor: "#40254F"
                        }, void 0, false, {
                            fileName: "[project]/src/app/SVG.tsx",
                            lineNumber: 343,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                            offset: "1",
                            stopColor: "#1A0E24"
                        }, void 0, false, {
                            fileName: "[project]/src/app/SVG.tsx",
                            lineNumber: 344,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/SVG.tsx",
                    lineNumber: 335,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 334,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/SVG.tsx",
        lineNumber: 323,
        columnNumber: 5
    }, this);
};
_c13 = Phone;
const Tiktok = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: "14",
        height: "14",
        viewBox: "0 0 24 24",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            fill: "#fff",
            d: "M16.6 5.82s.51.5 0 0A4.28 4.28 0 0 1 15.54 3h-3.09v12.4a2.59 2.59 0 0 1-2.59 2.5c-1.42 0-2.6-1.16-2.6-2.6c0-1.72 1.66-3.01 3.37-2.48V9.66c-3.45-.46-6.47 2.22-6.47 5.64c0 3.33 2.76 5.7 5.69 5.7c3.14 0 5.69-2.55 5.69-5.7V9.01a7.35 7.35 0 0 0 4.3 1.38V7.3s-1.88.09-3.24-1.48"
        }, void 0, false, {
            fileName: "[project]/src/app/SVG.tsx",
            lineNumber: 359,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/SVG.tsx",
        lineNumber: 353,
        columnNumber: 5
    }, this);
};
_c14 = Tiktok;
const Location = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: "14",
        height: "16",
        viewBox: "0 0 16 19",
        fill: "none",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M0.459385 7.13725C0.61186 5.29452 1.45142 3.57643 2.81152 2.32382C4.17161 1.07121 5.95286 0.375602 7.80189 0.375H8.19789C10.0469 0.375602 11.8282 1.07121 13.1883 2.32382C14.5483 3.57643 15.3879 5.29452 15.5404 7.13725C15.7096 9.19462 15.0744 11.2375 13.7685 12.8362L9.37489 18.2097C9.20836 18.4135 8.9986 18.5777 8.7608 18.6905C8.52299 18.8033 8.26308 18.8618 7.99989 18.8618C7.73669 18.8618 7.47678 18.8033 7.23897 18.6905C7.00117 18.5777 6.79141 18.4135 6.62489 18.2097L2.23222 12.8362C0.925933 11.2376 0.29044 9.19475 0.459385 7.13725ZM7.99989 3.8125C6.84509 3.8125 5.73759 4.27124 4.92102 5.08781C4.10446 5.90437 3.64572 7.01187 3.64572 8.16667C3.64572 9.32146 4.10446 10.429 4.92102 11.2455C5.73759 12.0621 6.84509 12.5208 7.99989 12.5208C9.15468 12.5208 10.2622 12.0621 11.0787 11.2455C11.8953 10.429 12.3541 9.32146 12.3541 8.16667C12.3541 7.01187 11.8953 5.90437 11.0787 5.08781C10.2622 4.27124 9.15468 3.8125 7.99989 3.8125Z",
                fill: "#40254F"
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 375,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("linearGradient", {
                    id: "paint0_linear_44_106",
                    x1: "7.99993",
                    y1: "0.375",
                    x2: "7.99993",
                    y2: "18.8618",
                    gradientUnits: "userSpaceOnUse",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                            stopColor: "#40254F"
                        }, void 0, false, {
                            fileName: "[project]/src/app/SVG.tsx",
                            lineNumber: 390,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                            offset: "1",
                            stopColor: "#1A0E24"
                        }, void 0, false, {
                            fileName: "[project]/src/app/SVG.tsx",
                            lineNumber: 391,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/SVG.tsx",
                    lineNumber: 382,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 381,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/SVG.tsx",
        lineNumber: 368,
        columnNumber: 5
    }, this);
};
_c15 = Location;
const EmailWhite = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "14",
        height: "11",
        viewBox: "0 0 14 11",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M12.6875 0.5C13.3984 0.5 14 1.10156 14 1.8125C14 2.25 13.7812 2.63281 13.4531 2.87891L7.51953 7.33594C7.19141 7.58203 6.78125 7.58203 6.45312 7.33594L0.519531 2.87891C0.191406 2.63281 0 2.25 0 1.8125C0 1.10156 0.574219 0.5 1.3125 0.5H12.6875ZM5.93359 8.04688C6.5625 8.51172 7.41016 8.51172 8.03906 8.04688L14 3.5625V9.25C14 10.2344 13.207 11 12.25 11H1.75C0.765625 11 0 10.2344 0 9.25V3.5625L5.93359 8.04688Z",
                fill: "url(#paint0_linear_44_94)"
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 406,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("linearGradient", {
                    id: "paint0_linear_44_94",
                    x1: "8",
                    y1: "-1",
                    x2: "8",
                    y2: "15",
                    gradientUnits: "userSpaceOnUse",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                            stopColor: "#ffffff"
                        }, void 0, false, {
                            fileName: "[project]/src/app/SVG.tsx",
                            lineNumber: 419,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                            offset: "1",
                            stopColor: "#f7f7f7"
                        }, void 0, false, {
                            fileName: "[project]/src/app/SVG.tsx",
                            lineNumber: 420,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/SVG.tsx",
                    lineNumber: 411,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 410,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/SVG.tsx",
        lineNumber: 399,
        columnNumber: 5
    }, this);
};
_c16 = EmailWhite;
const PhoneWhite = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "15",
        height: "15",
        viewBox: "0 0 15 15",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M13.9727 11.332L13.3164 14.0938C13.2344 14.5039 12.9062 14.7773 12.4961 14.7773C5.60547 14.75 0 9.14453 0 2.25391C0 1.84375 0.246094 1.51562 0.65625 1.43359L3.41797 0.777344C3.80078 0.695312 4.21094 0.914062 4.375 1.26953L5.66016 4.25C5.79688 4.60547 5.71484 5.01562 5.41406 5.23438L3.9375 6.4375C4.86719 8.32422 6.39844 9.85547 8.3125 10.7852L9.51562 9.30859C9.73438 9.03516 10.1445 8.92578 10.5 9.0625L13.4805 10.3477C13.8359 10.5391 14.0547 10.9492 13.9727 11.332Z",
                fill: "url(#paint0_linear_44_98)"
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 435,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("linearGradient", {
                    id: "paint0_linear_44_98",
                    x1: "7",
                    y1: "1",
                    x2: "7",
                    y2: "15",
                    gradientUnits: "userSpaceOnUse",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                            stopColor: "#ffffff"
                        }, void 0, false, {
                            fileName: "[project]/src/app/SVG.tsx",
                            lineNumber: 448,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                            offset: "1",
                            stopColor: "#f7f7f7"
                        }, void 0, false, {
                            fileName: "[project]/src/app/SVG.tsx",
                            lineNumber: 449,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/SVG.tsx",
                    lineNumber: 440,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 439,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/SVG.tsx",
        lineNumber: 428,
        columnNumber: 5
    }, this);
};
_c17 = PhoneWhite;
const LocationWhite = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "14",
        height: "16",
        viewBox: "0 0 16 19",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M0.459385 7.13725C0.61186 5.29452 1.45142 3.57643 2.81152 2.32382C4.17161 1.07121 5.95286 0.375602 7.80189 0.375H8.19789C10.0469 0.375602 11.8282 1.07121 13.1883 2.32382C14.5483 3.57643 15.3879 5.29452 15.5404 7.13725C15.7096 9.19462 15.0744 11.2375 13.7685 12.8362L9.37489 18.2097C9.20836 18.4135 8.9986 18.5777 8.7608 18.6905C8.52299 18.8033 8.26308 18.8618 7.99989 18.8618C7.73669 18.8618 7.47678 18.8033 7.23897 18.6905C7.00117 18.5777 6.79141 18.4135 6.62489 18.2097L2.23222 12.8362C0.925933 11.2376 0.29044 9.19475 0.459385 7.13725ZM7.99989 3.8125C6.84509 3.8125 5.73759 4.27124 4.92102 5.08781C4.10446 5.90437 3.64572 7.01187 3.64572 8.16667C3.64572 9.32146 4.10446 10.429 4.92102 11.2455C5.73759 12.0621 6.84509 12.5208 7.99989 12.5208C9.15468 12.5208 10.2622 12.0621 11.0787 11.2455C11.8953 10.429 12.3541 9.32146 12.3541 8.16667C12.3541 7.01187 11.8953 5.90437 11.0787 5.08781C10.2622 4.27124 9.15468 3.8125 7.99989 3.8125Z",
                fill: "url(#paint0_linear_44_106)"
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 464,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("linearGradient", {
                    id: "paint0_linear_44_106",
                    x1: "7.99993",
                    y1: "0.375",
                    x2: "7.99993",
                    y2: "18.8618",
                    gradientUnits: "userSpaceOnUse",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                            stopColor: "#ffffff"
                        }, void 0, false, {
                            fileName: "[project]/src/app/SVG.tsx",
                            lineNumber: 479,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                            offset: "1",
                            stopColor: "#f7f7f7"
                        }, void 0, false, {
                            fileName: "[project]/src/app/SVG.tsx",
                            lineNumber: 480,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/SVG.tsx",
                    lineNumber: 471,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 470,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/SVG.tsx",
        lineNumber: 457,
        columnNumber: 5
    }, this);
};
_c18 = LocationWhite;
const BusinessGrowthIcon = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: "39",
        height: "39",
        viewBox: "0 0 39 39",
        fill: "none",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M26.0507 4.10298C25.9753 4.57443 25.9376 5.04589 25.9376 5.51734C25.9376 9.76042 29.3697 13.1907 33.594 13.1907C34.0654 13.1907 34.518 13.136 34.9895 13.0606V28.2772C34.9895 34.672 31.2178 38.4625 24.8061 38.4625H10.8718C4.45815 38.4625 0.686523 34.672 0.686523 28.2772V14.3241C0.686523 7.91232 4.45815 4.10298 10.8718 4.10298H26.0507ZM26.4298 15.5687C25.9187 15.5121 25.4114 15.7384 25.1078 16.1533L20.546 22.0559L15.3204 17.9448C14.9998 17.6997 14.6227 17.6035 14.2455 17.6431C13.8702 17.6997 13.5308 17.9052 13.3026 18.207L7.72249 25.4692L7.60746 25.639C7.28687 26.2405 7.43773 27.0137 8.00348 27.4305C8.26749 27.6002 8.55036 27.7134 8.87095 27.7134C9.30657 27.7322 9.71957 27.504 9.98358 27.1476L14.717 21.0546L20.0915 25.0921L20.2613 25.2033C20.8647 25.5239 21.619 25.375 22.0528 24.8073L27.5028 17.7751L27.4274 17.8128C27.7291 17.398 27.7857 16.8699 27.5782 16.3985C27.3727 15.927 26.9182 15.6064 26.4298 15.5687ZM33.8582 0.745667C36.3663 0.745667 38.403 2.78234 38.403 5.29048C38.403 7.79861 36.3663 9.83529 33.8582 9.83529C31.35 9.83529 29.3134 7.79861 29.3134 5.29048C29.3134 2.78234 31.35 0.745667 33.8582 0.745667Z",
            fill: "#392147"
        }, void 0, false, {
            fileName: "[project]/src/app/SVG.tsx",
            lineNumber: 495,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/SVG.tsx",
        lineNumber: 488,
        columnNumber: 5
    }, this);
};
_c19 = BusinessGrowthIcon;
const AngleRight = ({ fill })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "9",
        height: "13",
        viewBox: "0 0 9 13",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M2 12.5C1.71875 12.5 1.46875 12.4062 1.28125 12.2188C0.875 11.8438 0.875 11.1875 1.28125 10.8125L5.5625 6.5L1.28125 2.21875C0.875 1.84375 0.875 1.1875 1.28125 0.8125C1.65625 0.40625 2.3125 0.40625 2.6875 0.8125L7.6875 5.8125C8.09375 6.1875 8.09375 6.84375 7.6875 7.21875L2.6875 12.2188C2.5 12.4062 2.25 12.5 2 12.5Z",
            fill: fill ? fill : "#F5F5F7"
        }, void 0, false, {
            fileName: "[project]/src/app/SVG.tsx",
            lineNumber: 511,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/SVG.tsx",
        lineNumber: 504,
        columnNumber: 5
    }, this);
};
_c20 = AngleRight;
const AngleRightColor = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "15",
        height: "10",
        viewBox: "0 0 15 10",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M13.7266 5.37891L10.2266 8.87891C9.89844 9.23438 9.32422 9.23438 8.99609 8.87891C8.64062 8.55078 8.64062 7.97656 8.99609 7.64844L10.9922 5.625H0.875C0.382812 5.625 0 5.24219 0 4.75C0 4.23047 0.382812 3.875 0.875 3.875H10.9922L8.99609 1.87891C8.64062 1.55078 8.64062 0.976562 8.99609 0.648438C9.32422 0.292969 9.89844 0.292969 10.2266 0.648438L13.7266 4.14844C14.082 4.47656 14.082 5.05078 13.7266 5.37891Z",
                fill: "url(#paint0_linear_69_435)"
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 527,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("linearGradient", {
                    id: "paint0_linear_69_435",
                    x1: "7",
                    y1: "-2",
                    x2: "7",
                    y2: "12",
                    gradientUnits: "userSpaceOnUse",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                            stopColor: "#40254F"
                        }, void 0, false, {
                            fileName: "[project]/src/app/SVG.tsx",
                            lineNumber: 540,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                            offset: "1",
                            stopColor: "#1A0E24"
                        }, void 0, false, {
                            fileName: "[project]/src/app/SVG.tsx",
                            lineNumber: 541,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/SVG.tsx",
                    lineNumber: 532,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 531,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/SVG.tsx",
        lineNumber: 520,
        columnNumber: 5
    }, this);
};
_c21 = AngleRightColor;
const DoubleChevronRight = ({ fill, className })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "13",
        height: "11",
        viewBox: "0 0 13 11",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        className: className,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M6.72656 5.14844C7.08203 5.47656 7.08203 6.05078 6.72656 6.37891L2.35156 10.7539C2.1875 10.918 1.96875 11 1.75 11C1.50391 11 1.28516 10.918 1.12109 10.7539C0.765625 10.4258 0.765625 9.85156 1.12109 9.52344L4.86719 5.75L1.12109 2.00391C0.765625 1.67578 0.765625 1.10156 1.12109 0.773438C1.44922 0.417969 2.02344 0.417969 2.35156 0.773438L6.72656 5.14844ZM11.9766 5.14844C12.332 5.47656 12.332 6.05078 11.9766 6.37891L7.60156 10.7539C7.4375 10.918 7.21875 11 7 11C6.75391 11 6.53516 10.918 6.37109 10.7539C6.01562 10.4258 6.01562 9.85156 6.37109 9.52344L10.1172 5.75L6.37109 2.00391C6.01562 1.67578 6.01562 1.10156 6.37109 0.773438C6.69922 0.417969 7.27344 0.417969 7.60156 0.773438L11.9766 5.14844Z",
                fill: fill || "url(#paint0_linear_69_454)"
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 564,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("linearGradient", {
                    id: "paint0_linear_69_454",
                    x1: "7",
                    y1: "-1",
                    x2: "7",
                    y2: "13",
                    gradientUnits: "userSpaceOnUse",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                            stopColor: "#40254F"
                        }, void 0, false, {
                            fileName: "[project]/src/app/SVG.tsx",
                            lineNumber: 577,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                            offset: "1",
                            stopColor: "#1A0E24"
                        }, void 0, false, {
                            fileName: "[project]/src/app/SVG.tsx",
                            lineNumber: 578,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/SVG.tsx",
                    lineNumber: 569,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 568,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/SVG.tsx",
        lineNumber: 556,
        columnNumber: 5
    }, this);
};
_c22 = DoubleChevronRight;
const User = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "11",
        height: "13",
        viewBox: "0 0 11 13",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M6.375 7.59375C8.64844 7.59375 10.5 9.44531 10.5 11.7188C10.5 12.1406 10.1484 12.4688 9.75 12.4688H0.75C0.328125 12.4688 0 12.1406 0 11.7188C0 9.44531 1.82812 7.59375 4.125 7.59375H6.375ZM1.125 11.3438H9.35156C9.16406 9.86719 7.89844 8.71875 6.375 8.71875H4.125C2.57812 8.71875 1.3125 9.86719 1.125 11.3438ZM5.25 6.46875C3.58594 6.46875 2.25 5.13281 2.25 3.46875C2.25 1.82812 3.58594 0.46875 5.25 0.46875C6.89062 0.46875 8.25 1.82812 8.25 3.46875C8.25 5.13281 6.89062 6.46875 5.25 6.46875ZM5.25 1.59375C4.19531 1.59375 3.375 2.4375 3.375 3.46875C3.375 4.52344 4.19531 5.34375 5.25 5.34375C6.28125 5.34375 7.125 4.52344 7.125 3.46875C7.125 2.4375 6.28125 1.59375 5.25 1.59375Z",
                fill: "url(#paint0_linear_76_100)"
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 594,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("linearGradient", {
                    id: "paint0_linear_76_100",
                    x1: "5.5",
                    y1: "-0.03125",
                    x2: "5.5",
                    y2: "11.9257",
                    gradientUnits: "userSpaceOnUse",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                            stopColor: "#40254F"
                        }, void 0, false, {
                            fileName: "[project]/src/app/SVG.tsx",
                            lineNumber: 607,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                            offset: "1",
                            stopColor: "#1A0E24"
                        }, void 0, false, {
                            fileName: "[project]/src/app/SVG.tsx",
                            lineNumber: 608,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/SVG.tsx",
                    lineNumber: 599,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 598,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/SVG.tsx",
        lineNumber: 587,
        columnNumber: 5
    }, this);
};
_c23 = User;
const FolderOpen = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "14",
        height: "11",
        viewBox: "0 0 14 11",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M13.4062 5.82031L11.1562 10.3203C11.0391 10.5781 10.7812 10.7188 10.4766 10.7188H1.5C0.65625 10.7188 0 10.0625 0 9.21875V1.71875C0 0.898438 0.65625 0.21875 1.5 0.21875H4.24219C4.64062 0.21875 5.01562 0.382812 5.29688 0.664062L6.44531 1.71875H9.75C10.5703 1.71875 11.25 2.39844 11.25 3.21875V3.96875H10.125V3.21875C10.125 3.03125 9.9375 2.84375 9.75 2.84375H6L4.5 1.46094C4.42969 1.39062 4.33594 1.34375 4.24219 1.34375H1.5C1.28906 1.34375 1.125 1.53125 1.125 1.71875V8.46875L2.78906 5.14062C2.90625 4.88281 3.16406 4.71875 3.44531 4.71875H12.75C13.2891 4.71875 13.6641 5.30469 13.4062 5.82031Z",
                fill: "url(#paint0_linear_76_103)"
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 623,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("linearGradient", {
                    id: "paint0_linear_76_103",
                    x1: "7",
                    y1: "-1.03125",
                    x2: "7",
                    y2: "10.9257",
                    gradientUnits: "userSpaceOnUse",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                            stopColor: "#40254F"
                        }, void 0, false, {
                            fileName: "[project]/src/app/SVG.tsx",
                            lineNumber: 636,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                            offset: "1",
                            stopColor: "#1A0E24"
                        }, void 0, false, {
                            fileName: "[project]/src/app/SVG.tsx",
                            lineNumber: 637,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/SVG.tsx",
                    lineNumber: 628,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 627,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/SVG.tsx",
        lineNumber: 616,
        columnNumber: 5
    }, this);
};
_c24 = FolderOpen;
const ChevronRight = ({ fill, className })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "10",
        height: "16",
        viewBox: "0 0 10 16",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        className: className,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M1.17618 0.0940074C0.946907 0.0891488 0.721754 0.153185 0.532029 0.277311C0.342304 0.401438 0.197434 0.579519 0.11756 0.786639C0.0376862 0.993758 0.0267775 1.21968 0.0863502 1.43305C0.145923 1.64641 0.273017 1.83651 0.449963 1.97707L7.20145 7.54963L0.449963 13.1202C0.327561 13.2069 0.225052 13.3169 0.148855 13.4436C0.0726593 13.5702 0.0244179 13.7106 0.00715143 13.856C-0.010115 14.0014 0.00396594 14.1487 0.0485124 14.2886C0.0930588 14.4285 0.167111 14.5581 0.266031 14.6692C0.364952 14.7803 0.48661 14.8703 0.623387 14.934C0.760164 14.9977 0.909113 15.0335 1.06091 15.0391C1.2127 15.0447 1.36407 15.0202 1.50553 14.9669C1.64699 14.9136 1.7755 14.8327 1.88301 14.7293L9.61285 8.35727C9.73423 8.25747 9.83171 8.13359 9.89855 7.99398C9.96539 7.85436 10 7.7024 10 7.54865C10 7.3949 9.96539 7.24294 9.89855 7.10333C9.83171 6.96371 9.73423 6.83971 9.61285 6.73991L1.88301 0.36179C1.68774 0.194686 1.43729 0.0996824 1.17618 0.0937621V0.0940074Z",
            fill: fill ? fill : "#101A29"
        }, void 0, false, {
            fileName: "[project]/src/app/SVG.tsx",
            lineNumber: 656,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/SVG.tsx",
        lineNumber: 648,
        columnNumber: 5
    }, this);
};
_c25 = ChevronRight;
const CallIcon = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: "32",
        height: "32",
        viewBox: "0 0 32 32",
        fill: "none",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M7.60945 9.80126L10.2611 7.35792C10.3547 7.27112 10.4646 7.2038 10.5844 7.15988C10.7042 7.11596 10.8316 7.09632 10.959 7.10208C11.0865 7.10785 11.2115 7.13891 11.3269 7.19347C11.4422 7.24802 11.5456 7.32499 11.6311 7.41989L13.4607 9.44715C13.3723 9.56224 13.0983 9.82782 12.7448 10.2705L11.6576 11.6957C11.629 11.7307 11.6052 11.7695 11.5869 11.8108C11.2851 12.3438 11.097 12.9337 11.0346 13.5433C10.9722 14.1528 11.0369 14.7687 11.2245 15.3519C11.6546 16.5297 12.3364 17.5992 13.222 18.4857C14.0374 19.4436 15.0713 20.1906 16.236 20.6635C16.7849 20.8809 17.3777 20.9639 17.965 20.9054C18.5523 20.8468 19.1171 20.6486 19.6124 20.3271L21.115 19.3444C21.5835 19.0346 21.8751 18.7779 21.9989 18.6982L23.8285 20.69C23.9168 20.7827 23.9857 20.8921 24.0309 21.0119C24.0762 21.1317 24.097 21.2594 24.0921 21.3874C24.0871 21.5154 24.0565 21.6411 24.0022 21.757C23.9478 21.8729 23.8707 21.9767 23.7755 22.0622L21.1239 24.5144C20.3726 25.1961 18.8258 25.2669 17.1199 24.7534C15.5089 24.2737 14.036 23.4147 12.8243 22.2481L9.16507 18.3087C8.10629 17.0006 7.37314 15.4592 7.0261 13.8115C6.66371 12.0675 6.85816 10.5272 7.60945 9.80126ZM6.4781 8.615C5.02855 9.9429 4.96668 12.1561 5.39093 14.1568C5.77814 16.1142 6.65387 17.9415 7.93649 19.4684L11.5692 23.4344C12.9719 24.8392 14.7088 25.8629 16.6161 26.4089C18.596 27.0109 20.7703 27.1259 22.2199 25.7892L24.8715 23.3458C25.3844 22.8699 25.6889 22.2104 25.7187 21.5107C25.7485 20.8111 25.5012 20.1279 25.0306 19.61L23.2363 17.6182C23.007 17.3408 22.6986 17.1401 22.3524 17.0427C22.0102 16.9762 21.6556 17.026 21.3448 17.1844C20.9482 17.4167 20.5726 17.6833 20.2223 17.9811L18.7286 18.9726C18.4547 19.1591 18.1372 19.271 17.8071 19.2974C17.4771 19.3238 17.1458 19.2637 16.8459 19.1231C15.9315 18.7223 15.1211 18.1165 14.4771 17.3526C13.765 16.6347 13.2109 15.7752 12.8508 14.8296C12.7174 14.4655 12.6672 14.0761 12.7039 13.69C12.7406 13.3039 12.8633 12.931 13.0629 12.5987L14.1148 11.2797C14.4381 10.9506 14.7338 10.5953 14.9986 10.2173C15.1808 9.92085 15.2586 9.57178 15.2196 9.22584C15.1577 8.8634 14.9847 8.52924 14.7246 8.26975L12.8597 6.32216C12.3845 5.80843 11.726 5.50345 11.0274 5.47361C10.3289 5.44376 9.64682 5.69147 9.12971 6.16281L6.4781 8.615Z",
                fill: "#C4C4C4"
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 672,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M7.78631 7.38449C7.63973 7.54716 7.55859 7.7585 7.55859 7.97762C7.55859 8.19675 7.63973 8.40808 7.78631 8.57075L11.4455 12.5633C11.6024 12.7163 11.8104 12.8056 12.0292 12.8137C12.2481 12.8219 12.4621 12.7484 12.6299 12.6076C12.7107 12.5338 12.7762 12.4449 12.8227 12.3457C12.8691 12.2466 12.8955 12.1393 12.9004 12.0299C12.9054 11.9205 12.8887 11.8112 12.8514 11.7083C12.8141 11.6054 12.7568 11.5109 12.683 11.4302L8.97954 7.43761C8.9057 7.35402 8.81582 7.28615 8.71526 7.23806C8.61469 7.18997 8.5055 7.16264 8.39417 7.15768C8.28284 7.15273 8.17166 7.17025 8.06723 7.20922C7.9628 7.24818 7.86727 7.30779 7.78631 7.38449Z",
                fill: "#C4C4C4"
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 676,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M18.7726 19.3445C18.6261 19.5071 18.5449 19.7185 18.5449 19.9376C18.5449 20.1567 18.6261 20.368 18.7726 20.5307L22.4407 24.5233C22.5907 24.6864 22.7993 24.7832 23.0206 24.7924C23.2419 24.8015 23.4578 24.7222 23.6207 24.572C23.7836 24.4217 23.8803 24.2128 23.8894 23.9911C23.8985 23.7695 23.8193 23.5533 23.6693 23.3901L19.9659 19.3976C19.892 19.314 19.8022 19.2461 19.7016 19.198C19.601 19.1499 19.4918 19.1226 19.3805 19.1176C19.2692 19.1127 19.158 19.1302 19.0536 19.1692C18.9491 19.2081 18.8536 19.2678 18.7726 19.3445Z",
                fill: "#C4C4C4"
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 680,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M19.214 8.91598C19.0924 9.02867 19.0071 9.17523 18.9692 9.33682C18.9314 9.49842 18.9426 9.66767 19.0015 9.82281C19.0605 9.97795 19.1644 10.1119 19.2999 10.2074C19.4354 10.303 19.5964 10.3558 19.762 10.359C20.2842 10.3842 20.7751 10.6153 21.1278 11.0017C21.4805 11.3881 21.6663 11.8985 21.6447 12.4216C21.6406 12.5309 21.6581 12.6399 21.6961 12.7424C21.7341 12.845 21.7919 12.939 21.8662 13.0191C21.9404 13.0993 22.0298 13.164 22.129 13.2096C22.2283 13.2551 22.3355 13.2807 22.4446 13.2848C22.5537 13.2888 22.6625 13.2713 22.7649 13.2333C22.8673 13.1952 22.9611 13.1373 23.0412 13.0629C23.1212 12.9886 23.1858 12.8991 23.2313 12.7997C23.2768 12.7003 23.3023 12.5929 23.3064 12.4836C23.3365 11.9951 23.2675 11.5055 23.1034 11.0445C22.9394 10.5834 22.6837 10.1605 22.3518 9.80124C21.6958 9.09334 20.7874 8.67339 19.8239 8.63269C19.5913 8.64298 19.3721 8.74478 19.214 8.91598Z",
                fill: "#C4C4C4"
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 684,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M19.3022 5.43692C19.1954 5.5554 19.1248 5.70218 19.0989 5.85974C19.073 6.0173 19.093 6.17899 19.1563 6.32551C19.2197 6.47204 19.3238 6.59721 19.4563 6.68609C19.5887 6.77498 19.7439 6.82382 19.9033 6.82679C20.6227 6.85637 21.3293 7.0279 21.9824 7.33156C22.6356 7.63521 23.2224 8.06501 23.7094 8.59631C24.1963 9.12761 24.5738 9.74996 24.8201 10.4277C25.0663 11.1054 25.1766 11.8251 25.1446 12.5456C25.1323 12.7747 25.2092 12.9997 25.3593 13.1731C25.5093 13.3465 25.7208 13.4548 25.949 13.4751C26.1834 13.4751 26.4082 13.3819 26.5739 13.2159C26.7397 13.0498 26.8328 12.8247 26.8328 12.5899C26.8719 11.6498 26.7249 10.7113 26.4004 9.82832C26.0758 8.94537 25.5801 8.13542 24.9418 7.44509C24.3035 6.75477 23.5352 6.1977 22.6811 5.80596C21.827 5.41421 20.904 5.19553 19.9651 5.16249C19.8412 5.15573 19.7173 5.17687 19.6026 5.22436C19.4879 5.27185 19.3852 5.34448 19.3022 5.43692Z",
                fill: "#C4C4C4"
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 688,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M17.7557 12.9174C17.6751 12.9918 17.6098 13.0814 17.5637 13.1811C17.5176 13.2807 17.4916 13.3885 17.487 13.4982C17.4825 13.608 17.4996 13.7175 17.5374 13.8207C17.5752 13.9238 17.6328 14.0184 17.7071 14.0992C17.7814 14.18 17.8708 14.2454 17.9703 14.2916C18.0698 14.3377 18.1775 14.3638 18.287 14.3684C18.3966 14.3729 18.506 14.3557 18.6089 14.3179C18.7119 14.2801 18.8064 14.2223 18.8871 14.1479L19.55 13.5371C19.7129 13.3868 19.8096 13.1779 19.8187 12.9563C19.8278 12.7346 19.7486 12.5184 19.5986 12.3553C19.4486 12.1921 19.24 12.0953 19.0187 12.0862C18.7974 12.077 18.5815 12.1563 18.4186 12.3066L17.7557 12.9174Z",
                fill: "#C4C4C4"
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 692,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/SVG.tsx",
        lineNumber: 665,
        columnNumber: 5
    }, this);
};
_c26 = CallIcon;
const UserName = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: "32",
        height: "33",
        viewBox: "0 0 32 33",
        fill: "none",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M21.2714 16.4226C21.1393 16.3169 20.9807 16.2288 20.8398 16.1319C20.7429 16.0174 20.6195 15.9381 20.4698 15.8852C19.5272 15.3479 18.4614 15.0308 17.4043 15.0308C17.1841 15.0308 16.9815 15.1189 16.8229 15.2686L15.7482 16.3521L14.6648 15.2774C14.515 15.1189 14.3036 15.0396 14.0834 15.0396C13.0175 15.0396 11.934 15.3655 10.9915 15.9116C10.8593 15.9557 10.7536 16.035 10.6655 16.1319C10.5158 16.2288 10.3572 16.3169 10.2163 16.4226C9.11518 17.2858 8.26953 18.5455 8.26953 20.0166V22.5095C8.26953 25.2578 10.507 27.4865 13.2553 27.4865H18.2412C20.9895 27.4865 23.227 25.2578 23.227 22.5095V20.0166C23.2182 18.5455 22.3725 17.2858 21.2714 16.4226ZM17.6686 16.7837C18.109 16.819 18.5759 16.907 19.0251 17.0744L18.0738 18.6688L16.9286 17.5237L17.6686 16.7837ZM14.5767 17.5237L13.4315 18.6688L12.4802 17.0744C12.9294 16.9159 13.3963 16.819 13.8367 16.7837L14.5767 17.5237ZM21.5621 22.5095C21.5621 24.3593 20.091 25.8216 18.2412 25.8216H13.2553C11.3967 25.8216 9.9344 24.3593 9.9344 22.5095V20.0166C9.9344 19.259 10.366 18.5279 11.0531 17.9201L12.5506 20.4394C12.8237 20.9063 13.4668 20.9855 13.8543 20.6068L15.7482 18.6952L17.651 20.598C18.0386 20.9767 18.6728 20.8975 18.9547 20.4306L20.4522 17.9113C21.1393 18.5191 21.5709 19.2502 21.5709 20.0078V22.5095H21.5621Z",
                fill: "#C4C4C4"
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 708,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M15.7486 13.3747C17.8011 13.3747 19.4924 11.6922 19.4924 9.63974C19.4924 7.58728 17.8099 5.90479 15.7486 5.90479C13.6962 5.90479 12.0137 7.58728 12.0137 9.63974C12.0137 11.6922 13.6874 13.3747 15.7486 13.3747ZM15.7486 7.56085C16.9026 7.56085 17.8275 8.48578 17.8275 9.63974C17.8275 10.7937 16.9026 11.7186 15.7486 11.7186C14.5947 11.7186 13.6785 10.7937 13.6785 9.63974C13.6785 8.48578 14.5859 7.56085 15.7486 7.56085Z",
                fill: "#C4C4C4"
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 712,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M19.0687 21.6726H18.2406C17.1307 21.6726 17.1307 23.3375 18.2406 23.3375H19.0687C20.1698 23.3375 20.1698 21.6726 19.0687 21.6726Z",
                fill: "#857F7F"
            }, void 0, false, {
                fileName: "[project]/src/app/SVG.tsx",
                lineNumber: 716,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/SVG.tsx",
        lineNumber: 701,
        columnNumber: 5
    }, this);
};
_c27 = UserName;
const YourEmail = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: "32",
        height: "33",
        viewBox: "0 0 32 33",
        fill: "none",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            fillRule: "evenodd",
            clipRule: "evenodd",
            d: "M7.33571 15.6217L12.8429 19.4359L10.5071 21.7787C10.4434 21.8397 10.3925 21.9128 10.3573 21.9937C10.3222 22.0747 10.3035 22.1618 10.3024 22.25C10.3012 22.3382 10.3177 22.4258 10.3508 22.5076C10.3839 22.5894 10.4329 22.6637 10.4951 22.7264C10.5572 22.789 10.6312 22.8386 10.7128 22.8723C10.7943 22.906 10.8818 22.9232 10.97 22.9227C11.0582 22.9223 11.1455 22.9042 11.2267 22.8697C11.3079 22.8351 11.3813 22.7848 11.4429 22.7215L13.9571 20.2073L15.6214 21.3644C15.7326 21.4415 15.8647 21.4828 16 21.4828C16.1353 21.4828 16.2674 21.4415 16.3786 21.3644L18.0429 20.2073L20.55 22.7215C20.6119 22.7834 20.6854 22.8325 20.7663 22.866C20.8472 22.8995 20.9339 22.9168 21.0214 22.9168C21.109 22.9168 21.1957 22.8995 21.2766 22.866C21.3575 22.8325 21.4309 22.7834 21.4929 22.7215C21.5548 22.6596 21.6039 22.5861 21.6374 22.5052C21.6709 22.4243 21.6881 22.3377 21.6881 22.2501C21.6881 22.1626 21.6709 22.0759 21.6374 21.995C21.6039 21.9141 21.5548 21.8406 21.4929 21.7787L19.1571 19.4359L24.6643 15.6217V22.9644C24.6662 23.2541 24.6106 23.5414 24.5008 23.8096C24.391 24.0777 24.2291 24.3215 24.0246 24.5267C23.82 24.7319 23.5768 24.8946 23.309 25.0052C23.0412 25.1159 22.7541 25.1724 22.4643 25.1715H9.57143C9.28165 25.1724 8.99456 25.1159 8.72675 25.0052C8.45894 24.8946 8.21572 24.7319 8.01114 24.5267C7.80657 24.3215 7.64471 24.0777 7.5349 23.8096C7.4251 23.5414 7.36954 23.2541 7.37143 22.9644L7.33571 15.6217ZM12.4286 13.686C12.2634 13.7031 12.1103 13.7809 11.9991 13.9042C11.8879 14.0276 11.8263 14.1878 11.8263 14.3539C11.8263 14.52 11.8879 14.6802 11.9991 14.8035C12.1103 14.9269 12.2634 15.0046 12.4286 15.0217H19.5714C19.6649 15.0314 19.7594 15.0213 19.8488 14.9922C19.9382 14.963 20.0204 14.9154 20.0902 14.8525C20.1601 14.7895 20.2159 14.7126 20.2541 14.6267C20.2923 14.5408 20.312 14.4479 20.312 14.3539C20.312 14.2599 20.2923 14.1669 20.2541 14.081C20.2159 13.9951 20.1601 13.9182 20.0902 13.8553C20.0204 13.7923 19.9382 13.7447 19.8488 13.7156C19.7594 13.6864 19.6649 13.6763 19.5714 13.686H12.4286ZM22.4286 13.3789L24.1143 14.3932L22.4286 15.5646V13.3789ZM9.57143 13.3789V15.5217L7.9 14.3932L9.57143 13.3789ZM12.3429 10.0718C12.1629 10.0832 11.9948 10.1656 11.8756 10.3009C11.7564 10.4362 11.6958 10.6133 11.7071 10.7932C11.7185 10.9732 11.8009 11.1413 11.9362 11.2605C12.0715 11.3797 12.2486 11.4403 12.4286 11.4289H16C16.18 11.4289 16.3526 11.3574 16.4798 11.2302C16.6071 11.1029 16.6786 10.9303 16.6786 10.7504C16.6786 10.5704 16.6071 10.3978 16.4798 10.2706C16.3526 10.1433 16.18 10.0718 16 10.0718H12.3429ZM18.8143 8.99328L20.3214 10.7861H18.8143V8.99328ZM11.7143 7.83617H17.5071V11.5004C17.5071 11.6784 17.5779 11.8492 17.7038 11.9751C17.8297 12.101 18.0005 12.1718 18.1786 12.1718H21.1V16.5002L16 20.0002L10.9214 16.5002V8.64329C10.9209 8.54206 10.9409 8.44178 10.9802 8.34849C11.0195 8.2552 11.0772 8.17082 11.15 8.10045C11.218 8.01663 11.3041 7.94931 11.4018 7.90353C11.4995 7.85776 11.6064 7.83473 11.7143 7.83617ZM18.1429 6.50048H11.7143C11.146 6.50048 10.6009 6.72624 10.1991 7.1281C9.79719 7.52995 9.57143 8.07498 9.57143 8.64329V11.8575L6.36429 13.786C6.25835 13.8404 6.16878 13.922 6.10476 14.0224C6.04075 14.1228 6.00459 14.2384 6 14.3574V22.9644C6.00941 23.9053 6.38984 24.8046 7.05859 25.4666C7.72735 26.1287 8.63038 26.5 9.57143 26.5H22.5C23.4286 26.4815 24.3135 26.1019 24.9669 25.4418C25.6203 24.7818 25.9909 23.8931 26 22.9644V14.3574C25.9993 14.2293 25.9619 14.104 25.8923 13.9965C25.8227 13.8889 25.7237 13.8035 25.6071 13.7503L22.4286 11.8218V11.6718C22.4561 11.5639 22.4554 11.4508 22.4267 11.3432C22.3979 11.2356 22.342 11.1373 22.2643 11.0575L18.6929 6.77191C18.6311 6.68443 18.5484 6.61378 18.4523 6.56638C18.3563 6.51898 18.2499 6.49633 18.1429 6.50048Z",
            fill: "#C4C4C4"
        }, void 0, false, {
            fileName: "[project]/src/app/SVG.tsx",
            lineNumber: 732,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/SVG.tsx",
        lineNumber: 725,
        columnNumber: 5
    }, this);
};
_c28 = YourEmail;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11, _c12, _c13, _c14, _c15, _c16, _c17, _c18, _c19, _c20, _c21, _c22, _c23, _c24, _c25, _c26, _c27, _c28;
__turbopack_refresh__.register(_c, "WhatsAppIcon");
__turbopack_refresh__.register(_c1, "PlayIcon");
__turbopack_refresh__.register(_c2, "LearnMoreIcon");
__turbopack_refresh__.register(_c3, "TickIcon");
__turbopack_refresh__.register(_c4, "TickIcon2");
__turbopack_refresh__.register(_c5, "Star");
__turbopack_refresh__.register(_c6, "Plus");
__turbopack_refresh__.register(_c7, "Question");
__turbopack_refresh__.register(_c8, "Facebook");
__turbopack_refresh__.register(_c9, "Instagram");
__turbopack_refresh__.register(_c10, "Twitter");
__turbopack_refresh__.register(_c11, "Pinterest");
__turbopack_refresh__.register(_c12, "Email");
__turbopack_refresh__.register(_c13, "Phone");
__turbopack_refresh__.register(_c14, "Tiktok");
__turbopack_refresh__.register(_c15, "Location");
__turbopack_refresh__.register(_c16, "EmailWhite");
__turbopack_refresh__.register(_c17, "PhoneWhite");
__turbopack_refresh__.register(_c18, "LocationWhite");
__turbopack_refresh__.register(_c19, "BusinessGrowthIcon");
__turbopack_refresh__.register(_c20, "AngleRight");
__turbopack_refresh__.register(_c21, "AngleRightColor");
__turbopack_refresh__.register(_c22, "DoubleChevronRight");
__turbopack_refresh__.register(_c23, "User");
__turbopack_refresh__.register(_c24, "FolderOpen");
__turbopack_refresh__.register(_c25, "ChevronRight");
__turbopack_refresh__.register(_c26, "CallIcon");
__turbopack_refresh__.register(_c27, "UserName");
__turbopack_refresh__.register(_c28, "YourEmail");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/components/Button.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$SVG$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/app/SVG.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
;
;
;
const Button = ({ varient = "default", text, className = "", icon, path = "#", onClick })=>{
    // If onClick is provided, use button element
    if (onClick) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            onClick: onClick,
            className: `bg-gradient text-white text-[14px] inline-flex items-center justify-center py-4 px-[50px] rounded-[10px] ${className || ''}`,
            children: text
        }, void 0, false, {
            fileName: "[project]/src/app/components/Button.tsx",
            lineNumber: 19,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        className: `py-2 lg:py-3 px-4 lg:px-5 xl:px-7 relative inline-flex items-center justify-center overflow-hidden group rounded-[14px] font-bold transition ease text-[14px] lg:text-base xl:text-[18px] 2xl:text-[20px] ${varient === "primary" ? "bg-gradient text-white" : varient === "secondary" ? "bg-[#f5f5f7]" : "bg-white"} ${className}`,
        href: path,
        prefetch: true,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: `duration-400 ease absolute left-0 top-1/2 block h-0 w-full ${varient === "primary" ? "bg-gradient" : varient === "secondary" ? "bg-[#f5f5f7]" : "bg-white"} opacity-100 transition-all group-hover:top-0 group-hover:h-full`
            }, void 0, false, {
                fileName: "[project]/src/app/components/Button.tsx",
                lineNumber: 40,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "ease absolute right-0 top-1/2 -translate-y-1/2 flex h-5 w-6 translate-x-2 opacity-0 group-hover:opacity-[1] transform items-center justify-start duration-500 group-hover:translate-x-full",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            className: "h-5 w-5",
                            fill: "none",
                            stroke: "currentColor",
                            viewBox: "0 0 24 24",
                            xmlns: "http://www.w3.org/2000/svg",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: "2",
                                d: "M14 5l7 7m0 0l-7 7m7-7H3"
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/Button.tsx",
                                lineNumber: 58,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/Button.tsx",
                            lineNumber: 51,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/components/Button.tsx",
                        lineNumber: 50,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: `relative ${varient !== "primary" && " gradient-text"} ${icon && "gap-3"} transform ease transform duration-700 group-hover:-translate-x-3 flex items-center`,
                        children: [
                            icon === "WhatsAppIcon" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$SVG$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WhatsAppIcon"], {}, void 0, false, {
                                fileName: "[project]/src/app/components/Button.tsx",
                                lineNumber: 71,
                                columnNumber: 39
                            }, this),
                            text
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/components/Button.tsx",
                        lineNumber: 66,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/components/Button.tsx",
                lineNumber: 49,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/components/Button.tsx",
        lineNumber: 29,
        columnNumber: 5
    }, this);
};
_c = Button;
const __TURBOPACK__default__export__ = Button;
var _c;
__turbopack_refresh__.register(_c, "Button");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/components/Header.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/app/components/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$SVG$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/app/SVG.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_refresh__.signature();
"use client";
;
;
;
;
;
;
const headerMenu = [
    {
        name: "Home",
        path: "/"
    },
    {
        name: "Services",
        path: "/services"
    },
    {
        name: "Case Study",
        path: "/case-study"
    },
    {
        name: "Blog",
        path: "/blog"
    }
];
const Header = ()=>{
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const [isScrolled, setIsScrolled] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showMenu, setShowMenu] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Header.useEffect": ()=>{
            const handleScroll = {
                "Header.useEffect.handleScroll": ()=>{
                    setIsScrolled(window.scrollY > 5);
                }
            }["Header.useEffect.handleScroll"];
            window.addEventListener("scroll", handleScroll);
            return ({
                "Header.useEffect": ()=>window.removeEventListener("scroll", handleScroll)
            })["Header.useEffect"];
        }
    }["Header.useEffect"], []);
    const handleShowMenu = ()=>{
        setShowMenu(true);
    };
    const handleCloseMenu = ()=>{
        setShowMenu(false);
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Header.useEffect": ()=>{
            if (showMenu) {
                document.body.style.overflow = "hidden";
            } else {
                document.body.style.overflow = "auto";
            }
            return ({
                "Header.useEffect": ()=>{
                    document.body.classList.remove("overflow-hidden");
                }
            })["Header.useEffect"];
        }
    }["Header.useEffect"], [
        showMenu
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Header.useEffect": ()=>{
            setShowMenu(false);
        }
    }["Header.useEffect"], [
        pathname
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Header.useEffect": ()=>{
            console.log("Pathname changed:", pathname);
            console.log("Search params changed:", searchParams.toString());
        }
    }["Header.useEffect"], [
        pathname,
        searchParams
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Fragment, {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                className: `fixed w-full top-0 left-0 z-50 transition-all duration-300 ${isScrolled ? "lg:-translate-y-[44px] 2xl:-translate-y-[65px]" : ""}`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `bg-gradient hidden lg:block`,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "container mx-auto px-4 md:px-6",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                className: "flex gap-2 items-center justify-evenly",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        className: "flex gap-3 items-center text-[14px] lg:text-base 2xl:text-[18px] font-[400] leading-[20px] 2xl:leading-[25px] text-white md:py-2 lg:py-3 2xl:py-5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$SVG$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EmailWhite"], {}, void 0, false, {
                                                fileName: "[project]/src/app/components/Header.tsx",
                                                lineNumber: 67,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                href: "mailto:faeezahlun@iillestfinds.com",
                                                children: "faeezahlun@iillestfinds.com"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/components/Header.tsx",
                                                lineNumber: 68,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/components/Header.tsx",
                                        lineNumber: 66,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        className: "flex gap-3 items-center text-[14px] lg:text-base 2xl:text-[18px] font-[400] leading-[20px] 2xl:leading-[25px] text-white md:py-2 lg:py-3 2xl:py-5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$SVG$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PhoneWhite"], {}, void 0, false, {
                                                fileName: "[project]/src/app/components/Header.tsx",
                                                lineNumber: 73,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                href: "tel:+19258184494",
                                                children: "(+1) 925-818-4494"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/components/Header.tsx",
                                                lineNumber: 74,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/components/Header.tsx",
                                        lineNumber: 72,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        className: "flex gap-3 items-center text-[14px] lg:text-base 2xl:text-[18px] font-[400] leading-[20px] 2xl:leading-[25px] text-white md:py-2 lg:py-3 2xl:py-5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$SVG$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LocationWhite"], {}, void 0, false, {
                                                fileName: "[project]/src/app/components/Header.tsx",
                                                lineNumber: 77,
                                                columnNumber: 3
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                href: "https://www.google.com/maps/place/Iillest+Finds/@33.5611935,-111.9523555,10z/data=!3m1!4b1!4m6!3m5!1s0xadbfdd69eb94967d:0x945954682ee637b3!8m2!3d33.5611935!4d-111.9523556!16s%2Fg%2F11wwp9nh48?entry=ttu&g_ep=EgoyMDI1MDMxMi4wIKXMDSoASAFQAw%3D%3D",
                                                target: "_blank",
                                                rel: "noopener noreferrer",
                                                children: "Scottsdale, Greater Phoenix Area, Arizona"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/components/Header.tsx",
                                                lineNumber: 78,
                                                columnNumber: 3
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/components/Header.tsx",
                                        lineNumber: 76,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/components/Header.tsx",
                                lineNumber: 65,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/Header.tsx",
                            lineNumber: 64,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/components/Header.tsx",
                        lineNumber: 63,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `transition-all duration-300 ${isScrolled ? "bg-white shadow-custom py-2 lg:py-3" : "py-3 md:py-5 lg:py-7 2xl:py-9"}`,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "container mx-auto px-4 md:px-6",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-between items-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "logo",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            href: "/",
                                            prefetch: true,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                src: "/images/logo-text.png",
                                                height: 38,
                                                width: 312,
                                                alt: "logo",
                                                className: `ransition-all duration-300 w-[170px] h-auto lg:w-[312px]`
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/components/Header.tsx",
                                                lineNumber: 100,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/components/Header.tsx",
                                            lineNumber: 99,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/Header.tsx",
                                        lineNumber: 98,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "header-right-side inline-flex items-center gap-4 lg:gap-8",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "header-menu hidden lg:flex items-center",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                        className: "flex gap-8 items-center",
                                                        children: headerMenu.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                    href: item.path,
                                                                    className: `${pathname === item.path ? "text-[20px] font-semibold" : "text-base font-[400]"}  transition-all duration-300 hover:gradient-text"
                      `,
                                                                    prefetch: true,
                                                                    children: item.name
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/components/Header.tsx",
                                                                    lineNumber: 115,
                                                                    columnNumber: 27
                                                                }, this)
                                                            }, index, false, {
                                                                fileName: "[project]/src/app/components/Header.tsx",
                                                                lineNumber: 114,
                                                                columnNumber: 25
                                                            }, this))
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/components/Header.tsx",
                                                        lineNumber: 112,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/components/Header.tsx",
                                                    lineNumber: 111,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/components/Header.tsx",
                                                lineNumber: 110,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                varient: "primary",
                                                text: "Contact",
                                                path: "/contact-us"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/components/Header.tsx",
                                                lineNumber: 132,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                className: "h-[30px] w-[35px] flex-none relative z-[999] lg:hidden",
                                                onClick: handleShowMenu,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "h-[3px] bg-gradient rounded-[3px] block mb-2 w-[70%] ms-auto"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/components/Header.tsx",
                                                        lineNumber: 137,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "h-[3px] bg-gradient rounded-[3px] block mb-2"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/components/Header.tsx",
                                                        lineNumber: 138,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "h-[3px] bg-gradient rounded-[3px] block w-[80%] ms-auto"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/components/Header.tsx",
                                                        lineNumber: 139,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/components/Header.tsx",
                                                lineNumber: 133,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/components/Header.tsx",
                                        lineNumber: 109,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/components/Header.tsx",
                                lineNumber: 97,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/Header.tsx",
                            lineNumber: 96,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/components/Header.tsx",
                        lineNumber: 89,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/components/Header.tsx",
                lineNumber: 58,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `mobile-menu fixed top-0 ${showMenu ? "open" : ""} left-0 w-full h-full z-50 transition-all duration-400 z-[999]`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute bg-black bg-opacity-50 left-0 right-0 bottom-0 top-0",
                        onClick: handleCloseMenu
                    }, void 0, false, {
                        fileName: "[project]/src/app/components/Header.tsx",
                        lineNumber: 152,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                        className: `bg-white w-[300px] p-5 h-full relative off-canvas-inner-content`,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                            className: "",
                            children: headerMenu.map((item, index)=>{
                                const isActive = pathname === item.path || pathname.startsWith(`${item.path}/`);
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                    className: "mb-4",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        href: item.path,
                                        className: `${isActive ? "text-[20px] font-semibold" : "text-[18px] font-[400]"}  transition-all duration-300 hover:gradient-text block"
                      `,
                                        prefetch: true,
                                        children: item.name
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/Header.tsx",
                                        lineNumber: 166,
                                        columnNumber: 19
                                    }, this)
                                }, index, false, {
                                    fileName: "[project]/src/app/components/Header.tsx",
                                    lineNumber: 165,
                                    columnNumber: 17
                                }, this);
                            })
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/Header.tsx",
                            lineNumber: 159,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/components/Header.tsx",
                        lineNumber: 156,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/components/Header.tsx",
                lineNumber: 147,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/components/Header.tsx",
        lineNumber: 57,
        columnNumber: 5
    }, this);
};
_s(Header, "RO7YOhDTpN5ZaAcUuCEtbusjEPE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"]
    ];
});
_c = Header;
const __TURBOPACK__default__export__ = Header;
var _c;
__turbopack_refresh__.register(_c, "Header");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/components/LinkTag.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$SVG$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/app/SVG.tsx [app-client] (ecmascript)");
;
;
const LinkTag = ({ varient = "default", text, className = "", icon, path })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
        className: `py-2 lg:py-3 px-4 lg:px-5 xl:px-7 relative inline-flex items-center justify-center overflow-hidden group rounded-[14px] font-bold transition ease text-[14px] lg:text-base xl:text-[18px] 2xl:text-[20px] ${varient === "primary" ? "bg-gradient text-white" : varient === "secondary" ? "bg-[#f5f5f7]" : "bg-white"} ${className}`,
        href: path,
        target: "_blank",
        rel: "noopener noreferrer",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: `duration-400 ease absolute left-0 top-1/2 block h-0 w-full ${varient === "primary" ? "bg-gradient" : varient === "secondary" ? "bg-[#f5f5f7]" : "bg-white"} opacity-100 transition-all group-hover:top-0 group-hover:h-full`
            }, void 0, false, {
                fileName: "[project]/src/app/components/LinkTag.tsx",
                lineNumber: 27,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "ease absolute right-0 top-1/2 -translate-y-1/2 flex h-5 w-6 translate-x-2 opacity-0 group-hover:opacity-[1] transform items-center justify-start duration-500 group-hover:translate-x-full",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            className: "h-5 w-5",
                            fill: "none",
                            stroke: "currentColor",
                            viewBox: "0 0 24 24",
                            xmlns: "http://www.w3.org/2000/svg",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: "2",
                                d: "M14 5l7 7m0 0l-7 7m7-7H3"
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/LinkTag.tsx",
                                lineNumber: 45,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/LinkTag.tsx",
                            lineNumber: 38,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/components/LinkTag.tsx",
                        lineNumber: 37,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: `relative ${varient !== "primary" && " gradient-text"} ${icon && "gap-3"} transform ease transform duration-700 group-hover:-translate-x-3 flex items-center`,
                        children: [
                            icon === "WhatsAppIcon" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$SVG$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WhatsAppIcon"], {}, void 0, false, {
                                fileName: "[project]/src/app/components/LinkTag.tsx",
                                lineNumber: 58,
                                columnNumber: 39
                            }, this),
                            text
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/components/LinkTag.tsx",
                        lineNumber: 53,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/components/LinkTag.tsx",
                lineNumber: 36,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/components/LinkTag.tsx",
        lineNumber: 15,
        columnNumber: 5
    }, this);
};
_c = LinkTag;
const __TURBOPACK__default__export__ = LinkTag;
var _c;
__turbopack_refresh__.register(_c, "LinkTag");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/components/Footer.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/app/components/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$SVG$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/app/SVG.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$LinkTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/app/components/LinkTag.tsx [app-client] (ecmascript)"); // ✅ Removed unused `useRouter`
"use client";
;
;
;
;
;
const servicesLinks = [
    {
        name: "Social Media Marketing",
        desc: "Grow engagement, leads & sales!",
        path: "/services/seo-services-phoenix"
    },
    {
        name: "SEO Services",
        desc: "Rank higher, get traffic & dominate search engines!",
        path: "/services/social-media-marketing-phoenix"
    },
    {
        name: "Website Development",
        desc: "High-performance websites that convert!",
        path: "/services/website-development-phoenix"
    }
];
const socialLinks = [
    {
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$SVG$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Facebook"], {}, void 0, false, {
            fileName: "[project]/src/app/components/Footer.tsx",
            lineNumber: 36,
            columnNumber: 11
        }, this),
        path: "https://www.facebook.com/share/1AEuGAPGKZ"
    },
    {
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$SVG$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Instagram"], {}, void 0, false, {
            fileName: "[project]/src/app/components/Footer.tsx",
            lineNumber: 40,
            columnNumber: 11
        }, this),
        path: "https://www.instagram.com/iillestfinds"
    },
    {
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$SVG$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Tiktok"], {}, void 0, false, {
            fileName: "[project]/src/app/components/Footer.tsx",
            lineNumber: 44,
            columnNumber: 11
        }, this),
        path: "https://www.tiktok.com/@faeezahlun"
    }
];
const Footer = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
        className: "pt-12 md:pt-18 lg:pt-20 2xl:pt-24",
        "aria-label": "Footer",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative -mb-24",
                id: "contact-us",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container mx-auto px-4 md:px-6",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-gradient rounded-[10px] p-7",
                        role: "region",
                        "aria-label": "Contact Call-to-Action",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-wrap gap-6 md:gap-8 lg:gap-10 lg:flex-nowrap items-center justify-center lg:justify-between",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$LinkTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    icon: "WhatsAppIcon",
                                    text: "Contact Us",
                                    className: "py-2 lg:py-4 flex-none w-[180px] lg:w-[214px] h-[50px] lg:h-[67px]",
                                    path: "https://wa.me/19258184494"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/Footer.tsx",
                                    lineNumber: 61,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-center max-w-[736px]",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                            className: "text-[18px] md:text-[24px] lg:text-[30px] 2xl:text-[35px] leading-[42px] lg:leading-[57px] font-bold mb-3 text-white",
                                            children: "Ready to Grow Your Local Business?"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/components/Footer.tsx",
                                            lineNumber: 68,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-[14px] lg:text-base 2xl:text-[18px] leading-[28px] font-[400] text-white",
                                            children: "Let’s take your online presence to the next level. It’s time to build, rank, and convert—together!"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/components/Footer.tsx",
                                            lineNumber: 71,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/components/Footer.tsx",
                                    lineNumber: 67,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    text: "Get a Quote",
                                    className: "py-2 lg:py-4 flex-none w-[180px] lg:w-[214px] h-[50px] lg:h-[67px]",
                                    path: "/contact-us"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/Footer.tsx",
                                    lineNumber: 76,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/components/Footer.tsx",
                            lineNumber: 60,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/components/Footer.tsx",
                        lineNumber: 55,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/components/Footer.tsx",
                    lineNumber: 54,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/components/Footer.tsx",
                lineNumber: 53,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-[#F4E1FF] bg-opacity-50 pt-40",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container mx-auto px-4 md:px-6 pb-16",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-[2fr_1fr_1fr] gap-6 lg:gap-14 md:justify-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                        className: "text-[26px] leading-[37px] text-gradient tracking-[0.1px] font-bold mb-5",
                                        children: "Grow Your Business with Expert Digital Solutions in Phoenix!"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/Footer.tsx",
                                        lineNumber: 92,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-[16px] leading-[26px] text-gradient tracking-[0.2px] font-[400] mb-5",
                                        children: "Struggling to get leads, rank on Google, or build a high-converting website? We’ve got you covered—right here in Phoenix, AZ."
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/Footer.tsx",
                                        lineNumber: 95,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex flex-wrap md:lg-nowrap items-center gap-5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h6", {
                                                className: "text-base text-black font-bold",
                                                children: "Have Questions? Let’s Talk!"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/components/Footer.tsx",
                                                lineNumber: 101,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$LinkTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                text: "Book a Meeting",
                                                varient: "primary",
                                                className: "flex-none rounded-[10px] text-[18px]",
                                                path: "https://app.acuityscheduling.com/schedule.php?owner=32088231&calendarID=10026411"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/components/Footer.tsx",
                                                lineNumber: 104,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/components/Footer.tsx",
                                        lineNumber: 100,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/components/Footer.tsx",
                                lineNumber: 91,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                                "aria-label": "Services",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                        className: "text-[18px] leading-[24px] text-gradient tracking-[0.3px] font-medium mb-5",
                                        children: "Services"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/Footer.tsx",
                                        lineNumber: 115,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                        children: servicesLinks.map((item, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    href: item.path,
                                                    className: "text-[14px] font-[400] leading-[25px] text-gradient hover:text-black block mb-5",
                                                    prefetch: true,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                            children: item.name
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/components/Footer.tsx",
                                                            lineNumber: 126,
                                                            columnNumber: 23
                                                        }, this),
                                                        " – ",
                                                        item.desc
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/components/Footer.tsx",
                                                    lineNumber: 121,
                                                    columnNumber: 21
                                                }, this)
                                            }, i, false, {
                                                fileName: "[project]/src/app/components/Footer.tsx",
                                                lineNumber: 120,
                                                columnNumber: 19
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/Footer.tsx",
                                        lineNumber: 118,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/components/Footer.tsx",
                                lineNumber: 114,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                "aria-label": "Contact Information",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                        className: "text-[18px] leading-[24px] text-gradient tracking-[0.3px] font-medium mb-5",
                                        children: "Contact Us"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/Footer.tsx",
                                        lineNumber: 135,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("address", {
                                        className: "mb-5 not-italic",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    className: "flex gap-3 items-center text-[12px] font-[400] leading-[25px] group mb-3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$SVG$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Email"], {}, void 0, false, {
                                                            fileName: "[project]/src/app/components/Footer.tsx",
                                                            lineNumber: 141,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                            className: "inline-block text-gradient group-hover:text-black",
                                                            href: "mailto:faeezahlun@iillestfinds.com",
                                                            children: "faeezahlun@iillestfinds.com"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/components/Footer.tsx",
                                                            lineNumber: 142,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/components/Footer.tsx",
                                                    lineNumber: 140,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    className: "flex gap-3 items-center text-[12px] font-[400] leading-[25px] group mb-3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$SVG$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Phone"], {}, void 0, false, {
                                                            fileName: "[project]/src/app/components/Footer.tsx",
                                                            lineNumber: 150,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                            className: "inline-block text-gradient group-hover:text-black",
                                                            href: "tel:+19258184494",
                                                            children: "(+1) 925-818-4494"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/components/Footer.tsx",
                                                            lineNumber: 151,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/components/Footer.tsx",
                                                    lineNumber: 149,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    className: "flex gap-3 items-center text-[12px] font-[400] leading-[25px] group mb-3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$SVG$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Location"], {}, void 0, false, {
                                                            fileName: "[project]/src/app/components/Footer.tsx",
                                                            lineNumber: 159,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                            className: "inline-block text-gradient group-hover:text-black",
                                                            href: "https://www.google.com/maps/place/Iillest+Finds",
                                                            target: "_blank",
                                                            rel: "noopener noreferrer",
                                                            children: "Scottsdale, Greater Phoenix Area, Arizona"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/components/Footer.tsx",
                                                            lineNumber: 160,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/components/Footer.tsx",
                                                    lineNumber: 158,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/components/Footer.tsx",
                                            lineNumber: 139,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/Footer.tsx",
                                        lineNumber: 138,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                                        "aria-label": "Social Media Links",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                            className: "flex gap-4",
                                            children: socialLinks.map((item, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                        href: item.path,
                                                        className: "flex items-center justify-center rounded-[5px] h-[30px] w-[30px] bg-[#491F61]",
                                                        "aria-label": `Follow us on ${item.icon.type.name || "Social Media"}`,
                                                        children: item.icon
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/components/Footer.tsx",
                                                        lineNumber: 175,
                                                        columnNumber: 23
                                                    }, this)
                                                }, i, false, {
                                                    fileName: "[project]/src/app/components/Footer.tsx",
                                                    lineNumber: 174,
                                                    columnNumber: 21
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/components/Footer.tsx",
                                            lineNumber: 172,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/Footer.tsx",
                                        lineNumber: 171,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/components/Footer.tsx",
                                lineNumber: 134,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/components/Footer.tsx",
                        lineNumber: 89,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/components/Footer.tsx",
                    lineNumber: 88,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/components/Footer.tsx",
                lineNumber: 87,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/components/Footer.tsx",
        lineNumber: 51,
        columnNumber: 5
    }, this);
};
_c = Footer;
const __TURBOPACK__default__export__ = Footer;
var _c;
__turbopack_refresh__.register(_c, "Footer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/layout.tsx [app-rsc] (ecmascript, Next.js server component, client modules)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
}}),
}]);

//# sourceMappingURL=src_app_19dc24._.js.map